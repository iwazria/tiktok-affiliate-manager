"use client";

import { cx } from "@/lib/format";
import { Button } from "@/components/Button";

interface PaginationProps {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
  className?: string;
}

const WINDOW = 2;

/**
 * "Page X of Y" + Prev/Next buttons + windowed page numbers (current ±2).
 * Renders null when totalPages <= 1.
 */
export function Pagination({
  page,
  totalPages,
  onChange,
  className,
}: PaginationProps): React.JSX.Element | null {
  if (totalPages <= 1) return null;

  const start = Math.max(1, page - WINDOW);
  const end = Math.min(totalPages, page + WINDOW);
  const pages: number[] = [];
  for (let p = start; p <= end; p++) pages.push(p);

  return (
    <nav
      aria-label="Pagination"
      className={cx("flex flex-wrap items-center gap-2", className)}
    >
      <p className="mr-2 text-sm text-slate-600" aria-live="polite">
        Page {page} of {totalPages}
      </p>
      <Button
        size="sm"
        variant="secondary"
        disabled={page <= 1}
        onClick={() => onChange(page - 1)}
        ariaLabel="Previous page"
      >
        Prev
      </Button>
      <div className="flex items-center gap-1" role="group" aria-label="Page numbers">
        {pages.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => onChange(p)}
            disabled={p === page}
            aria-label={p === page ? `Page ${p}, current page` : `Go to page ${p}`}
            aria-current={p === page ? "page" : undefined}
            className={cx(
              "min-w-9 rounded-lg px-2 py-1.5 text-sm font-medium transition-colors",
              "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
              p === page
                ? "cursor-default bg-indigo-600 text-white"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            )}
          >
            {p}
          </button>
        ))}
      </div>
      <Button
        size="sm"
        variant="secondary"
        disabled={page >= totalPages}
        onClick={() => onChange(page + 1)}
        ariaLabel="Next page"
      >
        Next
      </Button>
    </nav>
  );
}
