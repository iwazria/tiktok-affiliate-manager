import { cx } from "@/lib/format";

export interface ChartDatum {
  label: string;
  value: number;
}

interface ChartProps {
  data: ChartDatum[];
  height?: number;
  ariaLabel: string;
  formatValue?: (v: number) => string;
}

const MAX_BARS = 12;

/** Visually-hidden data table so charts are never information-by-image-alone. */
function ChartDataTable({
  data,
  ariaLabel,
  formatValue,
}: {
  data: ChartDatum[];
  ariaLabel: string;
  formatValue?: (v: number) => string;
}): React.JSX.Element {
  return (
    <table className="sr-only">
      <caption>{ariaLabel}</caption>
      <thead>
        <tr>
          <th scope="col">Label</th>
          <th scope="col">Value</th>
        </tr>
      </thead>
      <tbody>
        {data.map((d) => (
          <tr key={d.label}>
            <th scope="row">{d.label}</th>
            <td>{formatValue ? formatValue(d.value) : d.value}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function truncate(label: string, max = 10): string {
  return label.length > max ? `${label.slice(0, max - 1)}…` : label;
}

function EmptyChart({ message = "No data" }: { message?: string }): React.JSX.Element {
  return <p className="py-8 text-center text-sm text-slate-500">{message}</p>;
}

/** Pure-SVG bar chart. Limited to 12 bars. */
export function BarChart({
  data,
  height = 220,
  ariaLabel,
  formatValue,
}: ChartProps): React.JSX.Element {
  const shown = data.slice(0, MAX_BARS);
  if (shown.length === 0) return <EmptyChart />;

  const max = Math.max(...shown.map((d) => d.value), 0);
  const W = 600;
  const labelArea = 28;
  const topPad = 24;
  const plotH = height - labelArea - topPad;
  const slotW = W / shown.length;
  const barW = Math.min(48, slotW * 0.6);
  const fmt = (v: number) => (formatValue ? formatValue(v) : String(v));

  return (
    <div>
      <svg
        viewBox={`0 0 ${W} ${height}`}
        className="h-auto w-full"
        role="img"
        aria-label={ariaLabel}
      >
        <title>{ariaLabel}</title>
        {/* baseline */}
        <line
          x1={0}
          y1={topPad + plotH}
          x2={W}
          y2={topPad + plotH}
          stroke="#cbd5e1"
          strokeWidth={1}
        />
        {shown.map((d, i) => {
          const barH = max > 0 ? (d.value / max) * plotH : 0;
          const x = i * slotW + (slotW - barW) / 2;
          const y = topPad + plotH - barH;
          return (
            <g key={d.label}>
              <title>{`${d.label}: ${fmt(d.value)}`}</title>
              <rect
                x={x}
                y={y}
                width={barW}
                height={Math.max(barH, 0)}
                rx={3}
                className="fill-indigo-600"
              />
              <text
                x={x + barW / 2}
                y={Math.max(y - 6, 10)}
                textAnchor="middle"
                className="fill-slate-600"
                fontSize={11}
              >
                {fmt(d.value)}
              </text>
              <text
                x={x + barW / 2}
                y={topPad + plotH + 18}
                textAnchor="middle"
                className="fill-slate-500"
                fontSize={11}
              >
                {truncate(d.label)}
              </text>
            </g>
          );
        })}
      </svg>
      <ChartDataTable data={shown} ariaLabel={ariaLabel} formatValue={formatValue} />
    </div>
  );
}

/** Pure-SVG line chart with area fill and dots. X labels: first / middle / last. */
export function LineChart({
  data,
  height = 220,
  ariaLabel,
  formatValue,
}: ChartProps): React.JSX.Element {
  if (data.length === 0) return <EmptyChart />;

  const W = 600;
  const labelArea = 28;
  const topPad = 16;
  const sidePad = 12;
  const plotW = W - sidePad * 2;
  const plotH = height - labelArea - topPad;
  const fmt = (v: number) => (formatValue ? formatValue(v) : String(v));

  const values = data.map((d) => d.value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min;

  const x = (i: number) =>
    data.length === 1 ? sidePad + plotW / 2 : sidePad + (i / (data.length - 1)) * plotW;
  const y = (v: number) =>
    span === 0 ? topPad + plotH / 2 : topPad + plotH - ((v - min) / span) * plotH;

  const points = data.map((d, i) => `${x(i)},${y(d.value)}`).join(" ");
  const areaPath = `M${sidePad},${topPad + plotH} L${points.replaceAll(" ", " L")} L${sidePad + plotW},${topPad + plotH} Z`;

  const labelIdx = [0, Math.floor((data.length - 1) / 2), data.length - 1].filter(
    (idx, pos, arr) => data.length > 0 && arr.indexOf(idx) === pos
  );

  return (
    <div>
      <svg
        viewBox={`0 0 ${W} ${height}`}
        className="h-auto w-full"
        role="img"
        aria-label={ariaLabel}
      >
        <title>{ariaLabel}</title>
        <path d={areaPath} className="fill-indigo-100" opacity={0.7} />
        <polyline
          points={points}
          fill="none"
          className="stroke-indigo-600"
          strokeWidth={2.5}
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        {data.map((d, i) => (
          <g key={d.label}>
            <title>{`${d.label}: ${fmt(d.value)}`}</title>
            <circle
              cx={x(i)}
              cy={y(d.value)}
              r={4}
              className={cx("fill-white stroke-indigo-600")}
              strokeWidth={2.5}
            />
          </g>
        ))}
        {labelIdx.map((idx) => (
          <text
            key={idx}
            x={x(idx)}
            y={topPad + plotH + 18}
            textAnchor={
              idx === 0 ? "start" : idx === data.length - 1 ? "end" : "middle"
            }
            className="fill-slate-500"
            fontSize={11}
          >
            {truncate(data[idx].label, 14)}
          </text>
        ))}
      </svg>
      <ChartDataTable data={data} ariaLabel={ariaLabel} formatValue={formatValue} />
    </div>
  );
}
