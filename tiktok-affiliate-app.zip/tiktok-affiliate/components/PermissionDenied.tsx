import type { ReactNode } from "react";
import { Card } from "@/components/Card";
import { AlertIcon } from "@/components/icons";

interface PermissionDeniedProps {
  title?: string;
  body?: ReactNode;
  action?: ReactNode;
}

const DEFAULT_BODY =
  "Your role doesn't allow this. Permissions are enforced by the server — contact an admin if you need access.";

/** Shown when the user's role can't use a page or action. */
export function PermissionDenied({
  title = "Permission denied",
  body,
  action,
}: PermissionDeniedProps): React.JSX.Element {
  return (
    <Card className="mx-auto max-w-lg text-center">
      <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-red-50 text-red-600">
        <AlertIcon className="h-6 w-6" />
      </div>
      <h2 className="text-base font-semibold text-slate-900">{title}</h2>
      <p className="mt-1 text-sm text-slate-600">{body ?? DEFAULT_BODY}</p>
      {action && <div className="mt-4 flex items-center justify-center gap-2">{action}</div>}
    </Card>
  );
}
