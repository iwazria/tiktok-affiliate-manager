import { cx } from "@/lib/format";

interface SkeletonProps {
  className?: string;
}

/** Pulsing placeholder block. */
export function Skeleton({ className }: SkeletonProps): React.JSX.Element {
  return (
    <div
      aria-hidden="true"
      className={cx("animate-pulse rounded bg-slate-200", className)}
    />
  );
}

interface SkeletonLinesProps {
  lines?: number;
  className?: string;
}

/** Stack of pulsing text-line placeholders. */
export function SkeletonLines({
  lines = 3,
  className,
}: SkeletonLinesProps): React.JSX.Element {
  return (
    <div aria-hidden="true" className={cx("space-y-2", className)}>
      {Array.from({ length: lines }, (_, i) => (
        <div
          key={i}
          className={cx(
            "h-4 animate-pulse rounded bg-slate-200",
            i === lines - 1 && "w-2/3"
          )}
        />
      ))}
    </div>
  );
}
