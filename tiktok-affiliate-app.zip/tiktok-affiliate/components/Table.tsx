import type { ReactNode } from "react";
import { cx } from "@/lib/format";

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  className?: string;
}

interface TableProps<T> {
  columns: Column<T>[];
  data: T[];
  rowKey: (row: T) => string;
  caption?: string;
  ariaLabel: string;
}

/**
 * Responsive data table. Desktop (sm+): a real <table>.
 * Mobile (<sm): each row becomes a bordered card with a <dl> of header/value pairs.
 * Empty states are the page's job (see EmptyState) — this renders no rows when data is empty.
 */
export function Table<T>({
  columns,
  data,
  rowKey,
  caption,
  ariaLabel,
}: TableProps<T>): React.JSX.Element {
  return (
    <div>
      {/* Desktop: real table */}
      <div className="hidden overflow-x-auto sm:block">
        <table
          aria-label={ariaLabel}
          className="min-w-full divide-y divide-slate-200"
        >
          {caption ? <caption className="sr-only">{caption}</caption> : null}
          <thead className="bg-slate-50">
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key}
                  scope="col"
                  className={cx(
                    "px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500",
                    col.className
                  )}
                >
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {data.map((row) => (
              <tr key={rowKey(row)} className="transition-colors hover:bg-slate-50">
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={cx("px-4 py-3 text-sm text-slate-700", col.className)}
                  >
                    {col.render(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile: stacked cards */}
      <div className="space-y-3 sm:hidden" role="list" aria-label={ariaLabel}>
        {data.map((row) => (
          <div
            key={rowKey(row)}
            role="listitem"
            className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm"
          >
            <dl className="divide-y divide-slate-100">
              {columns.map((col) => (
                <div
                  key={col.key}
                  className="flex items-start justify-between gap-4 py-2 first:pt-0 last:pb-0"
                >
                  <dt className="shrink-0 text-xs font-semibold uppercase tracking-wide text-slate-500">
                    {col.header}
                  </dt>
                  <dd className="text-right text-sm text-slate-700">
                    {col.render(row)}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        ))}
      </div>
    </div>
  );
}
