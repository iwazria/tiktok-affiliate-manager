import type { ReactNode } from "react";
import { cx } from "@/lib/format";

interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  body?: ReactNode;
  action?: ReactNode;
  className?: string;
}

/** Centered empty-state block: icon, title, body text, optional action buttons. */
export function EmptyState({
  icon,
  title,
  body,
  action,
  className,
}: EmptyStateProps): React.JSX.Element {
  return (
    <div className={cx("px-6 py-12 text-center", className)}>
      {icon && (
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-500">
          {icon}
        </div>
      )}
      <p className="text-base font-semibold text-slate-900">{title}</p>
      {body && <div className="mx-auto mt-1 max-w-sm text-sm text-slate-600">{body}</div>}
      {action && <div className="mt-4 flex items-center justify-center gap-2">{action}</div>}
    </div>
  );
}
