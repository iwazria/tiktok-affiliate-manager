"use client";

import type { ReactNode } from "react";
import { cx } from "@/lib/format";
import {
  AlertIcon,
  CheckIcon,
  InfoIcon,
  XIcon,
} from "@/components/icons";

export type AlertTone = "info" | "success" | "warning" | "error";

const TONE_STYLES: Record<AlertTone, string> = {
  info: "border-blue-200 bg-blue-50 text-blue-900",
  success: "border-emerald-200 bg-emerald-50 text-emerald-900",
  warning: "border-amber-200 bg-amber-50 text-amber-900",
  error: "border-red-200 bg-red-50 text-red-900",
};

const TONE_ICON_STYLES: Record<AlertTone, string> = {
  info: "text-blue-600",
  success: "text-emerald-600",
  warning: "text-amber-600",
  error: "text-red-600",
};

function ToneIcon({ tone }: { tone: AlertTone }): React.JSX.Element {
  const className = cx("h-5 w-5 shrink-0", TONE_ICON_STYLES[tone]);
  switch (tone) {
    case "success":
      return <CheckIcon className={className} />;
    case "warning":
    case "error":
      return <AlertIcon className={className} />;
    case "info":
    default:
      return <InfoIcon className={className} />;
  }
}

interface AlertProps {
  tone: AlertTone;
  title?: ReactNode;
  children: ReactNode;
  onDismiss?: () => void;
  className?: string;
}

/**
 * Notice banner. role="alert" for error/warning (assertive), role="status"
 * otherwise. Icon + text; optional dismiss button with aria-label="Dismiss".
 */
export function Alert({
  tone,
  title,
  children,
  onDismiss,
  className,
}: AlertProps): React.JSX.Element {
  const assertive = tone === "error" || tone === "warning";
  return (
    <div
      role={assertive ? "alert" : "status"}
      className={cx(
        "flex items-start gap-3 rounded-lg border px-4 py-3 text-sm",
        TONE_STYLES[tone],
        className
      )}
    >
      <ToneIcon tone={tone} />
      <div className="min-w-0 flex-1">
        {title && <p className="font-semibold">{title}</p>}
        <div className={cx(title ? "mt-0.5" : null)}>{children}</div>
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss"
          className="rounded-lg p-1 opacity-70 transition-opacity hover:opacity-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current"
        >
          <XIcon className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
