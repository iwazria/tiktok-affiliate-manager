import { Alert } from "@/components/Alert";

interface CapabilityNoteProps {
  feature: string;
  reason?: string;
}

/**
 * Replaces a control that can't work (missing approval/authorization) with a
 * warning note. Never render a broken control — pages use this instead.
 */
export function CapabilityNote({
  feature,
  reason,
}: CapabilityNoteProps): React.JSX.Element {
  return (
    <Alert tone="warning" title={`${feature} isn't available`}>
      <p>{reason ?? "This requires additional TikTok Shop approval or authorization."}</p>
    </Alert>
  );
}
