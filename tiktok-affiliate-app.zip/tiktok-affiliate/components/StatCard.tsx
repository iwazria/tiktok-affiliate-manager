import type { ReactNode } from "react";
import { cx } from "@/lib/format";
import { DataSourceLabel } from "@/components/DataSourceLabel";

interface StatCardProps {
  title: string;
  value: ReactNode;
  source: string;
  quality?: string | null;
  syncedAt?: string | null;
  hint?: ReactNode;
  icon?: ReactNode;
  className?: string;
}

/** KPI card: uppercase title, large value, provenance label, optional hint/icon. */
export function StatCard({
  title,
  value,
  source,
  quality,
  syncedAt,
  hint,
  icon,
  className,
}: StatCardProps): React.JSX.Element {
  return (
    <section
      className={cx(
        "rounded-xl border border-slate-200 bg-white p-5 shadow-sm",
        className
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          {title}
        </p>
        {icon && <div className="text-slate-400">{icon}</div>}
      </div>
      <p className="mt-1 text-2xl font-bold text-slate-900">{value}</p>
      <div className="mt-2">
        <DataSourceLabel source={source} quality={quality} syncedAt={syncedAt} />
      </div>
      {hint && <p className="mt-2 text-xs text-slate-500">{hint}</p>}
    </section>
  );
}
