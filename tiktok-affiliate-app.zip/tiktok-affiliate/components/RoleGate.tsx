"use client";

import type { ReactNode } from "react";
import { roleAtLeast } from "@/lib/roles";
import { useOrg } from "@/components/OrgContext";

interface CanProps {
  minRole: string;
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * Renders children only when the current org role meets `minRole`.
 * UX-only: permissions are enforced by the server.
 */
export function Can({ minRole, children, fallback = null }: CanProps): React.JSX.Element | null {
  const { role } = useOrg();
  if (!roleAtLeast(role, minRole)) return <>{fallback}</>;
  return <>{children}</>;
}
