import type { ReactNode } from "react";
import { cx } from "@/lib/format";

export type BadgeTone = "green" | "yellow" | "red" | "blue" | "gray" | "purple";

const TONE_STYLES: Record<BadgeTone, string> = {
  green: "bg-emerald-50 text-emerald-800 border-emerald-200",
  yellow: "bg-amber-50 text-amber-800 border-amber-200",
  red: "bg-red-50 text-red-800 border-red-200",
  blue: "bg-blue-50 text-blue-800 border-blue-200",
  gray: "bg-slate-100 text-slate-700 border-slate-200",
  purple: "bg-violet-50 text-violet-800 border-violet-200",
};

interface BadgeProps {
  tone: BadgeTone;
  children: ReactNode;
  className?: string;
}

/** Status pill — always text, never color alone. */
export function Badge({ tone, children, className }: BadgeProps): React.JSX.Element {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium leading-5",
        TONE_STYLES[tone],
        className
      )}
    >
      {children}
    </span>
  );
}
