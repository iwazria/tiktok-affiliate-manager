import { Alert } from "@/components/Alert";

interface FieldErrorProps {
  error?: string | string[] | null;
}

/** Inline field error text. Renders nothing when there is no error. */
export function FieldError({ error }: FieldErrorProps): React.JSX.Element | null {
  const messages = Array.isArray(error) ? error : error ? [error] : [];
  if (messages.length === 0) return null;
  return (
    <p role="alert" className="mt-1 text-xs font-medium text-red-600">
      {messages.join(" ")}
    </p>
  );
}

interface FormErrorsProps {
  errors: Record<string, string[]> | null;
}

/**
 * Form-level error summary: an Alert listing "field: message" lines.
 * Renders nothing when errors is null or empty.
 */
export function FormErrors({ errors }: FormErrorsProps): React.JSX.Element | null {
  const entries = errors ? Object.entries(errors) : [];
  const items = entries.flatMap(([field, messages]) =>
    messages.map((message) => ({ field, message }))
  );
  if (items.length === 0) return null;
  return (
    <Alert tone="error" title="Please fix the following errors">
      <ul className="list-disc space-y-0.5 pl-5">
        {items.map(({ field, message }, i) => (
          <li key={`${field}-${i}`}>
            <span className="font-medium capitalize">{field}</span>: {message}
          </li>
        ))}
      </ul>
    </Alert>
  );
}
