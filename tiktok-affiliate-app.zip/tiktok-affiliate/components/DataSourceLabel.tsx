"use client";

import { cx } from "@/lib/format";
import { timeAgo } from "@/lib/format";
import type { DataQuality, DataSource } from "@/lib/types";

const SOURCE_TEXT: Record<string, string> = {
  live: "TikTok API",
  tiktok_api: "TikTok API",
  demo: "Demo data",
  manual: "Entered manually",
  none: "Not available",
};

const SOURCE_TONE: Record<string, string> = {
  live: "bg-emerald-50 text-emerald-800 border-emerald-200",
  tiktok_api: "bg-emerald-50 text-emerald-800 border-emerald-200",
  demo: "bg-amber-50 text-amber-800 border-amber-200",
  manual: "bg-slate-100 text-slate-700 border-slate-200",
  none: "bg-slate-100 text-slate-500 border-slate-200",
};

export interface DataSourceLabelProps {
  source: DataSource | string;
  quality?: DataQuality | string | null;
  syncedAt?: string | null;
  className?: string;
}

/**
 * Provenance pill for EVERY metric: e.g. "Demo data · synced 2m ago",
 * "TikTok API · estimated · synced 1h ago". Never color-alone: always text.
 */
export function DataSourceLabel({
  source,
  quality,
  syncedAt,
  className,
}: DataSourceLabelProps): React.JSX.Element {
  const key = source === "tiktok_api" ? "live" : source;
  let text = SOURCE_TEXT[source] ?? String(source);

  if (quality === "estimated") text += " · estimated";
  else if (quality === "pending") text += " · pending";
  else if (quality === "unavailable") text += " · unavailable";

  if (syncedAt) text += ` · synced ${timeAgo(syncedAt)}`;

  const title =
    source === "demo" || source === "tiktok_api" || source === "live"
      ? `Source: ${SOURCE_TEXT[source]}${syncedAt ? `, last synced ${timeAgo(syncedAt)}` : ""}`
      : `Source: ${text}`;

  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium leading-4",
        SOURCE_TONE[key] ?? SOURCE_TONE.manual,
        className
      )}
      title={title}
    >
      {text}
    </span>
  );
}
