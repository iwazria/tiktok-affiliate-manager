"use client";

import { cx } from "@/lib/format";
import { useOrg } from "@/components/OrgContext";

/** Amber banner shown when the workspace is in demo mode. */
export function DemoBanner({ className }: { className?: string }): React.JSX.Element {
  // useOrg throws outside an <OrgProvider>; fall back to "/docs" then.
  let orgSlug = "";
  try {
    orgSlug = useOrg().orgSlug;
  } catch {
    orgSlug = "";
  }
  const docsHref = orgSlug ? `/${orgSlug}/docs` : "/docs";

  return (
    <div
      role="status"
      className={cx(
        "flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-900",
        className
      )}
    >
      <p>
        <span className="font-semibold">Demo mode</span>
        {" — you're viewing simulated data, not live TikTok Shop data."}
      </p>
      <a
        href={docsHref}
        className="font-medium text-amber-800 underline decoration-amber-400 underline-offset-2 hover:text-amber-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-600"
      >
        Learn more
      </a>
    </div>
  );
}
