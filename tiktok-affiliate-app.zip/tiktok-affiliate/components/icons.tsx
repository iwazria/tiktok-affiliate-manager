/** Tiny inline SVG icon set (no dependencies). All inherit currentColor. */

interface IconProps {
  className?: string;
}

function base(className: string | undefined, path: React.ReactNode, viewBox = "0 0 24 24") {
  return (
    <svg
      className={className ?? "h-5 w-5"}
      viewBox={viewBox}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {path}
    </svg>
  );
}

export const DashboardIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <rect x="3" y="3" width="7" height="9" rx="1.5" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </>
  );

export const BoxIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <path d="M21 8.5 12 3 3 8.5v7L12 21l9-5.5v-7Z" />
      <path d="M3 8.5 12 14l9-5.5" />
      <path d="M12 14v7" />
    </>
  );

export const MegaphoneIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <path d="M3 11v3l4 .5V10.5L3 11Z" />
      <path d="M7 10.5 18 5v13l-11-3.5" />
      <path d="M18 8.5a3 3 0 0 1 0 6" />
      <path d="M9 15.5V19a1.5 1.5 0 0 0 3 0v-2.5" />
    </>
  );

export const UsersIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <circle cx="9" cy="8" r="3.5" />
      <path d="M2.5 20a6.5 6.5 0 0 1 13 0" />
      <path d="M16 5a3.5 3.5 0 0 1 0 7" />
      <path d="M17.5 14.5a6.5 6.5 0 0 1 4 5.5" />
    </>
  );

export const ChartIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <path d="M3 3v18h18" />
      <path d="M7 15v3" />
      <path d="M12 10v8" />
      <path d="M17 6v12" />
    </>
  );

export const TeamIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <circle cx="12" cy="8" r="3.5" />
      <path d="M5 20a7 7 0 0 1 14 0" />
    </>
  );

export const GearIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.9 2.9l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.9-2.9l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.9-2.9l.1.1a1.7 1.7 0 0 0 1.9.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.5h.1a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.9 2.9l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.5 1h.2a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.5 1Z" />
    </>
  );

export const BellIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.7 21a2 2 0 0 1-3.4 0" />
    </>
  );

export const PlusIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="M12 5v14" />
    <path d="M5 12h14" />
  </>);

export const SearchIcon = ({ className }: IconProps) =>
  base(className, <>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </>);

export const XIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="M18 6 6 18" />
    <path d="m6 6 12 12" />
  </>);

export const CheckIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="m4 12.5 5 5L20 6.5" />
  </>);

export const AlertIcon = ({ className }: IconProps) =>
  base(
    className,
    <>
      <path d="M12 3 2 20h20L12 3Z" />
      <path d="M12 10v4" />
      <path d="M12 17.5h.01" />
    </>
  );

export const DownloadIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="M12 3v12" />
    <path d="m7 10 5 5 5-5" />
    <path d="M4 21h16" />
  </>);

export const RefreshIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="M21 12a9 9 0 1 1-2.6-6.4" />
    <path d="M21 3v6h-6" />
  </>);

export const ChevronDownIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="m6 9 6 6 6-6" />
  </>);

export const MenuIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="M4 6h16" />
    <path d="M4 12h16" />
    <path d="M4 18h16" />
  </>);

export const UserIcon = ({ className }: IconProps) =>
  base(className, <>
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21a8 8 0 0 1 16 0" />
  </>);

export const LinkIcon = ({ className }: IconProps) =>
  base(className, <>
    <path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7" />
    <path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7" />
  </>);

export const InfoIcon = ({ className }: IconProps) =>
  base(className, <>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v5" />
    <path d="M12 8h.01" />
  </>);

export const EmptyBoxIcon = ({ className }: IconProps) =>
  base(
    className ?? "h-12 w-12",
    <>
      <path d="M21 8.5 12 3 3 8.5v7L12 21l9-5.5v-7Z" />
      <path d="M3 8.5 12 14l9-5.5" />
      <path d="M12 14v7" />
    </>
  );
