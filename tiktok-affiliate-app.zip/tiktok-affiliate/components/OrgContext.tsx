"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { apiFetch, ApiRequestError } from "@/lib/client";
import type { MeResponse, Shop } from "@/lib/types";

export interface OrgInfo {
  id: string;
  name: string;
  slug: string;
}

interface OrgContextValue {
  loading: boolean;
  /** "unauthorized" | "not-member" | "load-failed" | null */
  error: string | null;
  errorMessage: string | null;
  me: MeResponse | null;
  org: OrgInfo | null;
  orgId: string | null;
  orgSlug: string;
  role: string | null;
  shops: Shop[];
  shopsLoading: boolean;
  selectedShop: Shop | null;
  selectShop: (id: string) => void;
  /** True when any connected shop is in demo mode. */
  isDemo: boolean;
  refreshShops: () => Promise<void>;
}

const OrgContext = createContext<OrgContextValue | null>(null);

function shopStorageKey(orgId: string): string {
  return `tam:shop:${orgId}`;
}

/** Defensive extractor: GET /api/orgs/[orgId]/shops returns a plain array. */
function extractShops(data: unknown): Shop[] {
  if (Array.isArray(data)) return data as Shop[];
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.shops)) return d.shops as Shop[];
    if (Array.isArray(d.items)) return d.items as Shop[];
  }
  return [];
}

export function OrgProvider({
  orgSlug,
  children,
}: {
  orgSlug: string;
  children: ReactNode;
}): React.JSX.Element {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [me, setMe] = useState<MeResponse | null>(null);
  const [org, setOrg] = useState<OrgInfo | null>(null);
  const [role, setRole] = useState<string | null>(null);
  const [shops, setShops] = useState<Shop[]>([]);
  const [shopsLoading, setShopsLoading] = useState(false);
  const [selectedShopId, setSelectedShopId] = useState<string | null>(null);

  const loadShops = useCallback(async (orgId: string) => {
    setShopsLoading(true);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/shops`);
      const list = extractShops(data);
      setShops(list);
      // Restore selection from localStorage, else first shop.
      let chosen: string | null = null;
      try {
        chosen = window.localStorage.getItem(shopStorageKey(orgId));
      } catch {
        chosen = null;
      }
      if (!chosen || !list.some((s) => s.id === chosen)) {
        chosen = list[0]?.id ?? null;
      }
      setSelectedShopId(chosen);
    } catch {
      // Shops failing to load must not break the whole app; pages show their own states.
      setShops([]);
      setSelectedShopId(null);
    } finally {
      setShopsLoading(false);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      setErrorMessage(null);
      try {
        const meData = await apiFetch<MeResponse>("/api/auth/me");
        if (cancelled) return;
        const membership = meData.memberships.find(
          (m) => m.organization.slug === orgSlug
        );
        if (!membership) {
          setError("not-member");
          setErrorMessage(
            `You are not a member of the organization "${orgSlug}". Ask an admin for an invitation.`
          );
          setMe(meData);
          setLoading(false);
          return;
        }
        setMe(meData);
        setOrg(membership.organization);
        setRole(membership.role);
        await loadShops(membership.organization.id);
      } catch (e) {
        if (cancelled) return;
        if (e instanceof ApiRequestError && e.status === 401) {
          setError("unauthorized");
        } else {
          setError("load-failed");
          setErrorMessage(
            e instanceof Error ? e.message : "Could not load your workspace."
          );
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [orgSlug, loadShops]);

  const selectShop = useCallback(
    (id: string) => {
      setSelectedShopId(id);
      if (org) {
        try {
          window.localStorage.setItem(shopStorageKey(org.id), id);
        } catch {
          // non-fatal
        }
      }
    },
    [org]
  );

  const refreshShops = useCallback(async () => {
    if (org) await loadShops(org.id);
  }, [org, loadShops]);

  const value = useMemo<OrgContextValue>(() => {
    const selectedShop = shops.find((s) => s.id === selectedShopId) ?? null;
    return {
      loading,
      error,
      errorMessage,
      me,
      org,
      orgId: org?.id ?? null,
      orgSlug,
      role,
      shops,
      shopsLoading,
      selectedShop,
      selectShop,
      isDemo: shops.some((s) => s.mode === "demo"),
      refreshShops,
    };
  }, [
    loading,
    error,
    errorMessage,
    me,
    org,
    orgSlug,
    role,
    shops,
    shopsLoading,
    selectedShopId,
    selectShop,
    refreshShops,
  ]);

  return <OrgContext.Provider value={value}>{children}</OrgContext.Provider>;
}

export function useOrg(): OrgContextValue {
  const ctx = useContext(OrgContext);
  if (!ctx) throw new Error("useOrg must be used inside <OrgProvider>");
  return ctx;
}
