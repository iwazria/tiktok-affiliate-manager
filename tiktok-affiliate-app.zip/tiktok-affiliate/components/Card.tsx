import type { ReactNode } from "react";
import { cx } from "@/lib/format";

interface CardProps {
  title?: ReactNode;
  /** Heading level for the title. Defaults to "h3". */
  titleAs?: "h2" | "h3";
  subtitle?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  padded?: boolean;
}

/** White content card. Title renders as h2/h3 via `titleAs`. */
export function Card({
  title,
  titleAs = "h3",
  subtitle,
  actions,
  children,
  className,
  padded = true,
}: CardProps): React.JSX.Element {
  const Heading = titleAs;
  return (
    <section
      className={cx(
        "rounded-xl border border-slate-200 bg-white shadow-sm",
        padded && "p-5",
        className
      )}
    >
      {(title || subtitle || actions) && (
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            {title && (
              <Heading className="text-base font-semibold text-slate-900">
                {title}
              </Heading>
            )}
            {subtitle && (
              <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
            )}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}
