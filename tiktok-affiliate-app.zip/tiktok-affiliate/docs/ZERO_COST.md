# Zero-Cost Operation

Everything this app needs to build, run, and demo must work at **$0** — no
paid software, service, subscription, API, hosting, or tool. "Free" here means
genuinely usable at no cost: not a trial, not expiring credits, not a plan
that starts billing automatically. Terms change; **all figures below were
verified October 2026 — re-check before you deploy.**

## Chosen zero-cost stack

| Layer | Choice | Free limits (verified Oct 2026) | Payment method required? | What happens at quota | Notes |
|---|---|---|---|---|---|
| Language/runtime | Node.js 20+ (OSS) | None | No | n/a | |
| Framework | Next.js 15 (OSS, MIT) | None | No | n/a | Self-hosted or any host below |
| Database (dev) | SQLite file via Prisma | None — local file | No | n/a | Default `DATABASE_URL="file:./dev.db"`. Zero setup, zero cost |
| Database (local prod-like) | PostgreSQL 16 via Docker Compose (OSS) | None — runs on your machine | No | n/a | You provide the hardware/electricity; no backups unless you schedule them |
| Database (hosted demo, optional) | **Neon Free** | 100 CU-hours/project/mo, ~0.5–1 GB storage/project, scale-to-zero, 5 GB transfer/mo | No | Compute **suspends** until next month — no surprise bill | Preferred hosted demo DB; quota exhaustion = downtime, not charges |
| Database (hosted demo, alternative) | **Supabase Free** | 500 MB DB, 2 projects, 1 GB storage, 5 GB egress/mo, 50k MAU | No | Project **pauses after 7 days inactivity**; resumes on visit | Good for demos; not for anything needing uptime |
| Auth | Our own bcrypt sessions (lib/auth.ts) | None | No | n/a | No Auth0/Clerk — those free tiers have MAU caps and paid overages |
| Email | **None — we do not send email** | n/a | n/a | n/a | Password recovery via IdP-equivalent is out of scope until a free, opt-in mail path exists. Do not add Resend/SMTP without revisiting this doc |
| File storage (exports) | Local disk (`./storage/exports`) | Disk space you have | No | n/a | CSV exports audited; served by the app. No S3 needed at this scale |
| Background jobs | DB-backed job runner (lib/jobs.ts) | None | No | n/a | No Redis/BullMQ service needed; documented in ARCHITECTURE.md |
| Hosting (option A) | **Render Free** | 750 instance hrs/mo, 512 MB RAM, spins down after 15 min idle | Card required per some reports — verify at signup | Service sleeps; **free Postgres expires 30 days after creation** (migrate data!) | True $0 demo host; cron jobs are NOT free ($1/mo min) — use in-app scheduler instead |
| Hosting (option B) | **Vercel Hobby** | 100 GB bandwidth, 1M function invocations/mo; over-quota = **paused, not billed** | No | Project pauses until next cycle | ⚠️ ToS restricts Hobby to **personal, non-commercial** use — do not run a business on it |
| Hosting (rejected) | Fly.io | — | — | — | **No free tier for new accounts** (2-VM-hour trial only) — excluded |
| Domain + TLS | Provider subdomain (e.g. `*.onrender.com`) or `localhost` | Included | No | n/a | No custom paid domain required; TLS included by hosts |
| CI/CD | GitHub Actions (public repo) | Generous free minutes for public repos | No | n/a | |
| Logging/monitoring | Structured server logs + `/api/health` | Self-hosted | No | n/a | **No paid analytics, no error-tracking SaaS** — none is used |
| Developer tools | VS Code, npm, Prisma, Vitest (all OSS) | None | No | n/a | |

## Features disabled or limited at $0

- **Email notifications** — not implemented (would need a mail provider; even
  free tiers require a card and have sending limits). In-app notifications only.
- **Background cron on free hosts** — Render free has no cron; the app's
  DB-backed scheduler runs inside the web process instead.
- **Backups on hosted free DBs** — Neon/Supabase free include little or no
  backup; schedule your own `pg_dump` if data matters.
- **Uptime on free hosts** — Render sleeps when idle; Supabase pauses after
  7 idle days; Neon suspends at quota. Acceptable for demo, not for production.
- **Vercel Hobby for commercial use** — prohibited by ToS; a real business
  needs Pro ($20/user/mo) or a different host.
- **TikTok Shop live features** — TikTok partner registration/approval is
  outside our control; unverified capabilities stay demo-only regardless of
  hosting spend (see docs/FEATURE_MATRIX.md).

## Rules

1. Never enable billing, paid overages, or automatic upgrades.
2. If a provider can't guarantee usage *stops* instead of becoming billable
   at quota, don't use it in the zero-cost setup.
3. Re-verify this page's figures before any deployment — free tiers are
   repriced quietly and often.
4. The app must keep working locally (SQLite + `npm run dev`) even if every
   hosted free tier above disappears tomorrow.
