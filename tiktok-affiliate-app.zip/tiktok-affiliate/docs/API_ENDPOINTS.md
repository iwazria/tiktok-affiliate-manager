# TikTok Shop API Endpoints Used by This App

> Cross-checked against `lib/tiktok/endpoints.ts` (the integration agent's
> endpoint registry, 2026-10-16). The live adapter may **only** call endpoints
> marked `verified` there; anything else throws `TikTokCapabilityError`.
>
> **Scope names are PROVISIONAL** (`product.info`, `affiliate.campaign`,
> `affiliate.creator`) — confirm the exact strings in Partner Center
> (Authorization > Scopes) before going live. Affiliate paths are shaped like
> TikTok's `affiliate_partner` surface and are **not called until verified**.

Base URL: `https://open-api.tiktokglobalshop.com` · API version:
`TIKTOK_API_VERSION` (default `202309`) · Auth base:
`https://auth.tiktok-shops.com`. `{version}` in a path is replaced at request
time.

## Approval status meanings

| Status | Meaning |
|---|---|
| `verified` | Confirmed in current official docs and enabled for this app |
| `pending_approval` | Plausibly documented, but not confirmed/enabled for this app |
| `unavailable` | Not available to this app — never called |

## Endpoint map (from `lib/tiktok/endpoints.ts`)

| Key | Method | Path | Purpose | Required scope | Approval | App feature |
|---|---|---|---|---|---|---|
| `productSearch` | POST | `/product/{version}/products/search` | Paginated product catalog (body: page_size/page_number) | `product.info` | verified | Product sync + catalog |
| `productDetail` | POST | `/product/{version}/products/detail` | Full product fields | `product.info` | pending_approval | Product detail view |
| `shopInfo` | GET | `/seller/{version}/shops` | Confirm connected shop identity | — | pending_approval | Onboarding step 3, shop summary |
| `tokenGet` | POST | `/api/v2/token/get` (auth base) | Exchange auth code for access/refresh tokens (server-side; no signature) | — | verified | Seller OAuth connect |
| `tokenRefresh` | POST | `/api/v2/token/refresh` (auth base) | Refresh expiring seller access token | — | verified | Token refresh job |
| `tokenRevoke` | POST | `/api/v2/token/revoke` (auth base) | Revoke tokens on disconnect | — | pending_approval | Disconnect shop (local credential deletion always happens; remote revocation unverified) |
| `campaignCreate` | POST | `/affiliate/{version}/campaigns` | Create affiliate campaign | `affiliate.campaign` | pending_approval | Campaign create (demo: local drafts) |
| `campaignUpdate` | PATCH | `/affiliate/{version}/campaigns/{id}` | Edit campaign (confirm editable fields) | `affiliate.campaign` | pending_approval | Campaign edit |
| `campaignStatus` | POST | `/affiliate/{version}/campaigns/{id}/status` | Pause/resume/end/archive transitions | `affiliate.campaign` | pending_approval | Campaign lifecycle |
| `collaborationList` | GET | `/affiliate/{version}/campaigns/{id}/collaborations` | Invitation/collaboration status list | `affiliate.creator` | pending_approval | Collaboration tracking |
| `collaborationInvite` | POST | `/affiliate/{version}/campaigns/{id}/invitations` | Invite creator to targeted campaign | `affiliate.creator` | pending_approval | Creator invitations |
| `invitationDetail` | GET | `/affiliate/{version}/invitations/{id}` | Invitation status detail | `affiliate.creator` | pending_approval | Invitation tracking |
| `invitationResend` | POST | `/affiliate/{version}/invitations/{id}/resend` | Resend invitation | `affiliate.creator` | pending_approval | Invitations |
| `invitationCancel` | DELETE | `/affiliate/{version}/invitations/{id}` | Cancel invitation | `affiliate.creator` | pending_approval | Invitations |
| `metrics` | GET | `/affiliate/{version}/performance` | Clicks/orders/revenue/commission, quality labels, timezone | `affiliate.campaign` | pending_approval | Reports, overview dashboard |
| `creatorSearch` | GET | `/affiliate/{version}/creators/search` | Creator discovery | `affiliate.creator` | unavailable | Not built — manual creator records instead |

## Notes

- **Request signing** (`lib/tiktok/http.ts`): sort query params (excluding
  `sign`, `access_token`), concatenate `key+value`, prepend `app_key`, append
  raw body string, HMAC-SHA256 with app secret, lowercase hex. Re-verify the
  canonicalization against the current Partner Center signature docs before
  production (see `docs/ASSUMPTIONS.md`).
- **Reliability**: 15s timeout, retries with exponential backoff + full
  jitter (max 3), 429 honors `Retry-After`; only idempotent requests (GET)
  auto-retry — never POST/PUT/PATCH/DELETE.
- **Logging**: request metadata + sanitized errors only; `redactSecrets()`
  applied; raw query strings never printed.
- **Creator authorization** is reserved for the future creator portal:
  separate flow, separate tokens — never reuse seller tokens
  (`docs/ASSUMPTIONS.md` #16).
- When an endpoint is verified in Partner Center, update `endpoints.ts`
  (status → `verified`, exact path/scope), this table, and
  `docs/FEATURE_MATRIX.md` together, recording the docs URL and check date.
