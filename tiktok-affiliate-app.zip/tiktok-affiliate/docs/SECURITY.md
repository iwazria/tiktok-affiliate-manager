# Security

## Authentication model

- Email + password (bcrypt, cost 12). Sessions are server-managed:
  httpOnly, `SameSite=Lax` cookie (`tam_session`); the DB stores only a
  SHA-256 hash of the token. `Secure` flag in production.
- `getSessionUser()` (lib/auth.ts) is the single session reader; every
  protected route calls `requireUser(req)` then
  `requireOrgRole(userId, orgId, minRole)` (lib/rbac.ts).
- Role hierarchy: `owner > admin > campaign_manager > analyst > read_only`.
  Frontend hiding is cosmetic — enforcement is backend-only, on every route
  and in every background job.
- Rate limiting on login, invitations, exports, and sensitive operations
  (in-memory limiter in lib/rbac.ts; Redis in production when available).

## Organization data isolation

- Every query filters by `organizationId`. Cross-org access attempts must
  return 403/404, never data. Covered by `tests/integration/isolation.test.ts`.
- A user may belong to multiple organizations; memberships are per-org with
  independent roles.

## Encryption at rest

- TikTok tokens/credentials are encrypted with **AES-256-GCM** before
  storage (`EncryptedCredential.payload`, lib/crypto.ts). Plaintext tokens
  never touch the database, logs, or the browser.
- Key delivery: `ENCRYPTION_KEY` env var (hex or string, normalized via
  SHA-256 to 32 bytes). In production this **must** come from a managed
  secret service (e.g. the host's secret manager); the env var is only the
  delivery mechanism.
- Envelope format: `{ alg, iv, tag, data, keyVersion }` — `keyVersion` marks
  which key encrypted the row.

### Key rotation procedure

1. Generate a new 256-bit key: `openssl rand -hex 32`.
2. Store it in the secret manager; set `ENCRYPTION_KEY` to the new value and
   bump `ENCRYPTION_KEY_VERSION` (e.g. `1` → `2`).
3. Run the `credentials:rekey` job (see lib/jobs.ts): it decrypts each
   `EncryptedCredential` with the old key (looked up by `keyVersion`) and
   re-encrypts with the new key, updating `keyVersion`.
4. Verify no rows remain on the old version, then retire the old key.
5. Never log keys, and never commit them — `.env` files are git-ignored.

## Secret handling

- App secrets, access/refresh tokens, auth codes, and signing material live
  **only on the server** (`lib/tiktok/`). The browser never sees them.
- `redactSecrets()` (lib/crypto.ts) scrubs token/secret/password/code/key/
  fields from anything logged; structured server logs must pass objects
  through it.
- Never log: tokens, app secrets, authorization codes, raw credentials, or
  unnecessary personal data. API error mapping sanitizes TikTok errors before
  they reach users or logs.
- `.env.example` contains placeholder names only — no real secrets, ever.

## OAuth hardening

- `state` is generated server-side (unpredictable, single-use), bound to the
  initiating user + organization + `AuthorizationSession`, and validated on
  callback: missing/invalid/expired/reused values are rejected; user denial
  and callback errors are handled explicitly.
- Seller and creator authorization are **separate flows** with separate
  tokens — never reuse one as the other (creator flow reserved for the future
  creator portal).
- Authorization code exchange happens server-side; granted scopes are
  verified before enabling features; revoked/expired/under-scoped auth
  surfaces as a clear UI notice with remediation.

## Audit log coverage

`audit()` (lib/audit.ts) records: auth events (signup/signin/signout,
failures), shop connect/disconnect, token refresh failures, campaign
create/update/lifecycle changes, creator invitations and status changes,
team invites/role changes/removals, report/export generation, and data
deletion. Entries store redacted JSON details, actor, org, IP, timestamp.

## Data retention & deletion

- Disconnecting a shop revokes/deletes stored credentials per the supported
  TikTok flow and marks the shop `disconnected`.
- Account deletion removes the user, sessions, memberships, and orgs they
  solely own (cascades in the Prisma schema); audit entries keep the org id
  but null the actor.
- Do not collect seller/creator personal data beyond what the features need.
  Confirm TikTok's retention/deletion obligations in Partner Center
  (docs/ASSUMPTIONS.md #15).

## Vulnerability disclosure

Security issues: do not file them as public issues. Report privately to the
project maintainers with a description, impact, and reproduction steps; expect
acknowledgment within 5 business days and coordinated disclosure before any
public write-up.
