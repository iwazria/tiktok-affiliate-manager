# Assumptions Requiring Partner Center Confirmation

Numbered list of everything the team must verify in the official TikTok Shop
Partner Center documentation before claiming live functionality. Nothing here
is implemented against a guessed value.

1. **OAuth authorization URL** — the exact official seller authorization page
   URL (project default `https://auth.tiktok-shops.com` is a placeholder from
   `.env.example`, not verified).
2. **OAuth scopes** — the exact scope strings for product read, affiliate
   campaign management, creator/collaboration access, and performance metrics;
   which scopes exist per market/region.
3. **Token endpoint + lifetimes** — exact token exchange and refresh URLs,
   access-token TTL, refresh-token TTL and rotation policy, revocation endpoint.
4. **Request signing algorithm version** — canonical string construction
   (parameter sorting, concatenation order, which secrets participate),
   signature header/query placement, and the API version it applies to
   (`TIKTOK_API_VERSION=202309` in `.env.example` is a default, not verified
   current).
5. **API base URL** — whether `https://open-api.tiktokglobalshop.com` is
   correct for all target markets or region-specific hosts are required.
6. **Product endpoints** — exact paths for product search/list/detail and the
   real field set returned (status values, stock semantics, image URLs).
7. **Affiliate campaign endpoints** — whether the TikTok Shop Open API exposes
   affiliate campaign creation/management to third-party apps at all, exact
   paths, mutable fields, and status mappings (draft/scheduled/active/paused/ended).
8. **Commission terms model** — what commission types/ranges the API accepts
   (percentage vs fixed), validation rules, currency handling.
9. **Creator discovery availability** — whether any approved endpoint allows
   searching creators, which fields are filterable, and what partner approval
   tier it requires. (Assumed approval-gated; manual creator records are the
   fallback.)
10. **Invitation endpoints** — exact flow for inviting a creator to a targeted
    collaboration: required creator identifiers, idempotency/duplicate rules,
    resend/remove support, status values.
11. **Performance metrics endpoints** — which metrics exist (clicks, orders,
    revenue, commission), their quality labels (estimated/pending/final),
    reporting timezone, delay/revision semantics, and max date range.
12. **Webhook support** — whether TikTok Shop offers webhooks for auth
    revocation, invitation status, or campaign events; if not, polling via
    background jobs is the supported pattern.
13. **Rate limits** — per-endpoint quotas, headers, and retry guidance; the
    app's backoff/jitter implementation must match official guidance.
14. **Partner registration & approval** — what registration tier our app needs
    for affiliate APIs, typical approval timelines, sandbox/test-shop
    availability, and any market restrictions.
15. **Data retention & deletion obligations** — TikTok developer terms on how
    long seller/creator data may be stored and what must be deleted on
    disconnect.
16. **Creator authorization flow** — the separate creator OAuth flow, its
    scopes, and whether our app is eligible; reserved for the future creator
    portal (spec §11).

## Process

- Verify each item against the *current* official docs (not blog posts or
  cached copies); record the docs URL and check date in `docs/API_ENDPOINTS.md`.
- Until an item is verified, the corresponding capability stays
  `pending_approval`/`unverified` in `docs/FEATURE_MATRIX.md` and throws
  `TikTokCapabilityError` in live mode.
