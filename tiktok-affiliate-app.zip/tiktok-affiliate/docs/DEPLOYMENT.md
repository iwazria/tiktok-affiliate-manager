# Deployment

## Environments

| Environment | Purpose | Database | Demo mode |
|---|---|---|---|
| `development` | Local work | SQLite (`./dev.db`, zero setup) or local Postgres via Compose | On (default) |
| `staging` | Pre-release checks with demo data | Postgres (Docker Compose or hosted free tier) | On, unless testing live OAuth |
| `production` | Real sellers | Postgres | **Off** — requires TikTok app credentials + verified endpoints |

Never run `prisma/seed.ts` against production. It refuses nothing by itself —
treat `db:seed` as dev-only by convention and guard it in CI.

## Local Postgres with Docker Compose

The schema is portable (SQLite ↔ Postgres via the `provider` switch in
`prisma/schema.prisma`). Suggested `docker-compose.yml` for local Postgres:

```yaml
services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: tam
      POSTGRES_PASSWORD: tam-dev-password   # dev only; use a secret in staging/prod
      POSTGRES_DB: tiktok_affiliate
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  app:
    build: .
    depends_on: [postgres]
    environment:
      DATABASE_URL: postgresql://tam:tam-dev-password@postgres:5432/tiktok_affiliate
    ports:
      - "3000:3000"

volumes:
  pgdata:
```

Then: `docker compose up -d postgres`, set `DATABASE_URL` to the Postgres URL,
and run migrations (below).

## Environment variables

All configuration comes from env vars — see `.env.example` (placeholder
names only, never real secrets). Required in every environment:

- `DATABASE_URL` — `file:./dev.db` (dev) or `postgresql://…` (staging/prod)
- `ENCRYPTION_KEY` — 64-hex secret (`openssl rand -hex 32`); **different per
  environment**, from a managed secret service in production
- `ENCRYPTION_KEY_VERSION` — bump on rotation (see docs/SECURITY.md)
- `SESSION_SECRET` — 64-hex secret (`openssl rand -hex 32`)
- `APP_URL`, `NODE_ENV`

Live mode additionally needs `DEMO_MODE=false` plus `TIKTOK_APP_KEY`,
`TIKTOK_APP_SECRET`, `TIKTOK_REDIRECT_URI` (and the endpoints in
`docs/API_ENDPOINTS.md` verified).

## Migrations

- Development (SQLite): `npm run db:push` (schema sync, no migration history).
- Staging/Production (Postgres): `npm run db:migrate`
  (`prisma migrate dev --name <name>`); apply with `prisma migrate deploy`
  in CI/CD — never `db:push` against Postgres.
- The Dockerfile / start command should run `prisma migrate deploy` before
  `next start`.

## Backups

- **SQLite (dev):** the DB is a single file — copy `dev.db` before risky
  operations. No automated backups; acceptable for local dev only.
- **Postgres:** schedule `pg_dump` (e.g. nightly cron on the host or a
  managed-service snapshot). Keep at least 7 daily dumps off the database
  host. Test restores quarterly — an untested backup is not a backup.
- Hosted free tiers (Supabase/Neon): free plans include limited or no
  backups — see `docs/ZERO_COST.md`. Do not promise point-in-time recovery
  on a free tier.

## Rollback

1. `next start` runs a single container/image: roll back by redeploying the
   previous image/tag.
2. Database migrations are the risky part: prefer **additive, backward-
   compatible migrations** (add columns/tables; avoid renames/drops). If a
   deploy must be reverted after a destructive migration, restore from the
   pre-deploy `pg_dump` — document the migration as destructive in the PR.
3. Keep `prisma migrate` history linear; resolve conflicts before merging.

## Health checks

- `GET /api/health` (to be added by the API agent): returns
  `{ ok: true, data: { db: "up"|"down", queue: {...}, mode: "demo"|"live" } }`.
  Must not leak secrets or row counts.
- Container `HEALTHCHECK`: `CMD-SWITCH` on `/api/health` every 30s.
- Queue health: `SyncJob` rows stuck in `running` past their timeout, and
  rising `failed` counts, should page/notify — see `lib/jobs.ts` (API agent).
- Integration health: last successful TikTok sync per shop
  (`ConnectedShop.lastSyncAt`/`lastSyncStatus`) is surfaced in the UI and the
  notifications center; auth expiry triggers `shop_auth_expired` notifications.
