# Feature Availability Matrix

Legend: ✅ available · 🟡 demo-only (simulated, clearly labeled) · ⏳ pending
TikTok approval / verification · ❌ unsupported / not built.

| Feature | Live | Demo | Pending approval | Unsupported | Notes |
|---|---|---|---|---|---|
| Seller OAuth connect | ⏳ | 🟡 simulated connect | Approval: partner registration + OAuth scopes | | Demo: one-click simulated shop |
| Shop identity confirmation | ⏳ | 🟡 | Endpoint unverified | | |
| Product sync | ⏳ | 🟡 labeled demo products | Endpoint unverified | | Never edit TikTok product data unless API supports it |
| Product catalog (search/sort/filter/paginate) | ⏳ | 🟡 | | | Filters limited to fields the API returns |
| Product detail + eligibility reason | ⏳ | 🟡 | | | |
| Campaign create | ⏳ | 🟡 local + demo | Affiliate campaign endpoints unverified | | Drafts clearly marked local vs TikTok-created |
| Campaign edit / pause / resume / end / archive | ⏳ | 🟡 | Only where API supports edits | | Irreversible actions need confirmation |
| Creator discovery (TikTok search) | | | ⏳ expected approval-gated | | Manual creator records always available |
| Manual creator records + notes/tags/lists | ✅ | ✅ | | | Local data, always distinguished from TikTok data |
| Creator invitations | ⏳ | 🟡 simulated | Requires creator IDs + scopes + endpoints | | No auto-messaging; explicit user action only |
| Collaboration status tracking | ⏳ | 🟡 | Invitation status endpoints unverified | | |
| Performance metrics (clicks/orders/revenue/commission) | ⏳ | 🟡 labeled estimated/pending/final | Metrics endpoints unverified | | Never fabricate in live mode; show "Not available" |
| Reports + date ranges + CSV export | ✅ local | 🟡 demo data | Live data pending metrics endpoints | | Exports audited; role-gated |
| Notifications center | ✅ | ✅ | Live event sources pending (webhooks likely unavailable → polling) | Email notifications | In-app only; email needs opt-in + unsubscribe (not built) |
| Team management (invite/roles/remove) | ✅ | ✅ | | | Owner transfer guarded; last owner protected |
| Audit log | ✅ | ✅ | | | Auth, campaigns, invites, team, shop, exports |
| Sync jobs + token refresh | ⏳ | 🟡 simulated jobs | Live endpoints unverified | | Idempotent, bounded retries, no overlapping syncs |
| Data export / deletion | ✅ local | ✅ | | | Per retention policy in docs/SECURITY.md |
| Creator portal (creator sign-in, invitations, performance) | | | | ❌ not started | Reserved: separate creator OAuth, tokens, screens (spec §11) |

## Capability gating

UI and API routes gate every feature above through
`getCapabilities({ mode, scopes, region })` (`lib/tiktok/capabilities.ts`,
currently being built). Unavailable features render an explanation — never a
broken control. See `docs/API_ENDPOINTS.md` for the endpoint verification
tracker.
