# TikTok Shop Affiliate Manager

A web app that helps TikTok Shop **sellers** manage affiliate campaigns and
creators: connect a shop, sync products, create campaigns, invite creators,
track collaborations, view performance, manage team access — with an audit
trail on everything significant.

TikTok Shop owns its marketplace, checkout, and affiliate program data. This
app is a **management and reporting layer** around the TikTok Shop capabilities
your approved API access grants. It never pretends to control TikTok features
that aren't available through your access.

**Demo mode first:** the app runs fully without TikTok credentials using
clearly-labeled simulated data, so you can explore every screen today.

## Quick start (demo mode, zero cost)

```bash
npm install
cp .env.example .env

# generate the two secrets (paste the outputs into .env)
openssl rand -hex 32   # -> ENCRYPTION_KEY
openssl rand -hex 32   # -> SESSION_SECRET

npm run db:push    # create the SQLite schema (./dev.db)
npm run db:seed    # load labeled demo data (safe to re-run; wipes demo rows first)
npm run dev        # http://localhost:3000
```

Sign in with the demo account: **`demo@example.com` / `demo1234`**
(Demo Commerce Co org, demo shop, 8 products, 2 campaigns, 6 creators —
everything flagged `isDemo` with a demo banner on every page.)

To reset demo data: `npm run db:seed` again.

## Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `DATABASE_URL` | yes | `file:./dev.db` | SQLite file (dev) or `postgresql://…` (staging/prod) |
| `ENCRYPTION_KEY` | yes | — | 64-hex secret for AES-256-GCM token encryption (`openssl rand -hex 32`) |
| `ENCRYPTION_KEY_VERSION` | no | `1` | Bump on key rotation (see docs/SECURITY.md) |
| `SESSION_SECRET` | yes | — | 64-hex secret for sessions (`openssl rand -hex 32`) |
| `APP_URL` | no | `http://localhost:3000` | Public base URL (used for OAuth callbacks) |
| `NODE_ENV` | no | `development` | `production` enables secure cookies |
| `DEMO_MODE` | no | `true` | `false` + TikTok credentials attempts live mode |
| `TIKTOK_APP_KEY` / `TIKTOK_APP_SECRET` | live only | — | Partner Center app credentials (never in the browser) |
| `TIKTOK_REDIRECT_URI` | live only | — | OAuth callback URL registered in Partner Center |
| `TIKTOK_API_BASE` / `TIKTOK_API_VERSION` / `TIKTOK_AUTH_BASE` | no | see `.env.example` | API endpoint configuration (verify in Partner Center) |
| `RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX` | no | `60000` / `60` | Rate limits for sensitive routes |

`.env.example` contains placeholder names only — never commit real secrets.

## Production with Postgres

1. Change `provider` to `"postgresql"` in `prisma/schema.prisma`.
2. Point `DATABASE_URL` at Postgres (local Docker Compose snippet in
   `docs/DEPLOYMENT.md`, or Neon/Supabase free tier — see `docs/ZERO_COST.md`).
3. Run `prisma migrate deploy` (never `db:push` against Postgres).
4. Provide `ENCRYPTION_KEY`/`SESSION_SECRET` from a managed secret service.
5. Set `DEMO_MODE=false` only after verifying `docs/API_ENDPOINTS.md`.

## Project structure

```
app/api/**/route.ts   backend (Next.js server routes; API agent)
app/**/page.tsx       frontend pages (frontend agent)
components/           design system: Button, Card, Table, DataSourceLabel, …
lib/                  shared contracts (do not rewrite):
  config.ts           env config + isDemoMode()
  db.ts               Prisma client
  auth.ts             sessions (httpOnly cookie)
  rbac.ts             roles, requireOrgRole, rate limiting
  api.ts              ok()/fail()/zodFail() response envelope
  audit.ts            audit()
  crypto.ts           AES-256-GCM secrets + redactSecrets()
  tiktok/             provider interface, live + demo adapters (integration agent)
  jobs.ts             DB-backed job runner (API agent)
prisma/schema.prisma  relational schema (SQLite dev / Postgres prod)
prisma/seed.ts        labeled demo seed
tests/                unit + integration (vitest); see tests/README.md
docs/                 API_ENDPOINTS, FEATURE_MATRIX, ASSUMPTIONS, DEPLOYMENT,
                      SECURITY, ZERO_COST
```

Key contracts live in `ARCHITECTURE.md` — read it before changing code.

## Testing

```bash
npm test           # full suite (vitest run)
npm run test:watch # watch mode
```

- Unit tests cover crypto envelopes, RBAC ordering, API envelopes, and
  contract tests for the TikTok integration (auto-enable when `lib/tiktok/*`
  lands; skipped with a note until then).
- Integration tests use an isolated SQLite `./test.db` (created/reset
  automatically) and mock `next/headers` — never production credentials.
- See `tests/README.md` for the isolation rules and skip policy.

## Deployment

See `docs/DEPLOYMENT.md` (environments, Docker Compose, migrations, backups,
rollback, health checks).

## Feature availability

- `docs/FEATURE_MATRIX.md` — what works in Live vs Demo vs Pending approval.
- `docs/API_ENDPOINTS.md` — every TikTok endpoint the integration needs,
  with verification status (**all unverified until checked against Partner
  Center**).
- `docs/ASSUMPTIONS.md` — numbered list of items requiring Partner Center
  confirmation.

## Zero-cost summary

Local SQLite + Next.js + our own session auth + DB-backed jobs + local disk
exports = **$0, no card, no trials**. Optional hosted demo: Neon/Supabase
free DB + Render/Vercel free hosting (with the limits documented in
`docs/ZERO_COST.md`, verified Oct 2026). We send no email and use no paid
analytics. The app always works locally even if hosted free tiers change.

## Security

See `docs/SECURITY.md`: auth model, AES-256-GCM encryption + key rotation,
secret handling, OAuth hardening, audit coverage, retention/deletion, and
disclosure contact.

## Troubleshooting

**`prisma generate` / `prisma db push` fails downloading engines**
(`ECONNRESET`, hangs, or checksum errors — common behind corporate proxies or
restricted networks): download the two engine binaries with a tool that works
on your network (e.g. `curl`), then point Prisma at them:

```bash
# engine commit + platform come from the error output, e.g.:
# https://binaries.prisma.sh/all_commits/<commit>/<platform>/schema-engine.gz
# https://binaries.prisma.sh/all_commits/<commit>/<platform>/libquery_engine.so.node.gz
export PRISMA_SCHEMA_ENGINE_BINARY=/path/to/schema-engine-<platform>
export PRISMA_QUERY_ENGINE_LIBRARY=/path/to/libquery_engine-<platform>.so.node
npx prisma generate
npx prisma db push
```

The query-engine library is also loaded at runtime by `@prisma/client`, so
keep `PRISMA_QUERY_ENGINE_LIBRARY` exported (or in your shell profile) when
running the dev server.

## License

MIT — see LICENSE (to be added).
