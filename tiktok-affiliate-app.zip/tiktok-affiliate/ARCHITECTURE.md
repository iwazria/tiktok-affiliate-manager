# Architecture & Agent Contracts

Single Next.js 15 App Router app. Server routes under `app/api/**/route.ts` are
the backend. All business logic lives in `lib/`. The browser never talks to
TikTok directly.

## Mandatory contracts (all agents must follow)

### API response envelope
- Success: `NextResponse.json({ ok: true, data })` via `ok()` from `@/lib/api`.
- Failure: `{ ok: false, error: { code, message, fieldErrors? } }` via `fail()` / `zodFail()`.
- Validate ALL input server-side with zod. Never trust the client.

### Auth & RBAC
- Session: httpOnly cookie `tam_session`, `getSessionUser()` from `@/lib/auth`.
- Every protected route: `requireUser(req)` then `requireOrgRole(userId, orgId, minRole)` from `@/lib/rbac`.
- Roles: `owner > admin > campaign_manager > analyst > read_only` (see ROLE_RANK).
- Hiding a button is NOT enforcement — check on every route AND in every job.
- Org isolation: every query MUST filter by `organizationId`.

### Database
- Prisma client: `import { prisma } from "@/lib/db"`.
- External TikTok IDs (`tiktokShopId`, `tiktokProductId`, ...) are separate from internal `id`.
- Never store tokens in plain text — use `encryptSecret`/`decryptSecret` from `@/lib/crypto`.

### TikTok integration (lib/tiktok/)
- `TikTokProvider` interface is the ONLY way to reach TikTok. No `fetch()` to
  TikTok anywhere else.
- `getTikTokProvider(shop)` returns the demo adapter when `isDemoMode()` or
  `shop.mode === "demo"`, else the live adapter.
- Demo adapter: clearly labeled simulated data (`isDemo: true`, source "demo").
- Live adapter: implemented against the documented endpoint map in
  `docs/API_ENDPOINTS.md`. Anything not verified there MUST throw
  `TikTokCapabilityError` — never invent endpoints/scopes.
- Request signing, retries with backoff+jitter, and rate-limit handling live in
  `lib/tiktok/http.ts`. Secrets never leave the server, never enter logs
  (use `redactSecrets`).

### Capabilities
- `lib/tiktok/capabilities.ts` exposes `getCapabilities({ mode, scopes, region })`.
- UI and API routes gate features through it. Unavailable features render a
  clear "not available" explanation, never a broken control.

### Jobs
- `lib/jobs.ts` — small durable job runner (DB-backed via SyncJob/ExportJob).
  Jobs: product_sync, campaign_sync, collab_sync, metrics_sync, token_refresh,
  report_export, cleanup. Idempotent, bounded retries, no overlapping syncs per
  shop (advisory check on running SyncJob).

### Audit & notifications
- `audit()` from `@/lib/audit` for: auth events, campaign changes, invitations,
  team changes, shop connect/disconnect, exports.
- `notify()` for user-facing events listed in the spec §13.

### Frontend
- Components in `components/`: Button, Card, Input, Select, Badge, Table,
  EmptyState, Skeleton, Modal, Alert, DataSourceLabel.
- `DataSourceLabel` shows source + freshness for EVERY metric:
  live/delayed/stale/demo. Never show a number without its provenance.
- App shell: org/shop selector, nav (Overview, Products, Campaigns, Creators,
  Reports, Team, Settings), profile menu, sync status, notifications bell,
  help link. Responsive + keyboard accessible, visible focus states.
- Every page needs loading, empty, error, and permission-denied states.

### Demo mode
- `isDemoMode()` from `@/lib/config`. Demo banner on every page.
- Demo data seeded by `prisma/seed.ts`, all rows flagged `isDemo`.

### File ownership (avoid conflicts)
- `lib/tiktok/**` — integration agent
- `app/api/**`, `lib/jobs.ts` — API agent
- `app/**` (pages/layouts, except api), `components/**` — frontend agent
- `tests/**`, `docs/**`, `README.md` — docs/tests agent
- Shared libs already written: `lib/config.ts`, `lib/db.ts`, `lib/auth.ts`,
  `lib/rbac.ts`, `lib/api.ts`, `lib/audit.ts`, `lib/crypto.ts`,
  `prisma/schema.prisma`. Do not rewrite them; extend only if needed and note it.
