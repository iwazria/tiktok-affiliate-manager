import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  resolve: {
    // Match tsconfig paths: "@/*" -> project root
    alias: {
      "@": path.resolve(__dirname, "."),
    },
  },
  test: {
    environment: "node",
    setupFiles: ["./tests/setup.ts"],
    include: ["tests/**/*.test.ts"],
    testTimeout: 30000,
    hookTimeout: 60000,
  },
});
