/**
 * Defensive frontend types for /api responses (envelope: { ok: true, data }).
 * Fields are optional/nullable-tolerant because the API agent owns the routes;
 * pages must render graceful fallbacks when a field is missing.
 */

export type DataSource = "live" | "demo" | "manual" | "tiktok_api";
export type DataQuality = "estimated" | "pending" | "final" | "unavailable";

export interface MeResponse {
  user: { id: string; name: string; email: string };
  memberships: Array<{
    organization: { id: string; name: string; slug: string };
    role: string;
  }>;
}

export interface Shop {
  id: string;
  organizationId: string;
  tiktokShopId: string;
  shopName: string | null;
  region: string | null;
  currency: string | null;
  sellerType: string | null;
  status: string; // connected|expired|revoked|error
  mode: string; // demo|live
  connectedAt: string;
  lastSyncAt: string | null;
  lastSyncStatus: string | null;
  lastSyncError: string | null;
}

export interface CapabilityInfo {
  available: boolean;
  reason?: string;
}

/**
 * Capability record keyed by camelCase CAP keys, e.g. "campaignCreate",
 * "campaignPause", "creatorInvite", "creatorDiscovery", "productSync",
 * "performanceMetrics". Each entry: { available, reason? }.
 * From GET /api/orgs/[orgId]/shops/[shopId]/capabilities → data.capabilities,
 * and from campaign detail → data.campaign.capabilities.
 */
export type Capabilities = Record<string, CapabilityInfo>;

export interface GrantedScopeInfo {
  scope: string;
  grantedAt: string;
}

export interface ShopDetail extends Shop {
  scopes: Array<GrantedScopeInfo | string>;
  capabilities?: Capabilities;
}

export interface Paginated<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface Product {
  id: string;
  tiktokProductId: string;
  name: string;
  imageUrl: string | null;
  price: number | null;
  currency: string | null;
  status: string | null;
  stock: number | null;
  affiliateEligible: boolean;
  ineligibilityReason: string | null;
  lastSyncedAt: string;
  isDemo: boolean;
}

export type CampaignStatus =
  | "draft"
  | "scheduled"
  | "active"
  | "paused"
  | "ended"
  | "archived"
  | string;

export interface CampaignCounts {
  invited: number;
  accepted: number;
  declined: number;
  completed: number;
}

export interface Campaign {
  id: string;
  name: string;
  description: string | null;
  status: CampaignStatus;
  commissionRate: number | null;
  commissionType: string | null;
  startAt: string | null;
  endAt: string | null;
  collaborationType: string | null;
  sampleAvailable: boolean;
  targetingNotes: string | null;
  tiktokCampaignId: string | null;
  /** True when the campaign exists on TikTok Shop (list/detail return isLive). */
  isLive?: boolean;
  isDemo: boolean;
  lastError?: string | null;
  lastSyncedAt: string | null;
  createdAt: string;
  updatedAt: string;
  /** List endpoint returns productCount + collaborationCounts (not products/counts). */
  productCount?: number;
  collaborationCounts?: Record<string, number>;
  /** Detail endpoint embeds these. */
  products?: Product[];
  collaborations?: Collaboration[];
  shop?: { id: string; shopName: string | null; mode: string; status: string };
  capabilities?: Capabilities;
  /** Legacy/alternate shapes some endpoints may return. */
  counts?: CampaignCounts;
}

export interface Creator {
  id: string;
  handle: string | null;
  displayName: string | null;
  avatarUrl: string | null;
  followerCount: number | null;
  notes: string | null;
  /** API returns parsed string[]; older shapes may be JSON strings. */
  tags: string[] | string | null;
  source: string; // manual|tiktok_api
  isDemo: boolean;
  lists?: Array<{ id: string; name: string }>;
}

export interface CreatorList {
  id: string;
  name: string;
  createdAt: string;
  memberCount?: number;
}

export type CollaborationStatus =
  | "draft"
  | "sent"
  | "accepted"
  | "declined"
  | "expired"
  | "completed"
  | "cancelled"
  | string;

export interface Collaboration {
  id: string;
  status: CollaborationStatus;
  invitedAt: string | null;
  respondedAt: string | null;
  lastError: string | null;
  isDemo: boolean;
  campaign: { id: string; name: string };
  creator: Creator;
}

export interface MetricValue {
  value: number | null;
  /** "demo" | "tiktok_api" | "none" (none = not provided by the API). */
  source: DataSource | "none" | string;
  quality: DataQuality | null;
  syncedAt: string | null;
  available?: boolean;
  note?: string | null;
}

export interface ReportSummary {
  clicks: MetricValue;
  orders: MetricValue;
  revenue: MetricValue;
  commission: MetricValue;
  /** Currency is not returned by the API; use the shop's currency instead. */
  currency?: string | null;
  timezone: string;
  range: { from: string; to: string } | null;
}

export interface BreakdownMeta {
  source: DataSource | "none" | string;
  quality: DataQuality | null;
  syncedAt: string | null;
  available?: boolean;
  note?: string | null;
  timezone?: string;
}

export interface BreakdownRow {
  id?: string | null;
  key: string;
  label: string;
  clicks: number | null;
  orders: number | null;
  revenue: number | null;
  commission: number | null;
}

export interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  readAt: string | null;
  createdAt: string;
}

export interface NotificationPref {
  type: string;
  enabled: boolean;
}

export interface TeamMember {
  id: string;
  userId: string;
  email: string;
  name: string;
  role: string;
  status: string;
  createdAt: string;
}

export interface TeamInvitation {
  id: string;
  email: string;
  role: string;
  status: string;
  expiresAt: string;
  createdAt: string;
}

export interface AuditLogItem {
  id: string;
  action: string;
  entityType: string | null;
  entityId: string | null;
  details: string | null;
  actor: { name: string | null; email: string | null } | null;
  createdAt: string;
  ip: string | null;
}

export interface ExportJobItem {
  id: string;
  kind: string;
  status: "queued" | "running" | "ready" | "failed" | string;
  fileName: string | null;
  rowCount: number | null;
  error: string | null;
  createdAt: string;
  finishedAt: string | null;
}

export interface OnboardingState {
  shopConnected: boolean;
  shopConfirmed: boolean;
  productsSynced: boolean;
  firstCampaign: boolean;
  teamInvited: boolean;
  dismissed: boolean;
}
