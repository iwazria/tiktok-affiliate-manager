import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { config } from "./config";

/**
 * Token/credential encryption at rest: AES-256-GCM envelope.
 *
 * - Key comes from ENCRYPTION_KEY (hex or utf8, hashed to 32 bytes).
 * - Stored payload JSON: { alg:"aes-256-gcm", iv, tag, data, keyVersion }.
 * - Key rotation: ENCRYPTION_KEY_VERSION marks new writes; decrypt accepts
 *   any version recorded in the envelope. For rotation, set the new key with
 *   a bumped version and run the `credentials:rekey` job (see docs).
 * - In production this key MUST come from a managed secret service; the env
 *   var is only the delivery mechanism.
 */

function keyBytes(): Buffer {
  const raw = config.encryptionKey;
  if (!raw) {
    throw new Error(
      "ENCRYPTION_KEY is not set. Generate one with: openssl rand -hex 32"
    );
  }
  // Accept hex (64 chars) or raw string; normalize to 32 bytes via sha256.
  const { createHash } = require("node:crypto");
  const buf = /^[0-9a-fA-F]{64}$/.test(raw) ? Buffer.from(raw, "hex") : Buffer.from(raw, "utf8");
  return createHash("sha256").update(buf).digest();
}

export interface EncryptedEnvelope {
  alg: "aes-256-gcm";
  iv: string;
  tag: string;
  data: string;
  keyVersion: number;
}

export function encryptSecret(plaintext: string): string {
  const key = keyBytes();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  const envelope: EncryptedEnvelope = {
    alg: "aes-256-gcm",
    iv: iv.toString("base64"),
    tag: tag.toString("base64"),
    data: ciphertext.toString("base64"),
    keyVersion: config.encryptionKeyVersion,
  };
  return JSON.stringify(envelope);
}

export function decryptSecret(payload: string): string {
  const env = JSON.parse(payload) as EncryptedEnvelope;
  if (env.alg !== "aes-256-gcm") throw new Error("Unsupported encryption algorithm");
  const key = keyBytes(); // rotation: look up by env.keyVersion in a real KMS setup
  const decipher = createDecipheriv(
    "aes-256-gcm",
    key,
    Buffer.from(env.iv, "base64")
  );
  decipher.setAuthTag(Buffer.from(env.tag, "base64"));
  const plain = Buffer.concat([
    decipher.update(Buffer.from(env.data, "base64")),
    decipher.final(),
  ]);
  return plain.toString("utf8");
}

/** Redact anything that looks like a secret before logging. */
export function redactSecrets(value: unknown): unknown {
  const sensitive = /(token|secret|password|code|key|authorization)/i;
  if (typeof value === "string") {
    return sensitive.test(value) ? "[redacted]" : value;
  }
  if (Array.isArray(value)) return value.map(redactSecrets);
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = sensitive.test(k) ? "[redacted]" : redactSecrets(v);
    }
    return out;
  }
  return value;
}
