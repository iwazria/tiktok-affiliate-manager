/**
 * TikTok Shop endpoint registry.
 *
 * The live adapter may ONLY call endpoints marked "verified". Anything marked
 * "pending_approval" or "unavailable" causes the adapter to throw
 * TikTokCapabilityError — the app never invents endpoints, scopes, or
 * response shapes to work around missing approval.
 *
 * Approval status meanings:
 * - "verified":        endpoint + required scope are confirmed in the current
 *                       official TikTok Shop Partner Center documentation AND
 *                       enabled for this app.
 * - "pending_approval": the capability plausibly exists in TikTok's docs but
 *                       is not confirmed/enabled for this app (no Partner
 *                       Center access, or Affiliate API approval required).
 * - "unavailable":      not available to this app (e.g. not approved, or no
 *                       such approved capability). Never called.
 *
 * SCOPE NAMES: the scope strings below are PROVISIONAL labels used by this
 * app's capability checks and demo seed data. Confirm the exact scope names
 * in Partner Center (Authorization > Scopes) before going live.
 *
 * `{version}` in a path is replaced with TIKTOK_API_VERSION at request time.
 */

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
export type EndpointApproval = "verified" | "pending_approval" | "unavailable";

export interface TikTokEndpoint {
  key: string;
  /** Path; `{version}` is replaced with the configured API version. */
  path: string;
  method: HttpMethod;
  /** Which TikTok API surface serves it. */
  base: "api" | "auth";
  requiredScope: string;
  approval: EndpointApproval;
  /** False for operations that must never be auto-retried. */
  idempotent: boolean;
  notes: string;
}

export const ENDPOINTS: Record<string, TikTokEndpoint> = {
  // ------------------------------------------------------- products ----
  productSearch: {
    key: "productSearch",
    path: "/product/{version}/products/search",
    method: "POST",
    base: "api",
    requiredScope: "product.info",
    approval: "verified",
    idempotent: false,
    notes:
      "Documented in Partner Center Seller API > Product ('Search products'). " +
      "Request body uses page_size/page_number; response data holds products[] and total_count. " +
      "Field names in the mapper are defensive — confirm against the docs for your API version. " +
      "shop_id is passed as a common parameter per documented seller-API examples.",
  },
  productDetail: {
    key: "productDetail",
    path: "/product/{version}/products/detail",
    method: "POST",
    base: "api",
    requiredScope: "product.info",
    approval: "pending_approval",
    idempotent: false,
    notes:
      "A product-detail operation exists in the seller product docs, but the exact " +
      "path and response shape for this API version are not confirmed for this app. " +
      "Confirm in Partner Center before enabling.",
  },

  // ---------------------------------------------------------- shops ----
  shopInfo: {
    key: "shopInfo",
    path: "/seller/{version}/shops",
    method: "GET",
    base: "api",
    requiredScope: "",
    approval: "pending_approval",
    idempotent: true,
    notes:
      "Believed documented as 'Get authorized shops' in the seller authorization " +
      "docs. Confirm the path, response fields, and any required scopes in " +
      "Partner Center. Until then, shop identity comes from the OAuth token " +
      "response (seller_name / open_id), not this endpoint.",
  },

  // --------------------------------------------- affiliate campaigns ---
  // The Affiliate API requires TikTok partner/app approval that this app does
  // not have. Paths below are placeholders shaped like TikTok's documented
  // affiliate_partner surface — they are NOT called until verified.
  campaignCreate: {
    key: "campaignCreate",
    path: "/affiliate/{version}/campaigns",
    method: "POST",
    base: "api",
    requiredScope: "affiliate.campaign",
    approval: "pending_approval",
    idempotent: false,
    notes:
      "Affiliate campaign management requires TikTok Partner Center approval for " +
      "the Affiliate API. Verify the endpoint path, request/response shapes, and " +
      "exact scope names in the approved Affiliate API docs before implementing.",
  },
  campaignUpdate: {
    key: "campaignUpdate",
    path: "/affiliate/{version}/campaigns/{id}",
    method: "PATCH",
    base: "api",
    requiredScope: "affiliate.campaign",
    approval: "pending_approval",
    idempotent: false,
    notes:
      "Same approval requirement as campaignCreate. Additionally, confirm which " +
      "fields are editable after creation — TikTok restricts edits on live campaigns.",
  },
  campaignStatus: {
    key: "campaignStatus",
    path: "/affiliate/{version}/campaigns/{id}/status",
    method: "POST",
    base: "api",
    requiredScope: "affiliate.campaign",
    approval: "pending_approval",
    idempotent: false,
    notes:
      "Same approval requirement as campaignCreate. Confirm the supported " +
      "transitions (pause/resume/end/archive) in the approved docs.",
  },
  collaborationList: {
    key: "collaborationList",
    path: "/affiliate/{version}/campaigns/{id}/collaborations",
    method: "GET",
    base: "api",
    requiredScope: "affiliate.creator",
    approval: "pending_approval",
    idempotent: true,
    notes:
      "Collaboration/invitation tracking requires the approved Affiliate API. " +
      "Verify the endpoint and the invitation status values TikTok returns.",
  },
  collaborationInvite: {
    key: "collaborationInvite",
    path: "/affiliate/{version}/campaigns/{id}/invitations",
    method: "POST",
    base: "api",
    requiredScope: "affiliate.creator",
    approval: "pending_approval",
    idempotent: false,
    notes:
      "Targeted creator invitations require the approved Affiliate API plus " +
      "creator identifiers TikTok accepts. Verify duplicate-invitation rules in " +
      "the docs before implementing.",
  },
  invitationDetail: {
    key: "invitationDetail",
    path: "/affiliate/{version}/invitations/{id}",
    method: "GET",
    base: "api",
    requiredScope: "affiliate.creator",
    approval: "pending_approval",
    idempotent: true,
    notes: "Same approval requirement as collaborationInvite.",
  },
  invitationResend: {
    key: "invitationResend",
    path: "/affiliate/{version}/invitations/{id}/resend",
    method: "POST",
    base: "api",
    requiredScope: "affiliate.creator",
    approval: "pending_approval",
    idempotent: false,
    notes: "Same approval requirement as collaborationInvite.",
  },
  invitationCancel: {
    key: "invitationCancel",
    path: "/affiliate/{version}/invitations/{id}",
    method: "DELETE",
    base: "api",
    requiredScope: "affiliate.creator",
    approval: "pending_approval",
    idempotent: false,
    notes: "Same approval requirement as collaborationInvite.",
  },

  // --------------------------------------------------------- metrics ---
  metrics: {
    key: "metrics",
    path: "/affiliate/{version}/performance",
    method: "GET",
    base: "api",
    requiredScope: "affiliate.campaign",
    approval: "pending_approval",
    idempotent: true,
    notes:
      "Performance reporting requires the approved Affiliate API. Verify which " +
      "metrics (clicks/orders/revenue/commission) TikTok exposes, the supported " +
      "date ranges and breakdowns, reporting timezone, and delay/revision policy.",
  },

  // ------------------------------------------------- creator search ---
  creatorSearch: {
    key: "creatorSearch",
    path: "/affiliate/{version}/creators/search",
    method: "GET",
    base: "api",
    requiredScope: "affiliate.creator",
    approval: "unavailable",
    idempotent: true,
    notes:
      "Creator discovery is not approved for this app and is not available. " +
      "Sellers manage manually entered creator records and internal lists instead.",
  },

  // ------------------------------------------------------------ auth ---
  // Documented in Partner Center > Authorization. These use app_key/app_secret
  // query params on the auth base with NO request signature.
  tokenGet: {
    key: "tokenGet",
    path: "/api/v2/token/get",
    method: "POST",
    base: "auth",
    requiredScope: "",
    approval: "verified",
    idempotent: false,
    notes:
      "Documented seller OAuth token exchange: grant_type=authorized_code with " +
      "app_key, app_secret, auth_code. Returns access_token, refresh_token, " +
      "expiry windows, open_id, seller_name, and granted scopes.",
  },
  tokenRefresh: {
    key: "tokenRefresh",
    path: "/api/v2/token/refresh",
    method: "POST",
    base: "auth",
    requiredScope: "",
    approval: "verified",
    idempotent: false,
    notes:
      "Documented seller token refresh: grant_type=refresh_token with app_key, " +
      "app_secret, refresh_token. Rotates the token pair.",
  },
  tokenRevoke: {
    key: "tokenRevoke",
    path: "/api/v2/token/revoke",
    method: "POST",
    base: "auth",
    requiredScope: "",
    approval: "pending_approval",
    idempotent: false,
    notes:
      "A token-revoke operation is expected in the authorization docs but the " +
      "exact endpoint is not confirmed for this app. Disconnect always deletes " +
      "stored credentials locally and records that remote revocation is " +
      "unverified.",
  },
};

/** Replace the `{version}` placeholder with the configured API version. */
export function resolvePath(path: string, apiVersion: string): string {
  return path.replace("{version}", apiVersion);
}
