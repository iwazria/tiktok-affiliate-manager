/**
 * SERVER ONLY — this module handles app secrets and access tokens.
 * It must never be imported by browser code. (Runtime guard below; the
 * `server-only` package is intentionally not a dependency.)
 *
 * The ONLY place in the codebase allowed to call TikTok over HTTP.
 * Implements the TikTok Shop Open API request rules:
 *
 * ---------------------------------------------------------------------------
 * REQUEST SIGNING (per TikTok Shop Partner Center documentation)
 * ---------------------------------------------------------------------------
 * 1. Collect every query parameter EXCEPT `sign` and `access_token`.
 * 2. Sort them alphabetically by parameter name.
 * 3. Concatenate each sorted pair as `key + value` (no separators).
 * 4. For requests with a JSON body, append the raw body string.
 * 5. Prepend the app_key:  string_to_sign = app_key + concatenated + body
 * 6. sign = lowercase hex of HMAC-SHA256(key = app_secret, message = string_to_sign)
 * 7. Append `sign` (and `access_token`, when used) to the final query string.
 *    `access_token` is sent as a query parameter per the official API rules,
 *    and is added AFTER signing.
 *
 * Worked example (illustrative values):
 *   app_key    = "ttapp123"
 *   app_secret = "s3cr3t"
 *   params     = { page_size: "20", shop_id: "743186299", timestamp: "1718448000" }
 *   (sorted: page_size, shop_id, timestamp)
 *   concatenated = "page_size20" + "shop_id743186299" + "timestamp1718448000"
 *                = "page_size20shop_id743186299timestamp1718448000"
 *   body       = "" (GET request, no body)
 *   string_to_sign = "ttapp123" + "page_size20shop_id743186299timestamp1718448000" + ""
 *   sign = HMAC-SHA256(key="s3cr3t", msg="ttapp123page_size20shop_id743186299timestamp1718448000").hexdigest()
 *        = "9f2c…" (64 lowercase hex chars)
 *   final query: app_key=ttapp123&page_size=20&shop_id=743186299
 *                &timestamp=1718448000&sign=9f2c…&access_token=<token>
 *
 * IMPORTANT: reproduce this algorithm from the CURRENT Partner Center
 * "signature generation" documentation for your app before production use.
 * ---------------------------------------------------------------------------
 *
 * Reliability: 15s default timeout, retries with exponential backoff + full
 * jitter (max 3 retries), automatic retries ONLY for idempotent requests
 * (GET by default), 429 handling that honors Retry-After. Non-idempotent
 * operations (POST/PUT/PATCH/DELETE) are never retried automatically.
 *
 * Logging: only request metadata (method, path, status, duration, attempt,
 * request id) and sanitized errors are logged. Secrets never enter logs —
 * `redactSecrets` is applied and raw query strings are never printed.
 */
import { createHmac } from "node:crypto";
import { config } from "../config";
import { redactSecrets } from "../crypto";
import { TikTokApiError, mapTikTokError } from "./errors";
import type { HttpMethod } from "./endpoints";

if (typeof window !== "undefined") {
  throw new Error(
    "lib/tiktok/http.ts is server-only and must not be bundled for the browser."
  );
}

export interface TikTokHttpClientOptions {
  baseUrl: string;
  appKey: string;
  appSecret: string;
  apiVersion?: string;
  timeoutMs?: number;
  /** Number of RETRIES after the first attempt (default 3). */
  maxRetries?: number;
  /**
   * Whether to sign requests. Default true. The OAuth token endpoints on the
   * auth base use app_key/app_secret query params and no signature, so the
   * auth client is constructed with signRequests: false.
   */
  signRequests?: boolean;
}

export interface TikTokRequestOptions {
  method: HttpMethod;
  /** May contain a `{version}` placeholder, replaced with the API version. */
  path: string;
  query?: Record<string, string | number | boolean | undefined>;
  /** JSON-serialized for methods with a body. */
  body?: unknown;
  /** Sent as the `access_token` query param AFTER signing (official rule). */
  accessToken?: string;
  /** Defaults to true for GET, false otherwise. Only idempotent requests auto-retry. */
  idempotent?: boolean;
}

const DEFAULT_TIMEOUT_MS = 15_000;
const MAX_BACKOFF_MS = 10_000;
const MAX_RETRY_AFTER_S = 60;

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Exponential backoff with full jitter: random in [0, min(cap, base * 2^attempt)]. */
function backoffWithJitter(attempt: number, baseMs = 1000): number {
  const exp = Math.min(MAX_BACKOFF_MS, baseMs * 2 ** attempt);
  return Math.random() * exp;
}

function retryAfterSeconds(res: Response): number {
  const raw = res.headers.get("retry-after");
  if (!raw) return 0;
  const seconds = parseInt(raw, 10);
  if (Number.isNaN(seconds) || seconds < 0) return 0;
  return Math.min(seconds, MAX_RETRY_AFTER_S);
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Pure TikTok Shop request signer (exported for unit testing).
 *
 * Implements the canonical-string algorithm documented at the top of this
 * file: sort params (excluding `sign` and `access_token`), concatenate as
 * `key+value`, prepend app_key, append the raw body string, then
 * HMAC-SHA256 with the app secret, lowercase hex.
 *
 * The exact canonicalization MUST be re-verified against the current Partner
 * Center "signature generation" documentation before production use.
 */
export function signTikTokRequest(input: {
  appKey: string;
  appSecret: string;
  params: Record<string, string>;
  bodyString?: string;
}): string {
  const concatenated = Object.entries(input.params)
    .filter(([k]) => k !== "sign" && k !== "access_token")
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => `${k}${v}`)
    .join("");
  const stringToSign = `${input.appKey}${concatenated}${input.bodyString ?? ""}`;
  return createHmac("sha256", input.appSecret)
    .update(stringToSign, "utf8")
    .digest("hex");
}

export class TikTokHttpClient {  private readonly baseUrl: string;
  private readonly appKey: string;
  private readonly appSecret: string;
  private readonly apiVersion: string;
  private readonly timeoutMs: number;
  private readonly maxRetries: number;
  private readonly signRequests: boolean;

  constructor(opts: TikTokHttpClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/$/, "");
    this.appKey = opts.appKey;
    this.appSecret = opts.appSecret;
    this.apiVersion = opts.apiVersion ?? config.tiktok.apiVersion;
    this.timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.maxRetries = opts.maxRetries ?? 3;
    this.signRequests = opts.signRequests ?? true;
    if (this.signRequests && (!this.appKey || !this.appSecret)) {
      throw new TikTokApiError({
        code: "MISSING_APP_CREDENTIALS",
        httpStatus: 0,
        userMessage: "TikTok app credentials are not configured.",
        remediation:
          "Set TIKTOK_APP_KEY and TIKTOK_APP_SECRET, or run the app in demo mode.",
        retryable: false,
      });
    }
  }

  /** HMAC-SHA256 signature per the algorithm documented at the top of this file. */
  private signParams(params: Record<string, string>, bodyString: string): string {
    return signTikTokRequest({
      appKey: this.appKey,
      appSecret: this.appSecret,
      params,
      bodyString,
    });
  }

  private buildUrl(opts: TikTokRequestOptions): { url: string; bodyString: string } {
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const query: Record<string, string> = {
      app_key: this.appKey,
      timestamp,
    };
    for (const [k, v] of Object.entries(opts.query ?? {})) {
      if (v !== undefined) query[k] = String(v);
    }
    const hasBody =
      opts.body !== undefined &&
      (opts.method === "POST" || opts.method === "PUT" || opts.method === "PATCH");
    const bodyString = hasBody ? JSON.stringify(opts.body) : "";

    const finalQuery: Record<string, string> = { ...query };
    if (this.signRequests) {
      finalQuery.sign = this.signParams(query, bodyString);
    }
    // access_token is added AFTER signing, per the official API rules.
    if (opts.accessToken) {
      finalQuery.access_token = opts.accessToken;
    }

    const path = opts.path.replace("{version}", this.apiVersion);
    const url = `${this.baseUrl}${path}?${new URLSearchParams(finalQuery).toString()}`;
    return { url, bodyString };
  }

  private logRequest(meta: {
    method: string;
    path: string;
    httpStatus: number;
    durationMs: number;
    attempt: number;
    requestId?: string;
  }): void {
    // Metadata only — never the query string, headers, or body (may hold secrets).
    console.info("[tiktok]", JSON.stringify(redactSecrets(meta)));
  }

  private logError(meta: Record<string, unknown>, err: unknown): void {
    const sanitized =
      err instanceof TikTokApiError
        ? err.toClientShape()
        : { message: err instanceof Error ? err.message.slice(0, 200) : String(err).slice(0, 200) };
    console.error("[tiktok] request failed", JSON.stringify(redactSecrets({ ...meta, error: sanitized })));
  }

  /**
   * Perform a signed request. Returns the `data` field of the TikTok envelope
   * (or the whole parsed body when no envelope is present). Throws
   * TikTokApiError on any failure. Only idempotent requests are retried.
   */
  async request<T>(opts: TikTokRequestOptions): Promise<T> {
    const idempotent = opts.idempotent ?? opts.method === "GET";
    const maxAttempts = 1 + Math.max(0, this.maxRetries);

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const started = Date.now();
      const meta = { method: opts.method, path: opts.path, attempt };
      try {
        const { url, bodyString } = this.buildUrl(opts);
        const res = await fetchWithTimeout(
          url,
          {
            method: opts.method,
            headers: {
              "Content-Type": "application/json",
              "User-Agent": "tiktok-affiliate-manager/0.1",
            },
            body: bodyString ? bodyString : undefined,
          },
          this.timeoutMs
        );
        const durationMs = Date.now() - started;

        let parsed: unknown = null;
        try {
          parsed = await res.json();
        } catch {
          parsed = null;
        }
        const envelope = (parsed ?? {}) as {
          code?: unknown;
          message?: unknown;
          data?: unknown;
          request_id?: unknown;
        };
        const requestId =
          typeof envelope.request_id === "string" ? envelope.request_id : undefined;
        this.logRequest({ ...meta, httpStatus: res.status, durationMs, requestId });

        if (res.status === 429) {
          if (idempotent && attempt < maxAttempts) {
            const waitMs = retryAfterSeconds(res) * 1000 || backoffWithJitter(attempt);
            console.info("[tiktok] rate limited; backing off", JSON.stringify({ waitMs: Math.round(waitMs), attempt }));
            await sleep(waitMs);
            continue;
          }
          throw mapTikTokError(parsed, 429);
        }

        if (res.status >= 500 && idempotent && attempt < maxAttempts) {
          await sleep(backoffWithJitter(attempt));
          continue;
        }

        if (!res.ok) {
          throw mapTikTokError(parsed, res.status);
        }

        // TikTok-level error: HTTP 200 but code != 0.
        if (typeof envelope.code === "number" && envelope.code !== 0) {
          throw mapTikTokError(parsed, res.status);
        }

        const data = "data" in envelope ? envelope.data : parsed;
        return data as T;
      } catch (err) {
        if (err instanceof TikTokApiError) {
          this.logError(meta, err);
          throw err;
        }
        // Network failure, DNS error, or timeout (AbortError).
        const isTimeout = err instanceof Error && err.name === "AbortError";
        if (idempotent && attempt < maxAttempts) {
          await sleep(backoffWithJitter(attempt));
          continue;
        }
        const apiError = new TikTokApiError({
          code: isTimeout ? "TIMEOUT" : "NETWORK_ERROR",
          httpStatus: 0,
          userMessage: isTimeout
            ? `The TikTok request timed out after ${this.timeoutMs}ms.`
            : "Could not reach the TikTok Shop API.",
          remediation:
            "Check network connectivity and try again. Idempotent requests are retried automatically with backoff.",
          retryable: idempotent,
        });
        this.logError(meta, apiError);
        throw apiError;
      }
    }

    // Unreachable: the loop always returns or throws.
    throw new TikTokApiError({
      code: "UNKNOWN",
      httpStatus: 0,
      userMessage: "Unexpected error while contacting TikTok.",
      retryable: false,
    });
  }
}
