/**
 * ============================================================================
 * DEMO ADAPTER — SIMULATED DATA ONLY. NOT REAL TIKTOK DATA.
 * ============================================================================
 * Implements TikTokProvider with in-memory, clearly labeled demo data that
 * mirrors `prisma/seed.ts` (products p-1001..p-1008). Every payload carries
 * `source: "demo"` so the UI can always show provenance.
 *
 * Demo-only actions (invite/resend/cancel, campaign edits) simulate state
 * transitions in memory; nothing leaves this process and nothing touches
 * TikTok. Use `reset()` to restore the initial demo dataset.
 * ============================================================================
 */
import { z } from "zod";
import { TikTokCapabilityError, TikTokApiError } from "./errors";
import {
  campaignInputSchema,
  campaignPatchSchema,
  inviteCreatorInputSchema,
  metricsParamsSchema,
  type CampaignDto,
  type CampaignInput,
  type CampaignPatch,
  type CampaignStatus,
  type CampaignStatusAction,
  type CollaborationDto,
  type CreatorSearchResult,
  type InvitationStatus,
  type InviteCreatorInput,
  type ListCampaignsParams,
  type ListProductsParams,
  type MetricsParams,
  type PagedResult,
  type PerformanceMetrics,
  type PerformancePoint,
  type ProductDto,
  type ShopInfo,
  type TikTokProvider,
  type TikTokTokenSet,
} from "./types";

const IMAGE = (seed: string) => `https://picsum.photos/seed/${seed}/400/400`;
const DAY_MS = 86_400_000;

function isoDaysFromNow(days: number): string {
  return new Date(Date.now() + days * DAY_MS).toISOString();
}

function initialProducts(): ProductDto[] {
  const defs: Array<[string, string, number, string, number, boolean, string | null]> = [
    ["p-1001", "Aurora LED Desk Lamp", 34.99, "ACTIVE", 420, true, null],
    ["p-1002", "Terra Ceramic Pour-Over Set", 49.5, "ACTIVE", 180, true, null],
    ["p-1003", "Nimbus Ultralight Backpack", 79.0, "ACTIVE", 0, false, "Out of stock"],
    ["p-1004", "Solstice Vitamin C Serum", 24.99, "ACTIVE", 950, true, null],
    ["p-1005", "Echo Bamboo Toothbrush (4-pack)", 12.99, "INACTIVE", 300, false, "Product not active"],
    ["p-1006", "Vertex Mechanical Keyboard", 129.0, "ACTIVE", 75, true, null],
    ["p-1007", "Lumen Reusable Water Bottle", 19.99, "ACTIVE", 1200, true, null],
    ["p-1008", "Drift Linen Throw Blanket", 59.0, "ACTIVE", 210, true, null],
  ];
  return defs.map(([tiktokProductId, name, price, status, stock, affiliateEligible, ineligibilityReason]) => ({
    tiktokProductId,
    name,
    imageUrl: IMAGE(tiktokProductId),
    price,
    currency: "USD",
    status,
    stock,
    affiliateEligible,
    ineligibilityReason,
    source: "demo" as const,
  }));
}

function initialCampaigns(): CampaignDto[] {
  return [
    {
      id: "demo-campaign-1",
      tiktokCampaignId: "demo-campaign-1",
      name: "Spring Creator Push",
      description: "Demo campaign promoting bestsellers with mid-tier creators.",
      status: "active",
      productIds: ["p-1001", "p-1002", "p-1004", "p-1006"],
      commissionRate: 12,
      commissionType: "percentage",
      startAt: isoDaysFromNow(-20),
      endAt: isoDaysFromNow(10),
      collaborationType: "targeted",
      sampleAvailable: false,
      lastError: null,
      source: "demo",
    },
    {
      id: "demo-campaign-2",
      tiktokCampaignId: null, // local draft — not created on TikTok
      name: "Summer Launch (draft)",
      description: "Local draft — not yet created on TikTok Shop.",
      status: "draft",
      productIds: ["p-1007"],
      commissionRate: 15,
      commissionType: "percentage",
      startAt: null,
      endAt: null,
      collaborationType: null,
      sampleAvailable: false,
      lastError: null,
      source: "demo",
    },
  ];
}

function initialCollaborations(): CollaborationDto[] {
  return [
    {
      id: "demo-invite-0",
      tiktokInviteId: "demo-invite-0",
      campaignId: "demo-campaign-1",
      creatorRef: { handle: "@glowwithmia", displayName: "Mia Chen" },
      status: "accepted",
      invitedAt: isoDaysFromNow(-18),
      respondedAt: isoDaysFromNow(-16),
      source: "demo",
    },
    {
      id: "demo-invite-1",
      tiktokInviteId: "demo-invite-1",
      campaignId: "demo-campaign-1",
      creatorRef: { handle: "@desksetupdan", displayName: "Dan Park" },
      status: "sent",
      invitedAt: isoDaysFromNow(-6),
      respondedAt: null,
      source: "demo",
    },
    {
      id: "demo-invite-2",
      tiktokInviteId: "demo-invite-2",
      campaignId: "demo-campaign-1",
      creatorRef: { handle: "@trailheadtess", displayName: "Tess Alvarez" },
      status: "declined",
      invitedAt: isoDaysFromNow(-12),
      respondedAt: isoDaysFromNow(-10),
      source: "demo",
    },
    {
      id: "demo-invite-3",
      tiktokInviteId: "demo-invite-3",
      campaignId: "demo-campaign-1",
      creatorRef: { handle: "@kitchenwithkojo", displayName: "Kojo Mensah" },
      status: "completed",
      invitedAt: isoDaysFromNow(-25),
      respondedAt: isoDaysFromNow(-23),
      source: "demo",
    },
  ];
}

/** Deterministic demo metrics for `daysAgo` days in the past (mirrors seed.ts). */
function demoDayMetrics(daysAgo: number): {
  clicks: number;
  orders: number;
  revenue: number;
  commission: number;
  quality: "pending" | "final";
} {
  const wave = Math.sin(daysAgo / 4) * 0.3 + 1;
  const clicks = Math.round(180 * wave + ((daysAgo * 37) % 60));
  const orders = Math.round(clicks * 0.06);
  const revenue = +(orders * 42.5).toFixed(2);
  const commission = +(revenue * 0.12).toFixed(2);
  return { clicks, orders, revenue, commission, quality: daysAgo <= 2 ? "pending" : "final" };
}

const TERMINAL_INVITE_STATUSES: InvitationStatus[] = ["cancelled", "declined", "expired"];

/** Demo status transitions for campaigns (simulated; real rules come from TikTok). */
const CAMPAIGN_TRANSITIONS: Record<CampaignStatus, CampaignStatusAction[]> = {
  draft: ["active", "archived"],
  scheduled: ["active", "archived"],
  active: ["paused", "ended"],
  paused: ["active", "ended"],
  ended: ["archived"],
  archived: [],
};

function paginate<T>(items: T[], page: number, pageSize: number, source: "demo"): PagedResult<T> {
  const p = Math.max(1, page);
  const ps = Math.min(100, Math.max(1, pageSize));
  const total = items.length;
  return {
    items: items.slice((p - 1) * ps, p * ps),
    total,
    page: p,
    pageSize: ps,
    source,
  };
}

function validationError(fieldErrors: Record<string, string[]>): TikTokApiError {
  return new TikTokApiError({
    code: "VALIDATION_FAILED",
    httpStatus: 400,
    userMessage: "Some fields are invalid. Fix the highlighted fields and try again.",
    retryable: false,
    fieldErrors,
  });
}

function zodFieldErrors(error: z.ZodError): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  for (const issue of error.issues) {
    const key = issue.path.join(".") || "_";
    out[key] = [...(out[key] ?? []), issue.message];
  }
  return out;
}

export class DemoTikTokAdapter implements TikTokProvider {
  readonly source = "demo" as const;

  private products: ProductDto[] = [];
  private campaigns: CampaignDto[] = [];
  private collaborations: CollaborationDto[] = [];
  private draftCounter = 0;
  private inviteCounter = 100;

  constructor() {
    this.reset();
  }

  /** Restore the initial demo dataset (used by the demo reset option). */
  reset(): void {
    this.products = initialProducts();
    this.campaigns = initialCampaigns();
    this.collaborations = initialCollaborations();
    this.draftCounter = 0;
    this.inviteCounter = 100;
  }

  // ------------------------------------------------------------ shop ---
  async getAuthorizedShopInfo(): Promise<ShopInfo> {
    return {
      tiktokShopId: "demo-shop-001",
      shopName: "Demo TikTok Shop",
      region: "US",
      currency: "USD",
      sellerType: "demo",
      source: "demo",
    };
  }

  // --------------------------------------------------------- products --
  async listProducts(params: ListProductsParams): Promise<PagedResult<ProductDto>> {
    let items = [...this.products];
    const q = params.search?.trim().toLowerCase();
    if (q) {
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.tiktokProductId.toLowerCase().includes(q)
      );
    }
    if (params.status) {
      items = items.filter((p) => p.status === params.status);
    }
    if (params.eligibleOnly) {
      items = items.filter((p) => p.affiliateEligible);
    }
    return paginate(items, params.page ?? 1, params.pageSize ?? 20, "demo");
  }

  async getProduct(tiktokProductId: string): Promise<ProductDto | null> {
    return this.products.find((p) => p.tiktokProductId === tiktokProductId) ?? null;
  }

  // -------------------------------------------------------- campaigns --
  async listCampaigns(params: ListCampaignsParams): Promise<PagedResult<CampaignDto>> {
    let items = [...this.campaigns];
    const q = params.search?.trim().toLowerCase();
    if (q) items = items.filter((c) => c.name.toLowerCase().includes(q));
    if (params.status) items = items.filter((c) => c.status === params.status);
    return paginate(items, params.page ?? 1, params.pageSize ?? 20, "demo");
  }

  private findCampaign(campaignId: string): CampaignDto {
    const c = this.campaigns.find((x) => x.id === campaignId);
    if (!c) {
      throw new TikTokApiError({
        code: "CAMPAIGN_NOT_FOUND",
        httpStatus: 404,
        userMessage: "Campaign not found.",
        retryable: false,
      });
    }
    return c;
  }

  async createCampaign(input: CampaignInput): Promise<CampaignDto> {
    const parsed = campaignInputSchema.safeParse(input);
    if (!parsed.success) throw validationError(zodFieldErrors(parsed.error));
    const value = parsed.data;

    if (value.startAt && value.endAt && value.startAt >= value.endAt) {
      throw validationError({ endAt: ["End date must be after the start date."] });
    }
    for (const pid of value.productIds) {
      const product = this.products.find((p) => p.tiktokProductId === pid);
      if (!product) {
        throw new TikTokApiError({
          code: "PRODUCT_NOT_FOUND",
          httpStatus: 400,
          userMessage: `Product ${pid} was not found in the synced catalog.`,
          retryable: false,
        });
      }
      if (!product.affiliateEligible) {
        throw new TikTokApiError({
          code: "PRODUCT_INELIGIBLE",
          httpStatus: 400,
          userMessage: `Product "${product.name}" is not eligible for affiliate campaigns.`,
          remediation: product.ineligibilityReason ?? undefined,
          retryable: false,
        });
      }
    }

    // DEMO: created as a local draft; on TikTok it would be submitted via the
    // (pending-approval) affiliate campaign endpoint instead.
    this.draftCounter += 1;
    const campaign: CampaignDto = {
      id: `demo-draft-${this.draftCounter}`,
      tiktokCampaignId: null,
      name: value.name,
      description: value.description ?? null,
      status: "draft",
      productIds: value.productIds,
      commissionRate: value.commissionRate ?? null,
      commissionType: value.commissionType ?? null,
      startAt: value.startAt ?? null,
      endAt: value.endAt ?? null,
      collaborationType: value.collaborationType ?? null,
      sampleAvailable: value.sampleAvailable ?? false,
      lastError: null,
      source: "demo",
    };
    this.campaigns.push(campaign);
    return { ...campaign };
  }

  async updateCampaign(campaignId: string, patch: CampaignPatch): Promise<CampaignDto> {
    const parsed = campaignPatchSchema.safeParse(patch);
    if (!parsed.success) throw validationError(zodFieldErrors(parsed.error));
    const campaign = this.findCampaign(campaignId);

    // DEMO rule (simulates TikTok restricting edits on live campaigns):
    // only drafts, scheduled, and paused campaigns are editable.
    if (campaign.status === "active" || campaign.status === "ended" || campaign.status === "archived") {
      throw new TikTokApiError({
        code: "CAMPAIGN_NOT_EDITABLE",
        httpStatus: 400,
        userMessage: `A ${campaign.status} campaign cannot be edited. Pause it first, or end it and create a new campaign.`,
        retryable: false,
      });
    }
    const value = parsed.data;
    if (value.name !== undefined) campaign.name = value.name;
    if (value.description !== undefined) campaign.description = value.description;
    if (value.commissionRate !== undefined) campaign.commissionRate = value.commissionRate;
    if (value.startAt !== undefined) campaign.startAt = value.startAt;
    if (value.endAt !== undefined) campaign.endAt = value.endAt;
    if (value.targetingNotes !== undefined) campaign.description = value.targetingNotes;
    if (campaign.startAt && campaign.endAt && campaign.startAt >= campaign.endAt) {
      throw validationError({ endAt: ["End date must be after the start date."] });
    }
    campaign.lastError = null;
    return { ...campaign };
  }

  async setCampaignStatus(
    campaignId: string,
    status: CampaignStatusAction
  ): Promise<CampaignDto> {
    const campaign = this.findCampaign(campaignId);
    const allowed = CAMPAIGN_TRANSITIONS[campaign.status];
    if (!allowed.includes(status)) {
      throw new TikTokApiError({
        code: "INVALID_STATUS_TRANSITION",
        httpStatus: 400,
        userMessage: `Cannot move a ${campaign.status} campaign to ${status}.`,
        remediation: `Allowed transitions from ${campaign.status}: ${allowed.join(", ") || "none"}.`,
        retryable: false,
      });
    }
    campaign.status = status;
    campaign.lastError = null;
    return { ...campaign };
  }

  // --------------------------------------------------- collaborations --
  async listCollaborations(campaignId: string): Promise<CollaborationDto[]> {
    this.findCampaign(campaignId); // 404 if unknown
    return this.collaborations
      .filter((c) => c.campaignId === campaignId)
      .map((c) => ({ ...c, creatorRef: { ...c.creatorRef } }));
  }

  private findInvitation(invitationId: string): CollaborationDto {
    const inv = this.collaborations.find((x) => x.id === invitationId);
    if (!inv) {
      throw new TikTokApiError({
        code: "INVITATION_NOT_FOUND",
        httpStatus: 404,
        userMessage: "Invitation not found.",
        retryable: false,
      });
    }
    return inv;
  }

  private creatorKey(ref: { tiktokCreatorId?: string; handle?: string; displayName?: string }): string {
    return (ref.tiktokCreatorId ?? ref.handle ?? ref.displayName ?? "").toLowerCase();
  }

  async inviteCreator(campaignId: string, input: InviteCreatorInput): Promise<CollaborationDto> {
    const parsed = inviteCreatorInputSchema.safeParse(input);
    if (!parsed.success) throw validationError(zodFieldErrors(parsed.error));
    this.findCampaign(campaignId);
    const key = this.creatorKey(parsed.data.creatorRef);
    const duplicate = this.collaborations.find(
      (c) =>
        c.campaignId === campaignId &&
        this.creatorKey(c.creatorRef) === key &&
        !TERMINAL_INVITE_STATUSES.includes(c.status)
    );
    if (duplicate) {
      throw new TikTokApiError({
        code: "DUPLICATE_INVITATION",
        httpStatus: 409,
        userMessage: "This creator already has an active invitation for this campaign.",
        remediation: "Resend or cancel the existing invitation instead of creating a duplicate.",
        retryable: false,
      });
    }
    // DEMO: invitation is simulated locally; nothing is sent to TikTok.
    this.inviteCounter += 1;
    const invite: CollaborationDto = {
      id: `demo-invite-${this.inviteCounter}`,
      tiktokInviteId: `demo-invite-${this.inviteCounter}`,
      campaignId,
      creatorRef: { ...parsed.data.creatorRef },
      status: "sent",
      invitedAt: new Date().toISOString(),
      respondedAt: null,
      source: "demo",
    };
    this.collaborations.push(invite);
    return { ...invite, creatorRef: { ...invite.creatorRef } };
  }

  async getInvitationStatus(invitationId: string): Promise<CollaborationDto> {
    const inv = this.findInvitation(invitationId);
    return { ...inv, creatorRef: { ...inv.creatorRef } };
  }

  async resendInvitation(invitationId: string): Promise<CollaborationDto> {
    const inv = this.findInvitation(invitationId);
    if (inv.status !== "sent" && inv.status !== "expired") {
      throw new TikTokApiError({
        code: "INVITATION_NOT_RESENDABLE",
        httpStatus: 400,
        userMessage: `An invitation with status "${inv.status}" cannot be resent.`,
        retryable: false,
      });
    }
    inv.status = "sent";
    inv.invitedAt = new Date().toISOString();
    return { ...inv, creatorRef: { ...inv.creatorRef } };
  }

  async cancelInvitation(invitationId: string): Promise<CollaborationDto> {
    const inv = this.findInvitation(invitationId);
    if (inv.status === "accepted" || inv.status === "completed") {
      throw new TikTokApiError({
        code: "INVITATION_NOT_CANCELLABLE",
        httpStatus: 400,
        userMessage: `An invitation with status "${inv.status}" cannot be cancelled.`,
        retryable: false,
      });
    }
    inv.status = "cancelled";
    return { ...inv, creatorRef: { ...inv.creatorRef } };
  }

  // ---------------------------------------------------------- metrics --
  async getPerformanceMetrics(params: MetricsParams): Promise<PerformanceMetrics> {
    const parsed = metricsParamsSchema.safeParse(params);
    if (!parsed.success) throw validationError(zodFieldErrors(parsed.error));
    const { dateFrom, dateTo, campaignId, productId, creatorId } = parsed.data;

    const from = new Date(`${dateFrom}T00:00:00Z`).getTime();
    const to = new Date(`${dateTo}T00:00:00Z`).getTime();
    if (Number.isNaN(from) || Number.isNaN(to) || from > to) {
      throw validationError({ dateTo: ["dateTo must be on or after dateFrom."] });
    }

    // DEMO: only the seeded demo campaign has simulated metrics. Filters for
    // unknown campaigns/products/creators return empty (labeled demo) data.
    const knownCampaign = !campaignId || campaignId === "demo-campaign-1";
    const points: PerformancePoint[] = [];
    if (knownCampaign && !productId && !creatorId) {
      for (let t = from; t <= to; t += DAY_MS) {
        const daysAgo = Math.round((Date.now() - t) / DAY_MS);
        if (daysAgo < 0 || daysAgo > 60) continue;
        const m = demoDayMetrics(daysAgo);
        const date = new Date(t).toISOString().slice(0, 10);
        points.push({
          date,
          campaignId: campaignId ?? "demo-campaign-1",
          productId: null,
          creatorId: null,
          clicks: m.clicks,
          orders: m.orders,
          revenue: m.revenue,
          commission: m.commission,
          currency: "USD",
          quality: m.quality,
        });
      }
    }

    const totals = points.reduce(
      (acc, p) => ({
        clicks: (acc.clicks ?? 0) + (p.clicks ?? 0),
        orders: (acc.orders ?? 0) + (p.orders ?? 0),
        revenue: +(((acc.revenue ?? 0) + (p.revenue ?? 0)).toFixed(2)),
        commission: +(((acc.commission ?? 0) + (p.commission ?? 0)).toFixed(2)),
        currency: "USD",
      }),
      { clicks: 0, orders: 0, revenue: 0, commission: 0, currency: "USD" as string | null }
    );

    const hasPending = points.some((p) => p.quality === "pending");
    return {
      points,
      totals: points.length ? totals : { clicks: null, orders: null, revenue: null, commission: null, currency: null },
      quality: hasPending ? "pending" : "final",
      source: "demo",
      syncedAt: new Date().toISOString(),
      timezone: "UTC",
    };
  }

  // ----------------------------------------------------- creator api ---
  async searchCreators(_query: string): Promise<CreatorSearchResult[]> {
    void _query;
    throw new TikTokCapabilityError(
      "creator_search",
      "Creator search requires additional TikTok approval and is not available, including in demo mode. Add creators manually and organize them in lists.",
      "TikTok Partner Center creator-discovery approval"
    );
  }

  // ------------------------------------------------------------ tokens --
  async refreshToken(_refreshToken: string): Promise<TikTokTokenSet> {
    void _refreshToken;
    throw new TikTokCapabilityError(
      "token_refresh",
      "Token refresh is a live-only operation; demo mode stores no tokens.",
      undefined
    );
  }

  async revokeToken(_token: string): Promise<void> {
    void _token;
    // DEMO: there are no stored tokens to revoke; no-op by design.
  }
}
