/**
 * Error taxonomy for the TikTok Shop integration layer.
 *
 * - `TikTokApiError`: a request to TikTok failed. Carries a machine-readable
 *   `code`, the HTTP status, a user-readable message, actionable remediation,
 *   and whether the failure is retryable.
 * - `TikTokCapabilityError`: the feature is not approved / not verified for
 *   this app. Never invent endpoints or scopes to work around it.
 *
 * SECURITY: never include tokens, app secrets, authorization codes, or
 * personal data in errors. Messages echoed from TikTok are sanitized.
 */

/** Strip long random-looking substrings (tokens/keys) from echoed messages. */
function sanitizeMessage(message: string): string {
  return message
    .replace(/[A-Za-z0-9_\-./+=]{32,}/g, "[redacted]")
    .slice(0, 300);
}

export interface TikTokApiErrorOptions {
  code: string;
  httpStatus: number; // 0 = no HTTP response (network/timeout/config)
  userMessage: string;
  remediation?: string;
  retryable?: boolean;
  fieldErrors?: Record<string, string[]>;
}

export class TikTokApiError extends Error {
  readonly code: string;
  readonly httpStatus: number;
  readonly userMessage: string;
  readonly remediation?: string;
  readonly retryable: boolean;
  readonly fieldErrors?: Record<string, string[]>;

  constructor(opts: TikTokApiErrorOptions) {
    super(opts.userMessage);
    this.name = "TikTokApiError";
    this.code = opts.code;
    this.httpStatus = opts.httpStatus;
    this.userMessage = opts.userMessage;
    this.remediation = opts.remediation;
    this.retryable = opts.retryable ?? false;
    this.fieldErrors = opts.fieldErrors;
  }

  /** Shape safe to return to API clients (no secrets by construction). */
  toClientShape(): {
    code: string;
    message: string;
    remediation?: string;
    fieldErrors?: Record<string, string[]>;
  } {
    return {
      code: this.code,
      message: this.userMessage,
      ...(this.remediation ? { remediation: this.remediation } : {}),
      ...(this.fieldErrors ? { fieldErrors: this.fieldErrors } : {}),
    };
  }
}

export class TikTokCapabilityError extends Error {
  readonly feature: string;
  readonly reason: string;
  readonly requiredApproval?: string;

  constructor(feature: string, reason: string, requiredApproval?: string) {
    super(`${feature}: ${reason}`);
    this.name = "TikTokCapabilityError";
    this.feature = feature;
    this.reason = reason;
    this.requiredApproval = requiredApproval;
  }
}

interface TikTokErrorBody {
  code?: unknown;
  message?: unknown;
  reason?: unknown;
}

/**
 * Translate a TikTok API failure into a TikTokApiError with a user-readable
 * message and remediation.
 *
 * TikTok Shop Open API responses use `{ code, message, data, request_id }`
 * where `code: 0` means success. This mapper is intentionally conservative:
 * it keys off HTTP status (documented behavior) and only sanitizes, never
 * trusts, the echoed TikTok message. Extend the code table only with codes
 * confirmed in the current Partner Center documentation.
 */
export function mapTikTokError(
  payload: unknown,
  httpStatus: number
): TikTokApiError {
  const body = (payload ?? {}) as TikTokErrorBody;
  const code =
    typeof body.code === "number" || typeof body.code === "string"
      ? String(body.code)
      : "UNKNOWN";
  const rawMessage =
    typeof body.message === "string"
      ? body.message
      : typeof body.reason === "string"
        ? body.reason
        : undefined;
  const echoed = rawMessage ? sanitizeMessage(rawMessage) : undefined;

  const base = { code, httpStatus };

  switch (httpStatus) {
    case 400:
      return new TikTokApiError({
        ...base,
        userMessage:
          echoed ?? "TikTok rejected the request as invalid.",
        remediation:
          "Check the request parameters and try again. If this persists, verify the endpoint against the current Partner Center documentation.",
        retryable: false,
      });
    case 401:
      return new TikTokApiError({
        ...base,
        userMessage:
          "TikTok authorization failed — the access token is invalid or expired.",
        remediation:
          "Refresh the access token, or reconnect the shop in Settings to authorize again.",
        retryable: false,
      });
    case 403:
      return new TikTokApiError({
        ...base,
        userMessage:
          "TikTok denied the request — a required scope may be missing or the authorization was revoked.",
        remediation:
          "Check the granted scopes in Settings and reconnect the shop with the required scopes.",
        retryable: false,
      });
    case 404:
      return new TikTokApiError({
        ...base,
        userMessage: "The requested TikTok resource was not found.",
        remediation:
          "It may have been deleted on TikTok Shop. Sync again to refresh local data.",
        retryable: false,
      });
    case 429:
      return new TikTokApiError({
        ...base,
        userMessage: "TikTok rate limit reached.",
        remediation:
          "Wait a moment and try again. The client automatically honors TikTok's Retry-After for idempotent requests.",
        retryable: true,
      });
    default:
      break;
  }

  if (httpStatus >= 500) {
    return new TikTokApiError({
      ...base,
      userMessage: "TikTok Shop API is temporarily unavailable.",
      remediation:
        "This is usually transient. Idempotent requests are retried automatically; otherwise try again shortly.",
      retryable: true,
    });
  }

  // TikTok-level error (HTTP 200 but code != 0) or other statuses.
  return new TikTokApiError({
    ...base,
    userMessage: echoed ?? `TikTok returned an error (code ${code}).`,
    remediation:
      "Check the TikTok Partner Center documentation for this error code. If it persists, contact support with the request time.",
    retryable: false,
  });
}
