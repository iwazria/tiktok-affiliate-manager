/**
 * Feature capability registry.
 *
 * `getCapabilities({ mode, scopes, region })` tells the UI and API routes
 * which features are usable, so unavailable features render a clear "not
 * available" explanation instead of a broken control.
 *
 * Rules:
 * - demo mode: most features are available but flagged `demoOnly: true`
 *   (the UI must label demo data). `creator_search` is always unavailable —
 *   it is not approved for this app, even in demo mode.
 * - live mode: a feature is available only when the required scope was
 *   granted AND the backing endpoint is "verified" in `endpoints.ts`.
 *   Anything pending approval explains what is missing.
 *
 * `region` is accepted for future market-specific gating; it does not change
 * results today.
 */
import { config } from "../config";
import { ENDPOINTS } from "./endpoints";

export type FeatureKey =
  | "shop_connect"
  | "product_sync"
  | "campaign_create"
  | "campaign_edit"
  | "campaign_status"
  | "creator_invite"
  | "invitation_tracking"
  | "creator_search"
  | "metrics"
  | "metrics_breakdown"
  | "export";

export interface CapabilityInfo {
  available: boolean;
  /** True when the feature only works against simulated demo data. */
  demoOnly?: boolean;
  /** Human-readable explanation when unavailable (or a demo caveat). */
  reason?: string;
  requiredScope?: string;
  approval?: "verified" | "pending_approval" | "unavailable";
}

const PENDING_APPROVAL_REASON =
  "This feature needs TikTok Partner Center approval for the Affiliate API and is not enabled for this app yet.";

const FEATURE_REQUIREMENTS: Record<
  FeatureKey,
  { scope?: string; endpointKey?: string }
> = {
  shop_connect: {},
  product_sync: { scope: "product.info", endpointKey: "productSearch" },
  campaign_create: { scope: "affiliate.campaign", endpointKey: "campaignCreate" },
  campaign_edit: { scope: "affiliate.campaign", endpointKey: "campaignUpdate" },
  campaign_status: { scope: "affiliate.campaign", endpointKey: "campaignStatus" },
  creator_invite: { scope: "affiliate.creator", endpointKey: "collaborationInvite" },
  invitation_tracking: { scope: "affiliate.creator", endpointKey: "collaborationList" },
  creator_search: { endpointKey: "creatorSearch" },
  metrics: { scope: "affiliate.campaign", endpointKey: "metrics" },
  metrics_breakdown: { scope: "affiliate.campaign", endpointKey: "metrics" },
  export: {},
};

function liveCapability(key: FeatureKey, scopes: string[]): CapabilityInfo {
  if (key === "export") {
    // Local feature (CSV generation); role-gated at the route level.
    return { available: true };
  }
  if (key === "shop_connect") {
    const configured = Boolean(config.tiktok.appKey && config.tiktok.appSecret);
    return configured
      ? { available: true }
      : {
          available: false,
          reason:
            "TikTok app credentials are not configured (TIKTOK_APP_KEY / TIKTOK_APP_SECRET).",
        };
  }
  if (key === "creator_search") {
    const ep = ENDPOINTS.creatorSearch;
    return {
      available: false,
      approval: "unavailable",
      reason:
        "Creator search requires additional TikTok approval and is not available. " +
        "Add creators manually and organize them in lists instead.",
      requiredScope: ep.requiredScope,
    };
  }

  const req = FEATURE_REQUIREMENTS[key];
  if (req.scope && !scopes.includes(req.scope)) {
    return {
      available: false,
      requiredScope: req.scope,
      reason: `Requires the TikTok scope "${req.scope}". Reconnect the shop and grant this scope.`,
    };
  }
  const ep = req.endpointKey ? ENDPOINTS[req.endpointKey] : undefined;
  if (ep && ep.approval !== "verified") {
    return {
      available: false,
      requiredScope: req.scope,
      approval: ep.approval,
      reason: PENDING_APPROVAL_REASON,
    };
  }
  return { available: true, requiredScope: req.scope };
}

function demoCapability(key: FeatureKey): CapabilityInfo {
  if (key === "creator_search") {
    return {
      available: false,
      demoOnly: true,
      approval: "unavailable",
      reason:
        "Creator search requires additional TikTok approval and is not available, including in demo mode. " +
        "Add creators manually and organize them in lists instead.",
    };
  }
  if (key === "export") {
    return { available: true };
  }
  return {
    available: true,
    demoOnly: true,
    reason: "Demo data — not real TikTok Shop data.",
  };
}

export interface CapabilityInput {
  mode: "demo" | "live";
  /** Granted TikTok scopes for the shop (from GrantedScope rows). */
  scopes: string[];
  /** Market/region code, e.g. "US". Reserved for future market gating. */
  region?: string | null;
}

export function getCapabilities(
  input: CapabilityInput
): Record<FeatureKey, CapabilityInfo> {
  const keys = Object.keys(FEATURE_REQUIREMENTS) as FeatureKey[];
  const out = {} as Record<FeatureKey, CapabilityInfo>;
  for (const key of keys) {
    out[key] = input.mode === "demo" ? demoCapability(key) : liveCapability(key, input.scopes);
  }
  return out;
}
