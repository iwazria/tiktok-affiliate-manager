/**
 * SERVER ONLY — holds a decrypted access token in memory for the duration of
 * a request/job. Never import from browser code, never log the token.
 *
 * Implements TikTokProvider against the endpoint registry in `endpoints.ts`
 * using the signed client in `http.ts`. Only endpoints marked "verified" are
 * called; everything else throws TikTokCapabilityError with a clear message.
 *
 * Honesty rules:
 * - No invented endpoints, scopes, metrics, or response fields.
 * - Response mapping is defensive: unknown fields become null, never
 *   fabricated values.
 * - The access token is passed as the `access_token` query parameter AFTER
 *   signing, per the official API rules (handled inside http.ts).
 */
import { config } from "../config";
import { TikTokHttpClient } from "./http";
import { ENDPOINTS, resolvePath, type TikTokEndpoint } from "./endpoints";
import { TikTokApiError, TikTokCapabilityError } from "./errors";
import { refreshTokenSet } from "./oauth";
import type {
  CampaignDto,
  CampaignPatch,
  CampaignStatusAction,
  CollaborationDto,
  CreatorSearchResult,
  DataSource,
  InviteCreatorInput,
  ListCampaignsParams,
  ListProductsParams,
  MetricsParams,
  PagedResult,
  PerformanceMetrics,
  ProductDto,
  ShopInfo,
  TikTokProvider,
  TikTokTokenSet,
  CampaignInput,
} from "./types";

if (typeof window !== "undefined") {
  throw new Error(
    "lib/tiktok/liveAdapter.ts is server-only and must not be bundled for the browser."
  );
}

export interface LiveAdapterOptions {
  shopId: string;
  tiktokShopId: string;
  accessToken: string;
}

/** Raw shape of the product-search response (defensive — fields confirmed per API version). */
interface TikTokProductSearchData {
  products?: Array<Record<string, unknown>>;
  total_count?: number;
}

function asString(v: unknown): string | null {
  return typeof v === "string" ? v : null;
}
function asNumber(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

/**
 * Map a raw TikTok product to our DTO. Unknown fields become null — never
 * fabricated. Affiliate eligibility is NOT returned by the product search
 * endpoint; it stays false until the (pending-approval) affiliate eligibility
 * check is verified and implemented.
 */
function mapProduct(raw: Record<string, unknown>): ProductDto {
  const id = asString(raw["id"]);
  if (!id) {
    throw new TikTokApiError({
      code: "INVALID_PRODUCT_RESPONSE",
      httpStatus: 502,
      userMessage: "TikTok returned a product without an id.",
      retryable: false,
    });
  }
  return {
    tiktokProductId: id,
    name: asString(raw["name"]) ?? asString(raw["title"]) ?? "Untitled product",
    imageUrl: asString(raw["main_image"]) ?? asString(raw["image_url"]) ?? asString(raw["cover"]),
    price: asNumber(raw["price"]) ?? asNumber(raw["sale_price"]),
    currency: asString(raw["currency"]),
    status: asString(raw["status"]),
    stock: asNumber(raw["stock"]) ?? asNumber(raw["inventory"]),
    affiliateEligible: false,
    ineligibilityReason: "Affiliate eligibility is not returned by the product search API; pending TikTok Affiliate API approval.",
    source: "tiktok",
  };
}

export class LiveTikTokAdapter implements TikTokProvider {
  readonly source: DataSource = "tiktok";

  private readonly http: TikTokHttpClient;
  private readonly accessToken: string;
  private readonly tiktokShopId: string;

  constructor(opts: LiveAdapterOptions) {
    if (!opts.accessToken) {
      throw new TikTokApiError({
        code: "MISSING_CREDENTIAL",
        httpStatus: 401,
        userMessage: "No access token available for this live shop.",
        remediation: "Reconnect the shop in Settings to authorize again.",
        retryable: false,
      });
    }
    this.accessToken = opts.accessToken;
    this.tiktokShopId = opts.tiktokShopId;
    this.http = new TikTokHttpClient({
      baseUrl: config.tiktok.apiBase,
      appKey: config.tiktok.appKey,
      appSecret: config.tiktok.appSecret,
      apiVersion: config.tiktok.apiVersion,
    });
  }

  /**
   * Gate every endpoint through the registry. Anything not "verified" throws
   * TikTokCapabilityError — never invent the call.
   */
  private requireEndpoint(key: string): TikTokEndpoint {
    const ep = ENDPOINTS[key];
    if (!ep) {
      throw new TikTokApiError({
        code: "UNKNOWN_ENDPOINT",
        httpStatus: 0,
        userMessage: `Unknown TikTok endpoint key: ${key}.`,
        retryable: false,
      });
    }
    if (ep.approval !== "verified") {
      throw new TikTokCapabilityError(
        ep.key,
        ep.approval === "unavailable"
          ? ep.notes
          : `This feature is not enabled for this app yet. ${ep.notes}`,
        ep.approval === "unavailable" ? undefined : "TikTok Partner Center approval"
      );
    }
    return ep;
  }

  private path(ep: TikTokEndpoint, id?: string): string {
    const resolved = resolvePath(ep.path, config.tiktok.apiVersion);
    return id ? resolved.replace("{id}", encodeURIComponent(id)) : resolved;
  }

  /**
   * For endpoints that are not verified: the registry gate throws
   * TikTokCapabilityError. `never` keeps call sites honest — there is no
   * fallback that invents the TikTok call.
   */
  private unverified(key: string): never {
    this.requireEndpoint(key); // always throws for pending/unavailable keys
    throw new TikTokApiError({
      code: "UNREACHABLE",
      httpStatus: 0,
      userMessage: "Unexpected: endpoint gate did not throw.",
      retryable: false,
    });
  }

  // ------------------------------------------------------------ shop ---
  async getAuthorizedShopInfo(): Promise<ShopInfo> {
    // shopInfo is pending_approval: shop identity in live mode comes from the
    // OAuth token response (seller_name/open_id), captured at connect time.
    const ep = this.requireEndpoint("shopInfo");
    const data = await this.http.request<Record<string, unknown>>({
      method: ep.method,
      path: this.path(ep),
      accessToken: this.accessToken,
      idempotent: ep.idempotent,
    });
    return {
      tiktokShopId: asString(data["shop_id"]) ?? this.tiktokShopId,
      shopName: asString(data["shop_name"]),
      region: asString(data["region"]),
      currency: asString(data["currency"]),
      sellerType: asString(data["seller_type"]),
      source: "tiktok",
    };
  }

  // --------------------------------------------------------- products --
  async listProducts(params: ListProductsParams): Promise<PagedResult<ProductDto>> {
    const ep = this.requireEndpoint("productSearch");
    const page = Math.max(1, params.page ?? 1);
    const pageSize = Math.min(100, Math.max(1, params.pageSize ?? 20));
    const data = await this.http.request<TikTokProductSearchData>({
      method: ep.method,
      path: this.path(ep),
      // shop_id is a common seller-API parameter per documented examples.
      query: { shop_id: this.tiktokShopId },
      body: {
        page_size: pageSize,
        page_number: page,
        // Server-side search/status filters depend on documented request
        // fields for this API version — confirm in Partner Center before
        // adding them. Filtering below is on the returned page only.
      },
      accessToken: this.accessToken,
      idempotent: ep.idempotent,
    });
    let items = (data.products ?? []).map(mapProduct);
    const q = params.search?.trim().toLowerCase();
    if (q) {
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.tiktokProductId.toLowerCase().includes(q)
      );
    }
    if (params.status) {
      items = items.filter((p) => p.status === params.status);
    }
    if (params.eligibleOnly) {
      items = items.filter((p) => p.affiliateEligible);
    }
    return {
      items,
      total: typeof data.total_count === "number" ? data.total_count : items.length,
      page,
      pageSize,
      source: "tiktok",
    };
  }

  async getProduct(tiktokProductId: string): Promise<ProductDto | null> {
    // productDetail is pending_approval — the registry gate throws.
    this.unverified("productDetail");
  }

  // -------------------------------------------------------- campaigns --
  async listCampaigns(_params: ListCampaignsParams): Promise<PagedResult<CampaignDto>> {
    void _params;
    // Representative gate: the whole affiliate surface is pending approval.
    this.unverified("campaignCreate");
  }

  async createCampaign(_input: CampaignInput): Promise<CampaignDto> {
    void _input;
    this.unverified("campaignCreate");
  }

  async updateCampaign(_campaignId: string, _patch: CampaignPatch): Promise<CampaignDto> {
    void _campaignId;
    void _patch;
    this.unverified("campaignUpdate");
  }

  async setCampaignStatus(
    _campaignId: string,
    _status: CampaignStatusAction
  ): Promise<CampaignDto> {
    void _campaignId;
    void _status;
    this.unverified("campaignStatus");
  }

  // --------------------------------------------------- collaborations --
  async listCollaborations(_campaignId: string): Promise<CollaborationDto[]> {
    void _campaignId;
    this.unverified("collaborationList");
  }

  async inviteCreator(_campaignId: string, _input: InviteCreatorInput): Promise<CollaborationDto> {
    void _campaignId;
    void _input;
    this.unverified("collaborationInvite");
  }

  async getInvitationStatus(_invitationId: string): Promise<CollaborationDto> {
    void _invitationId;
    this.unverified("invitationDetail");
  }

  async resendInvitation(_invitationId: string): Promise<CollaborationDto> {
    void _invitationId;
    this.unverified("invitationResend");
  }

  async cancelInvitation(_invitationId: string): Promise<CollaborationDto> {
    void _invitationId;
    this.unverified("invitationCancel");
  }

  // ---------------------------------------------------------- metrics --
  async getPerformanceMetrics(_params: MetricsParams): Promise<PerformanceMetrics> {
    void _params;
    this.unverified("metrics");
  }

  // ----------------------------------------------------- creator api ---
  async searchCreators(_query: string): Promise<CreatorSearchResult[]> {
    void _query;
    // creatorSearch is "unavailable" — the registry gate throws.
    this.unverified("creatorSearch");
  }

  // ------------------------------------------------------------ tokens --
  async refreshToken(refreshToken: string): Promise<TikTokTokenSet> {
    return refreshTokenSet(refreshToken);
  }

  async revokeToken(_token: string): Promise<void> {
    void _token;
    // tokenRevoke is pending_approval — the registry gate throws.
    this.unverified("tokenRevoke");
  }
}
