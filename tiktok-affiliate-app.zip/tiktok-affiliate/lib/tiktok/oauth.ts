/**
 * SERVER ONLY — handles authorization codes, tokens, and credentials.
 * Never import from browser code.
 *
 * Seller OAuth flow (per TikTok Shop Partner Center authorization docs):
 *  1. `createAuthorizationSession` — generates a secure, unpredictable,
 *     single-use `state` (32 random bytes; only the SHA-256 hash is stored),
 *     bound to the initiating user + organization with a 10-minute expiry,
 *     and returns the official authorization URL.
 *  2. The user authorizes on TikTok and is redirected back with `code`+`state`.
 *  3. `validateCallback` — rejects missing/invalid/expired/reused states and
 *     handles user denial, then marks the session completed (single use).
 *  4. `exchangeCodeForTokens` — exchanges the code server-side via http.ts.
 *  5. `storeTokens` — stores tokens encrypted at rest (AES-256-GCM envelopes
 *     via `encryptSecret`) plus the granted scopes.
 *
 * Seller and creator authorization are SEPARATE flows with separate
 * credentials. Creator authorization is not approved for this app:
 * `createAuthorizationSession(..., "creator")` throws TikTokCapabilityError.
 * Never reuse seller tokens as creator tokens or vice versa.
 */
import { randomBytes, createHash } from "node:crypto";
import { prisma } from "../db";
import { config, isDemoMode } from "../config";
import { encryptSecret, decryptSecret } from "../crypto";
import { audit, notify } from "../audit";
import { TikTokHttpClient } from "./http";
import { ENDPOINTS } from "./endpoints";
import { TikTokApiError, TikTokCapabilityError } from "./errors";
import type { TikTokTokenSet } from "./types";

if (typeof window !== "undefined") {
  throw new Error(
    "lib/tiktok/oauth.ts is server-only and must not be bundled for the browser."
  );
}

const STATE_BYTES = 32;
const STATE_TTL_MS = 10 * 60 * 1000; // 10 minutes

function sha256Hex(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

/** Build a client for the auth base (token endpoints use no request signature). */
function authClient(): TikTokHttpClient {
  return new TikTokHttpClient({
    baseUrl: config.tiktok.authBase,
    appKey: config.tiktok.appKey,
    appSecret: config.tiktok.appSecret,
    signRequests: false,
  });
}

/**
 * Validate and normalize a token response from TikTok. The documented shape is
 * `{ access_token, access_token_expire_in, refresh_token,
 * refresh_token_expire_in, open_id?, seller_name?, granted_scopes? }`.
 */
export function tokenSetFromResponse(data: unknown): TikTokTokenSet {
  const d = (data ?? {}) as Record<string, unknown>;
  const str = (v: unknown): string | undefined =>
    typeof v === "string" && v.length > 0 ? v : undefined;
  const num = (v: unknown): number | undefined =>
    typeof v === "number" && Number.isFinite(v) ? v : undefined;

  const accessToken = str(d["access_token"]);
  const refreshToken = str(d["refresh_token"]);
  if (!accessToken || !refreshToken) {
    throw new TikTokApiError({
      code: "INVALID_TOKEN_RESPONSE",
      httpStatus: 502,
      userMessage: "TikTok returned an invalid token response.",
      remediation: "Try the authorization flow again. If it persists, check TikTok's service status.",
      retryable: false,
    });
  }
  const grantedScopes = Array.isArray(d["granted_scopes"])
    ? (d["granted_scopes"] as unknown[]).filter((s): s is string => typeof s === "string")
    : undefined;
  return {
    accessToken,
    accessTokenExpiresIn: num(d["access_token_expire_in"]) ?? 0,
    refreshToken,
    refreshTokenExpiresIn: num(d["refresh_token_expire_in"]) ?? 0,
    openId: str(d["open_id"]),
    sellerName: str(d["seller_name"]),
    grantedScopes,
  };
}

export interface CreateAuthSessionResult {
  sessionId: string;
  authUrl: string;
  /** Raw state value — send to the browser; only its SHA-256 hash is stored. */
  state: string;
  expiresAt: Date;
}

/**
 * Start a seller authorization session. Throws TikTokCapabilityError when
 * OAuth is unavailable (demo mode, missing credentials, or creator kind).
 */
export async function createAuthorizationSession(
  organizationId: string,
  userId: string,
  kind: "seller" | "creator" = "seller"
): Promise<CreateAuthSessionResult> {
  if (kind === "creator") {
    throw new TikTokCapabilityError(
      "creator_authorization",
      "Creator authorization is not available yet — it requires separate TikTok approval and uses separate credentials from seller authorization.",
      "TikTok Partner Center creator authorization approval"
    );
  }
  if (isDemoMode()) {
    throw new TikTokCapabilityError(
      "shop_connect",
      "TikTok authorization is disabled while the app runs in demo mode. Configure TikTok app credentials and disable demo mode to connect a real shop.",
      undefined
    );
  }
  if (!config.tiktok.appKey || !config.tiktok.appSecret) {
    throw new TikTokCapabilityError(
      "shop_connect",
      "TikTok app credentials are not configured (TIKTOK_APP_KEY / TIKTOK_APP_SECRET).",
      undefined
    );
  }

  const state = randomBytes(STATE_BYTES).toString("base64url");
  const expiresAt = new Date(Date.now() + STATE_TTL_MS);
  const session = await prisma.authorizationSession.create({
    data: {
      organizationId,
      userId,
      kind,
      state: sha256Hex(state),
      status: "pending",
      expiresAt,
    },
  });

  const params = new URLSearchParams({
    app_key: config.tiktok.appKey,
    state,
  });
  if (config.tiktok.redirectUri) {
    params.set("redirect_uri", config.tiktok.redirectUri);
  }
  const authUrl = `${config.tiktok.authBase}/oauth/authorize?${params.toString()}`;

  await audit({
    organizationId,
    actorId: userId,
    action: "shop.auth_started",
    entityType: "authorization_session",
    entityId: session.id,
    details: { kind },
  });

  return { sessionId: session.id, authUrl, state, expiresAt };
}

export interface CallbackInput {
  state?: string | null;
  code?: string | null;
  /** TikTok signals denial via an `error` redirect parameter. */
  error?: string | null;
  errorDescription?: string | null;
  /** Bind the callback to the expected org/user to prevent session fixation. */
  expectedOrgId?: string;
  expectedUserId?: string;
}

export interface ValidatedCallback {
  sessionId: string;
  organizationId: string;
  userId: string;
  code: string;
}

function invalidStateError(reason: string): TikTokApiError {
  return new TikTokApiError({
    code: "INVALID_STATE",
    httpStatus: 400,
    userMessage: reason,
    remediation: "Start the shop connection flow again from Settings.",
    retryable: false,
  });
}

/**
 * Validate the OAuth redirect callback. Rejects missing, invalid, expired,
 * or reused states; handles user denial and missing codes.
 */
export async function validateCallback(input: CallbackInput): Promise<ValidatedCallback> {
  const { state } = input;
  if (!state) {
    throw invalidStateError("Missing authorization state in the TikTok callback.");
  }
  const session = await prisma.authorizationSession.findUnique({
    where: { state: sha256Hex(state) },
  });
  if (!session) {
    // Either forged, or already consumed (single-use).
    throw invalidStateError(
      "Invalid or already-used authorization state. Please start the connection flow again."
    );
  }
  if (input.expectedOrgId && session.organizationId !== input.expectedOrgId) {
    throw invalidStateError("This authorization session does not belong to your organization.");
  }
  if (input.expectedUserId && session.userId !== input.expectedUserId) {
    throw invalidStateError("This authorization session was started by a different user.");
  }
  if (session.status !== "pending") {
    throw invalidStateError(
      "This authorization link has already been used. Please start the connection flow again."
    );
  }
  if (session.expiresAt.getTime() <= Date.now()) {
    await prisma.authorizationSession.update({
      where: { id: session.id },
      data: { status: "expired" },
    });
    await audit({
      organizationId: session.organizationId,
      actorId: session.userId,
      action: "shop.auth_expired",
      entityType: "authorization_session",
      entityId: session.id,
    });
    throw invalidStateError("The authorization session expired. Please start the connection flow again.");
  }

  if (input.error) {
    await prisma.authorizationSession.update({
      where: { id: session.id },
      data: {
        status: "denied",
        error: input.errorDescription ?? input.error,
      },
    });
    await audit({
      organizationId: session.organizationId,
      actorId: session.userId,
      action: "shop.auth_denied",
      entityType: "authorization_session",
      entityId: session.id,
      details: { error: input.error },
    });
    throw new TikTokApiError({
      code: "USER_DENIED",
      httpStatus: 403,
      userMessage: "Authorization was not granted on TikTok. The shop was not connected.",
      remediation: "Start the connection flow again and approve the requested permissions on TikTok.",
      retryable: false,
    });
  }

  if (!input.code) {
    await prisma.authorizationSession.update({
      where: { id: session.id },
      data: { status: "error", error: "missing_code" },
    });
    throw new TikTokApiError({
      code: "MISSING_AUTH_CODE",
      httpStatus: 400,
      userMessage: "TikTok did not return an authorization code.",
      remediation: "Start the connection flow again.",
      retryable: false,
    });
  }

  // Single-use: mark completed before exchanging, so a replayed callback fails.
  await prisma.authorizationSession.update({
    where: { id: session.id },
    data: { status: "completed", completedAt: new Date() },
  });
  await audit({
    organizationId: session.organizationId,
    actorId: session.userId,
    action: "shop.auth_completed",
    entityType: "authorization_session",
    entityId: session.id,
  });

  return {
    sessionId: session.id,
    organizationId: session.organizationId,
    userId: session.userId,
    code: input.code,
  };
}

/**
 * Exchange a short-lived authorization code for tokens (server-side only).
 * Live only — demo mode has no TikTok credentials.
 */
export async function exchangeCodeForTokens(code: string): Promise<TikTokTokenSet> {
  if (isDemoMode()) {
    throw new TikTokCapabilityError(
      "shop_connect",
      "Token exchange is a live-only operation; demo mode has no TikTok credentials.",
      undefined
    );
  }
  const ep = ENDPOINTS.tokenGet;
  const data = await authClient().request<unknown>({
    method: ep.method,
    path: ep.path,
    query: {
      app_key: config.tiktok.appKey,
      app_secret: config.tiktok.appSecret,
      auth_code: code,
      grant_type: "authorized_code",
    },
    idempotent: false,
  });
  return tokenSetFromResponse(data);
}

/** Live token refresh against the verified token-refresh endpoint. */
export async function refreshTokenSet(refreshToken: string): Promise<TikTokTokenSet> {
  const ep = ENDPOINTS.tokenRefresh;
  const data = await authClient().request<unknown>({
    method: ep.method,
    path: ep.path,
    query: {
      app_key: config.tiktok.appKey,
      app_secret: config.tiktok.appSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    },
    idempotent: false,
  });
  return tokenSetFromResponse(data);
}

/**
 * Store a token set encrypted at rest, replacing prior credentials and
 * granted scopes for the shop. Verifies the response carries tokens before
 * enabling anything (callers check grantedScopes via capabilities).
 */
export async function storeTokens(shopId: string, tokens: TikTokTokenSet): Promise<void> {
  const now = Date.now();
  const accessExpiresAt = new Date(now + tokens.accessTokenExpiresIn * 1000);
  const refreshExpiresAt = new Date(now + tokens.refreshTokenExpiresIn * 1000);

  await prisma.$transaction([
    prisma.encryptedCredential.upsert({
      where: { shopId_kind: { shopId, kind: "seller_access" } },
      update: {
        payload: encryptSecret(tokens.accessToken),
        expiresAt: accessExpiresAt,
        keyVersion: config.encryptionKeyVersion,
      },
      create: {
        shopId,
        kind: "seller_access",
        payload: encryptSecret(tokens.accessToken),
        expiresAt: accessExpiresAt,
        keyVersion: config.encryptionKeyVersion,
      },
    }),
    prisma.encryptedCredential.upsert({
      where: { shopId_kind: { shopId, kind: "seller_refresh" } },
      update: {
        payload: encryptSecret(tokens.refreshToken),
        expiresAt: refreshExpiresAt,
        keyVersion: config.encryptionKeyVersion,
      },
      create: {
        shopId,
        kind: "seller_refresh",
        payload: encryptSecret(tokens.refreshToken),
        expiresAt: refreshExpiresAt,
        keyVersion: config.encryptionKeyVersion,
      },
    }),
    prisma.grantedScope.deleteMany({ where: { shopId } }),
  ]);

  if (tokens.grantedScopes && tokens.grantedScopes.length > 0) {
    await prisma.grantedScope.createMany({
      data: tokens.grantedScopes.map((scope) => ({ shopId, scope })),
    });
  }

  await prisma.connectedShop.update({
    where: { id: shopId },
    data: { status: "connected", lastSyncError: null },
  });
}

/**
 * Refresh a shop's access token using the stored (encrypted) refresh token.
 * Tracks expiry; on revoked/expired refresh credentials the shop is marked
 * expired and a notification is raised so the owner can reconnect.
 */
export async function refreshAccessToken(shopId: string): Promise<TikTokTokenSet> {
  const shop = await prisma.connectedShop.findUnique({ where: { id: shopId } });
  if (!shop) {
    throw new TikTokApiError({
      code: "SHOP_NOT_FOUND",
      httpStatus: 404,
      userMessage: "Connected shop not found.",
      retryable: false,
    });
  }
  const cred = await prisma.encryptedCredential.findUnique({
    where: { shopId_kind: { shopId, kind: "seller_refresh" } },
  });
  if (!cred) {
    throw new TikTokApiError({
      code: "MISSING_CREDENTIAL",
      httpStatus: 401,
      userMessage: "No stored refresh token for this shop.",
      remediation: "Reconnect the shop in Settings to authorize again.",
      retryable: false,
    });
  }
  let refreshToken: string;
  try {
    refreshToken = decryptSecret(cred.payload);
  } catch {
    throw new TikTokApiError({
      code: "CREDENTIAL_DECRYPT_FAILED",
      httpStatus: 500,
      userMessage: "The stored credential could not be decrypted.",
      remediation: "Check ENCRYPTION_KEY / key rotation, then reconnect the shop.",
      retryable: false,
    });
  }

  let tokens: TikTokTokenSet;
  try {
    tokens = await refreshTokenSet(refreshToken);
  } catch (err) {
    if (err instanceof TikTokApiError && (err.httpStatus === 401 || err.httpStatus === 403)) {
      await prisma.connectedShop.update({
        where: { id: shopId },
        data: { status: "expired", lastSyncError: err.userMessage },
      });
      await notify(
        shop.organizationId,
        "shop_auth_expired",
        "TikTok Shop authorization expired",
        `The authorization for ${shop.shopName ?? "your shop"} expired or was revoked. Reconnect the shop to resume syncing.`
      );
    }
    throw err;
  }

  await storeTokens(shopId, tokens);
  await audit({
    organizationId: shop.organizationId,
    action: "shop.token_refreshed",
    entityType: "connected_shop",
    entityId: shopId,
  });
  return tokens;
}

/**
 * Disconnect a shop: attempt remote token revocation when the revoke endpoint
 * is verified, then ALWAYS delete stored credentials and scopes locally,
 * mark the shop revoked, and audit the action.
 */
export async function disconnectShop(shopId: string, actorId?: string): Promise<void> {
  const shop = await prisma.connectedShop.findUnique({
    where: { id: shopId },
    include: { credentials: { where: { kind: "seller_access" } } },
  });
  if (!shop) {
    throw new TikTokApiError({
      code: "SHOP_NOT_FOUND",
      httpStatus: 404,
      userMessage: "Connected shop not found.",
      retryable: false,
    });
  }

  let revokedRemotely = false;
  let revokeNote =
    "Remote token revocation is not verified for this app; credentials were deleted locally.";
  const revokeEp = ENDPOINTS.tokenRevoke;
  const accessCred = shop.credentials[0];
  if (revokeEp.approval === "verified" && !isDemoMode() && accessCred) {
    try {
      const token = decryptSecret(accessCred.payload);
      await authClient().request<unknown>({
        method: revokeEp.method,
        path: revokeEp.path,
        query: {
          app_key: config.tiktok.appKey,
          app_secret: config.tiktok.appSecret,
          access_token: token,
        },
        idempotent: false,
      });
      revokedRemotely = true;
      revokeNote = "Access token revoked via TikTok, then deleted locally.";
    } catch (err) {
      revokeNote = `Remote revocation failed (${err instanceof TikTokApiError ? err.code : "unknown"}); credentials were deleted locally.`;
    }
  }

  await prisma.$transaction([
    prisma.encryptedCredential.deleteMany({ where: { shopId } }),
    prisma.grantedScope.deleteMany({ where: { shopId } }),
    prisma.connectedShop.update({
      where: { id: shopId },
      data: { status: "revoked", disconnectedAt: new Date(), lastSyncError: null },
    }),
  ]);

  await audit({
    organizationId: shop.organizationId,
    actorId,
    action: "shop.disconnected",
    entityType: "connected_shop",
    entityId: shopId,
    details: { revokedRemotely, revokeNote },
  });
  await notify(
    shop.organizationId,
    "shop_auth_expired",
    "TikTok Shop disconnected",
    `${shop.shopName ?? "The shop"} was disconnected. ${revokeNote}`,
    actorId ?? undefined
  );
}
