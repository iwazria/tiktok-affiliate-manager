/**
 * SERVER ONLY — decrypts stored credentials. Never import from browser code.
 *
 * Provider selection per the architecture contract:
 * - demo adapter when `isDemoMode()` OR `shop.mode === "demo"`;
 * - live adapter otherwise, with the access token decrypted from
 *   EncryptedCredential (AES-256-GCM) and handed to the adapter in memory.
 *
 * Tokens are never logged, never returned to the client, and never leave the
 * server. Expired or missing credentials produce actionable TikTokApiErrors
 * (the token-refresh job handles renewal before expiry).
 */
import { prisma } from "../db";
import { isDemoMode } from "../config";
import { decryptSecret } from "../crypto";
import { TikTokApiError } from "./errors";
import { DemoTikTokAdapter } from "./demoAdapter";
import { LiveTikTokAdapter } from "./liveAdapter";
import type { TikTokProvider } from "./types";

if (typeof window !== "undefined") {
  throw new Error(
    "lib/tiktok/provider.ts is server-only and must not be bundled for the browser."
  );
}

export interface ShopRef {
  id: string;
  mode: string;
  tiktokShopId: string;
}

/**
 * Select the provider for a shop record. For live shops the caller must pass
 * a decrypted access token (use `getProviderForShopId` for the full flow).
 */
export function getTikTokProvider(
  shop: ShopRef,
  opts?: { accessToken?: string }
): TikTokProvider {
  if (isDemoMode() || shop.mode === "demo") {
    return new DemoTikTokAdapter();
  }
  if (!opts?.accessToken) {
    throw new TikTokApiError({
      code: "MISSING_CREDENTIAL",
      httpStatus: 401,
      userMessage: "No decrypted access token was provided for this live shop.",
      remediation:
        "Load the shop with getProviderForShopId(), which decrypts the stored credential.",
      retryable: false,
    });
  }
  return new LiveTikTokAdapter({
    shopId: shop.id,
    tiktokShopId: shop.tiktokShopId,
    accessToken: opts.accessToken,
  });
}

/**
 * Load a ConnectedShop from the database and return the correct provider,
 * decrypting the stored access credential for live shops.
 */
export async function getProviderForShopId(shopId: string): Promise<TikTokProvider> {
  const shop = await prisma.connectedShop.findUnique({ where: { id: shopId } });
  if (!shop) {
    throw new TikTokApiError({
      code: "SHOP_NOT_FOUND",
      httpStatus: 404,
      userMessage: "Connected shop not found.",
      retryable: false,
    });
  }
  if (isDemoMode() || shop.mode === "demo") {
    return new DemoTikTokAdapter();
  }

  const cred = await prisma.encryptedCredential.findUnique({
    where: { shopId_kind: { shopId: shop.id, kind: "seller_access" } },
  });
  if (!cred) {
    throw new TikTokApiError({
      code: "MISSING_CREDENTIAL",
      httpStatus: 401,
      userMessage: "No stored TikTok access token for this shop.",
      remediation: "Reconnect the shop in Settings to authorize again.",
      retryable: false,
    });
  }
  if (cred.expiresAt && cred.expiresAt.getTime() <= Date.now()) {
    throw new TikTokApiError({
      code: "TOKEN_EXPIRED",
      httpStatus: 401,
      userMessage: "The stored TikTok access token has expired.",
      remediation:
        "Run the token refresh job, or reconnect the shop in Settings.",
      retryable: false,
    });
  }

  let accessToken: string;
  try {
    accessToken = decryptSecret(cred.payload);
  } catch {
    throw new TikTokApiError({
      code: "CREDENTIAL_DECRYPT_FAILED",
      httpStatus: 500,
      userMessage: "The stored credential could not be decrypted.",
      remediation: "Check ENCRYPTION_KEY / key rotation, then reconnect the shop.",
      retryable: false,
    });
  }

  return new LiveTikTokAdapter({
    shopId: shop.id,
    tiktokShopId: shop.tiktokShopId,
    accessToken,
  });
}
