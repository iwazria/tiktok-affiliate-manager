/**
 * Shared DTOs and the `TikTokProvider` interface for the TikTok Shop
 * integration layer.
 *
 * RULE: `TikTokProvider` is the ONLY gateway to TikTok. No `fetch()` to
 * TikTok may exist anywhere else — all network access goes through
 * `lib/tiktok/http.ts`, used by the adapters in this directory.
 *
 * Every DTO carries a `source` field ("demo" | "tiktok") so the UI can always
 * show data provenance and freshness. Demo payloads never pretend to be live.
 */
import { z } from "zod";

/** Where a payload came from. */
export type DataSource = "demo" | "tiktok";

/** Quality label supplied (or simulated) by the data source. */
export type MetricQuality = "estimated" | "pending" | "final" | "unavailable";

/** Campaign lifecycle statuses used by this app. */
export type CampaignStatus =
  | "draft"
  | "scheduled"
  | "active"
  | "paused"
  | "ended"
  | "archived";

/** Statuses a campaign can be moved to via setCampaignStatus. */
export type CampaignStatusAction = "active" | "paused" | "ended" | "archived";

/** Creator invitation / collaboration lifecycle. */
export type InvitationStatus =
  | "draft"
  | "sent"
  | "accepted"
  | "declined"
  | "expired"
  | "completed"
  | "cancelled";

// ------------------------------------------------------------- shop ----
export interface ShopInfo {
  tiktokShopId: string;
  shopName: string | null;
  region: string | null;
  currency: string | null;
  sellerType: string | null;
  source: DataSource;
}

// ---------------------------------------------------------- products ---
export interface ProductDto {
  tiktokProductId: string;
  name: string;
  imageUrl: string | null;
  price: number | null;
  currency: string | null;
  status: string | null;
  stock: number | null;
  affiliateEligible: boolean;
  ineligibilityReason: string | null;
  source: DataSource;
}

export interface ListProductsParams {
  page?: number;
  pageSize?: number;
  search?: string;
  status?: string;
  eligibleOnly?: boolean;
}

export interface PagedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  source: DataSource;
}

// --------------------------------------------------------- campaigns ---
export const campaignInputSchema = z.object({
  name: z.string().min(1, "Campaign name is required").max(200),
  description: z.string().max(2000).optional(),
  productIds: z.array(z.string().min(1)).min(1, "Select at least one product"),
  commissionRate: z.number().min(0).max(100).optional(),
  commissionType: z.enum(["percentage", "fixed"]).optional(),
  startAt: z.string().datetime({ offset: true }).optional(),
  endAt: z.string().datetime({ offset: true }).optional(),
  collaborationType: z.enum(["open", "targeted"]).optional(),
  sampleAvailable: z.boolean().optional(),
  targetingNotes: z.string().max(2000).optional(),
});
export type CampaignInput = z.infer<typeof campaignInputSchema>;

export const campaignPatchSchema = z.object({
  name: z.string().min(1).max(200).optional(),
  description: z.string().max(2000).nullable().optional(),
  commissionRate: z.number().min(0).max(100).nullable().optional(),
  startAt: z.string().datetime({ offset: true }).nullable().optional(),
  endAt: z.string().datetime({ offset: true }).nullable().optional(),
  targetingNotes: z.string().max(2000).nullable().optional(),
});
export type CampaignPatch = z.infer<typeof campaignPatchSchema>;

export interface CampaignDto {
  /** Provider-level lookup key (TikTok campaign id for live; stable demo key in demo mode). */
  id: string;
  /** External TikTok campaign id; null for local drafts not created on TikTok. */
  tiktokCampaignId: string | null;
  name: string;
  description: string | null;
  status: CampaignStatus;
  productIds: string[];
  commissionRate: number | null;
  commissionType: string | null;
  startAt: string | null;
  endAt: string | null;
  collaborationType: string | null;
  sampleAvailable: boolean;
  lastError: string | null;
  source: DataSource;
}

export interface ListCampaignsParams {
  page?: number;
  pageSize?: number;
  search?: string;
  status?: CampaignStatus;
}

// ----------------------------------------------------- creators ------
export interface CreatorRef {
  tiktokCreatorId?: string;
  handle?: string;
  displayName?: string;
}

export const inviteCreatorInputSchema = z.object({
  creatorRef: z
    .object({
      tiktokCreatorId: z.string().min(1).optional(),
      handle: z.string().max(100).optional(),
      displayName: z.string().max(200).optional(),
    })
    .refine(
      (r) => r.tiktokCreatorId ?? r.handle ?? r.displayName,
      "At least one creator identifier is required"
    ),
  productIds: z.array(z.string().min(1)).max(50).optional(),
  message: z.string().max(1000).optional(),
});
export type InviteCreatorInput = z.infer<typeof inviteCreatorInputSchema>;

export interface CollaborationDto {
  /** Provider-level lookup key (TikTok invitation id for live; stable demo key in demo mode). */
  id: string;
  /** External TikTok invitation id; null until TikTok accepts/creates it. */
  tiktokInviteId: string | null;
  campaignId: string;
  creatorRef: CreatorRef;
  status: InvitationStatus;
  invitedAt: string | null;
  respondedAt: string | null;
  source: DataSource;
}

export interface CreatorSearchResult {
  tiktokCreatorId: string;
  handle?: string;
  displayName?: string;
  avatarUrl?: string;
  followerCount?: number;
  source: DataSource;
}

// ------------------------------------------------------------ metrics --
export const metricsParamsSchema = z.object({
  dateFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "dateFrom must be YYYY-MM-DD"),
  dateTo: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "dateTo must be YYYY-MM-DD"),
  campaignId: z.string().optional(),
  productId: z.string().optional(),
  creatorId: z.string().optional(),
  breakdown: z.enum(["day", "campaign", "product", "creator"]).optional(),
});
export type MetricsParams = z.infer<typeof metricsParamsSchema>;

export interface PerformancePoint {
  date: string | null;
  campaignId: string | null;
  productId: string | null;
  creatorId: string | null;
  clicks: number | null;
  orders: number | null;
  revenue: number | null;
  commission: number | null;
  currency: string | null;
  quality: MetricQuality;
}

export interface PerformanceTotals {
  clicks: number | null;
  orders: number | null;
  revenue: number | null;
  commission: number | null;
  currency: string | null;
}

export interface PerformanceMetrics {
  points: PerformancePoint[];
  totals: PerformanceTotals;
  quality: MetricQuality;
  source: DataSource;
  syncedAt: string;
  timezone: string;
}

// ------------------------------------------------------------- tokens --
export interface TikTokTokenSet {
  accessToken: string;
  accessTokenExpiresIn: number; // seconds
  refreshToken: string;
  refreshTokenExpiresIn: number; // seconds
  openId?: string;
  sellerName?: string;
  grantedScopes?: string[];
}

// ----------------------------------------------------------- provider --
/**
 * The ONLY gateway to TikTok Shop. Implemented by:
 * - `DemoTikTokAdapter` (demoAdapter.ts) — clearly labeled simulated data.
 * - `LiveTikTokAdapter` (liveAdapter.ts) — real calls via endpoints.ts + http.ts.
 *
 * Methods throw `TikTokCapabilityError` when the feature is not approved or
 * not verified for this app, and `TikTokApiError` for request failures.
 */
export interface TikTokProvider {
  readonly source: DataSource;

  getAuthorizedShopInfo(): Promise<ShopInfo>;

  listProducts(params: ListProductsParams): Promise<PagedResult<ProductDto>>;
  getProduct(tiktokProductId: string): Promise<ProductDto | null>;

  listCampaigns(params: ListCampaignsParams): Promise<PagedResult<CampaignDto>>;
  createCampaign(input: CampaignInput): Promise<CampaignDto>;
  updateCampaign(campaignId: string, patch: CampaignPatch): Promise<CampaignDto>;
  setCampaignStatus(
    campaignId: string,
    status: CampaignStatusAction
  ): Promise<CampaignDto>;

  listCollaborations(campaignId: string): Promise<CollaborationDto[]>;
  inviteCreator(
    campaignId: string,
    input: InviteCreatorInput
  ): Promise<CollaborationDto>;
  getInvitationStatus(invitationId: string): Promise<CollaborationDto>;
  resendInvitation(invitationId: string): Promise<CollaborationDto>;
  cancelInvitation(invitationId: string): Promise<CollaborationDto>;

  getPerformanceMetrics(params: MetricsParams): Promise<PerformanceMetrics>;

  /**
   * Creator discovery. MUST throw TikTokCapabilityError — creator search is
   * not approved for this app. Sellers manage manually entered creator
   * records instead.
   */
  searchCreators(query: string): Promise<CreatorSearchResult[]>;

  refreshToken(refreshToken: string): Promise<TikTokTokenSet>;
  revokeToken(token: string): Promise<void>;
}
