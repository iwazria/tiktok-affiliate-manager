# lib/tiktok — TikTok Shop integration layer

**The rule: no direct TikTok calls outside this directory.** The only HTTP
calls to TikTok in the entire codebase live in `http.ts`. Everything else —
API routes, jobs, UI — reaches TikTok exclusively through the
`TikTokProvider` interface (`types.ts`), obtained via `provider.ts`.

## Files

| File | Purpose |
|---|---|
| `types.ts` | `TikTokProvider` interface + DTOs. Every payload carries `source: "demo" \| "tiktok"` for provenance. Zod schemas for input shapes. |
| `errors.ts` | `TikTokApiError` (code, httpStatus, userMessage, remediation, retryable) and `TikTokCapabilityError` for unapproved/unverified features. `mapTikTokError()` translates TikTok failures into user-readable messages. Never includes tokens/secrets. |
| `http.ts` | Server-only signed HTTP client. Implements TikTok Shop Open API request signing (HMAC-SHA256; algorithm + worked example in the file header), 15s timeout, retries with exponential backoff + jitter (max 3, idempotent requests only), 429 handling honoring `Retry-After`. API version from `TIKTOK_API_VERSION`. Logs metadata only, via `redactSecrets`. |
| `endpoints.ts` | Endpoint registry: path, method, required scope, and `approvalStatus` (`verified` \| `pending_approval` \| `unavailable`). The live adapter may only call `verified` endpoints. Scope strings are provisional — confirm exact names in Partner Center. |
| `demoAdapter.ts` | `DemoTikTokAdapter`: clearly labeled simulated data (`source: "demo"`, in-memory state mirroring `prisma/seed.ts` products p-1001..p-1008). Demo-only actions simulate state transitions locally. `reset()` restores the dataset. |
| `liveAdapter.ts` | `LiveTikTokAdapter`: real calls via `endpoints.ts` + `http.ts`. Unverified endpoints throw `TikTokCapabilityError` — nothing is invented. Implements token refresh/revoke. |
| `provider.ts` | `getTikTokProvider(shop)` → demo adapter when `isDemoMode()` or `shop.mode === "demo"`, else live adapter. `getProviderForShopId(shopId)` loads the shop from Prisma and decrypts the stored access token (AES-256-GCM) for live mode. |
| `capabilities.ts` | `getCapabilities({ mode, scopes, region })` → per-feature availability. Demo: available but `demoOnly: true`. Live: available only with granted scope + verified endpoint. `creator_search` is always unavailable (pending approval). |
| `oauth.ts` | Seller OAuth: `createAuthorizationSession` (secure single-use `state`, 32 random bytes, SHA-256 stored, 10-min expiry, bound to user+org), `validateCallback` (rejects missing/invalid/expired/reused states, handles denial), `exchangeCodeForTokens`, `storeTokens` (encrypted at rest), `refreshAccessToken` (expiry tracking), `disconnectShop` (revoke-if-verified + delete credentials). Creator authorization throws `TikTokCapabilityError` — not approved; seller and creator credentials are never mixed. |

## Current approval status (honest)

- **Verified**: seller OAuth token get/refresh, product search.
- **Pending approval** (throws `TikTokCapabilityError` in live mode): shop info, product detail, all affiliate campaign/collaboration endpoints, performance metrics, token revoke.
- **Unavailable**: creator search/discovery.

See `endpoints.ts` for per-endpoint notes, and `docs/` (docs agent) for the
feature-availability matrix. Before going live, verify the signing algorithm,
endpoint paths, and scope names against the current Partner Center docs.
