/**
 * Client-side API helper. All /api routes use the envelope
 * { ok: true, data } / { ok: false, error: { code, message, fieldErrors? } }.
 * Same-origin fetch sends the httpOnly session cookie automatically.
 */

export interface ApiErrorShape {
  code: string;
  message: string;
  fieldErrors?: Record<string, string[]>;
}

export class ApiRequestError extends Error {
  status: number;
  apiError: ApiErrorShape;
  constructor(status: number, apiError: ApiErrorShape) {
    super(apiError.message || "Request failed");
    this.name = "ApiRequestError";
    this.status = status;
    this.apiError = apiError;
  }
}

interface Envelope<T> {
  ok?: boolean;
  data?: T;
  error?: ApiErrorShape;
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    credentials: "same-origin",
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
  });
  let body: Envelope<T> | null = null;
  try {
    body = (await res.json()) as Envelope<T>;
  } catch {
    body = null;
  }
  if (!res.ok || !body || body.ok !== true) {
    const err: ApiErrorShape =
      body?.error ?? { code: "request_failed", message: `Request failed (${res.status})` };
    throw new ApiRequestError(res.status, err);
  }
  return body.data as T;
}

/** Extract zod-style field errors from a caught error, if present. */
export function getFieldErrors(e: unknown): Record<string, string[]> | null {
  return e instanceof ApiRequestError ? e.apiError.fieldErrors ?? null : null;
}

/** Human-readable message from any caught error. */
export function getErrorMessage(e: unknown): string {
  if (e instanceof ApiRequestError) return e.apiError.message || "Request failed.";
  if (e instanceof Error) return e.message || "Something went wrong.";
  return "Something went wrong.";
}

/** True when the error is 401/403 (auth or permission problem). */
export function isAuthError(e: unknown): boolean {
  return e instanceof ApiRequestError && (e.status === 401 || e.status === 403);
}

export function isForbidden(e: unknown): boolean {
  return e instanceof ApiRequestError && e.status === 403;
}
