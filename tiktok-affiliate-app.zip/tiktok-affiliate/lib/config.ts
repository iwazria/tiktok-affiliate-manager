/**
 * Central configuration. Every secret or deployment-specific value comes from
 * environment variables. See .env.example for the full list (placeholders only).
 */

function env(name: string, fallback = ""): string {
  return process.env[name] ?? fallback;
}

function envBool(name: string, fallback: boolean): boolean {
  const v = process.env[name];
  if (v === undefined) return fallback;
  return ["1", "true", "yes", "on"].includes(v.toLowerCase());
}

export const config = {
  nodeEnv: env("NODE_ENV", "development"),
  isProd: env("NODE_ENV") === "production",
  appUrl: env("APP_URL", "http://localhost:3000"),

  /** Demo mode is ON unless explicitly disabled AND TikTok credentials exist. */
  demoMode: envBool("DEMO_MODE", true),
  tiktok: {
    appKey: env("TIKTOK_APP_KEY"),
    appSecret: env("TIKTOK_APP_SECRET"),
    apiBase: env("TIKTOK_API_BASE", "https://open-api.tiktokglobalshop.com"),
    apiVersion: env("TIKTOK_API_VERSION", "202309"),
    authBase: env("TIKTOK_AUTH_BASE", "https://auth.tiktok-shops.com"),
    redirectUri: env("TIKTOK_REDIRECT_URI", ""),
  },

  /** 32+ byte secret for token encryption (AES-256-GCM). */
  encryptionKey: env("ENCRYPTION_KEY"),
  encryptionKeyVersion: parseInt(env("ENCRYPTION_KEY_VERSION", "1"), 10) || 1,
  sessionSecret: env("SESSION_SECRET", ""),

  rateLimit: {
    windowMs: parseInt(env("RATE_LIMIT_WINDOW_MS", "60000"), 10),
    max: parseInt(env("RATE_LIMIT_MAX", "60"), 10),
  },
};

/**
 * The app runs in demo mode unless the operator explicitly opts into live
 * mode AND provides TikTok app credentials. Demo mode uses the mock adapter
 * and every demo value is labeled as such in the UI.
 */
export function getAppMode(): "demo" | "live" {
  if (config.demoMode) return "demo";
  if (!config.tiktok.appKey || !config.tiktok.appSecret) return "demo";
  return "live";
}

export function isDemoMode(): boolean {
  return getAppMode() === "demo";
}
