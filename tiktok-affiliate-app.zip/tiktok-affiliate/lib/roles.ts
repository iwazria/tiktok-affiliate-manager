/**
 * Frontend role helpers. Mirrors lib/rbac.ts ROLE_RANK.
 * NOTE: hiding UI is UX only — the API enforces every permission server-side.
 */

export const ROLE_RANK: Record<string, number> = {
  owner: 0,
  admin: 1,
  campaign_manager: 2,
  analyst: 3,
  read_only: 4,
};

export function roleAtLeast(role: string | null | undefined, minimum: string): boolean {
  return (ROLE_RANK[role ?? ""] ?? 99) <= (ROLE_RANK[minimum] ?? 99);
}

export function roleLabel(role: string | null | undefined): string {
  switch (role) {
    case "owner":
      return "Owner";
    case "admin":
      return "Admin";
    case "campaign_manager":
      return "Campaign manager";
    case "analyst":
      return "Analyst";
    case "read_only":
      return "Read-only";
    default:
      return role ?? "Unknown";
  }
}

export const ROLE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "owner", label: "Owner — full control" },
  { value: "admin", label: "Admin — manage everything except ownership" },
  { value: "campaign_manager", label: "Campaign manager — campaigns, products, creators" },
  { value: "analyst", label: "Analyst — view dashboards and reports" },
  { value: "read_only", label: "Read-only — view permitted data" },
];
