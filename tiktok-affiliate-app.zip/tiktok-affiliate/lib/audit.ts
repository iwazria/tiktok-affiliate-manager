import { prisma } from "./db";
import { redactSecrets } from "./crypto";

export interface AuditEntry {
  organizationId: string;
  actorId?: string | null;
  action: string;
  entityType?: string;
  entityId?: string;
  details?: Record<string, unknown>;
  ip?: string;
}

/** Append an audit record. Secrets are redacted before storage. */
export async function audit(entry: AuditEntry) {
  try {
    await prisma.auditLog.create({
      data: {
        organizationId: entry.organizationId,
        actorId: entry.actorId ?? null,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        details: entry.details ? JSON.stringify(redactSecrets(entry.details)) : null,
        ip: entry.ip,
      },
    });
  } catch (e) {
    // Audit must never break the main flow; log to stderr instead.
    console.error("[audit] failed to write audit log", e);
  }
}

export async function notify(
  organizationId: string,
  type: string,
  title: string,
  body?: string,
  userId?: string | null
) {
  // Respect per-user preferences: skip when the target user disabled the type.
  if (userId) {
    const pref = await prisma.notificationPreference.findUnique({
      where: { organizationId_userId_type: { organizationId, userId, type } },
    });
    if (pref && !pref.enabled) return;
  }
  await prisma.notification.create({
    data: { organizationId, userId: userId ?? null, type, title, body },
  });
}
