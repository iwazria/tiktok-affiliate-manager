import { NextResponse } from "next/server";
import { z } from "zod";

export interface ApiError {
  code: string;
  message: string;
  fieldErrors?: Record<string, string[]>;
}

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ ok: true, data }, { status });
}

export function fail(code: string, message: string, status = 400, fieldErrors?: Record<string, string[]>) {
  const error: ApiError = { code, message };
  if (fieldErrors) error.fieldErrors = fieldErrors;
  return NextResponse.json({ ok: false, error }, { status });
}

export function zodFail(e: z.ZodError) {
  const fieldErrors: Record<string, string[]> = {};
  for (const issue of e.issues) {
    const key = issue.path.join(".") || "_";
    (fieldErrors[key] ||= []).push(issue.message);
  }
  return fail("validation_error", "Please fix the highlighted fields.", 422, fieldErrors);
}

export async function parseJson<T extends z.ZodTypeAny>(req: Request, schema: T) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return { error: fail("bad_request", "Request body must be JSON.", 400) as NextResponse, data: null as null };
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) return { error: zodFail(parsed.error), data: null as null };
  // NOTE: keep `error: null` as a literal (no widening assertion) so the
  // return type stays a discriminated union and callers narrow `data`
  // correctly after `if (error) return error;`.
  return { error: null, data: parsed.data as z.infer<T> };
}
