/**
 * lib/capabilities.ts — canonical capability layer for routes and jobs.
 *
 * The integration layer (lib/tiktok/capabilities.ts) owns the FeatureKey
 * taxonomy tied to TikTok approval/scopes/endpoints. The API layer speaks in
 * camelCase keys (CAP.*). THIS FILE is the single place where the two meet:
 * every route and job must use CAP.* + hasCapability() from here.
 *
 * Never invent availability: when the registry says unavailable, the feature
 * stays disabled with the registry's reason.
 */
import {
  getCapabilities as getRawCapabilities,
  type CapabilityInfo,
} from "./tiktok/capabilities";
import { TikTokApiError, TikTokCapabilityError } from "./tiktok/errors";

/**
 * API-layer capability keys → integration FeatureKey.
 *
 * Fallbacks (documented, not invented):
 * - campaignSync: campaign list reads ride on the affiliate-campaign API
 *   surface; the closest registered requirement is campaign_create's
 *   scope/approval gate.
 * - creatorInviteResend / creatorInviteCancel: resend/cancel reuse the same
 *   collaboration-invitation API surface as creator_invite.
 */
export const CAP = {
  productSync: "product_sync",
  campaignSync: "campaign_create",
  collabSync: "invitation_tracking",
  metricsSync: "metrics",
  campaignCreate: "campaign_create",
  campaignEdit: "campaign_edit",
  campaignPause: "campaign_status",
  campaignResume: "campaign_status",
  campaignEnd: "campaign_status",
  campaignArchive: "campaign_status",
  creatorDiscovery: "creator_search",
  creatorInvite: "creator_invite",
  creatorInviteResend: "creator_invite",
  creatorInviteCancel: "creator_invite",
  performanceMetrics: "metrics",
  /** Local CSV export feature (role-gated at the route level). */
  exportData: "export",
} as const;

export type CapKey = keyof typeof CAP;
export type { CapabilityInfo };

/**
 * Reverse lookup: FeatureKey value -> a CapKey that maps to it.
 * Several CapKeys can share one FeatureKey (e.g. campaignPause/campaignResume/
 * campaignEnd/campaignArchive all ride on "campaign_status"); availability and
 * reason are identical for all of them, so any one is a valid representative.
 */
const FEATURE_TO_CAP = Object.fromEntries(
  Object.entries(CAP).map(([capKey, featureKey]) => [featureKey, capKey])
) as Record<string, CapKey>;

/**
 * Resolve either a CapKey ("campaignCreate") or a FeatureKey value
 * ("campaign_create", e.g. via CAP.campaignCreate) to the CapKey used in the
 * capabilities record. Routes historically passed CAP.* values, so both
 * forms are accepted to avoid silent capability denials.
 */
function resolveCapKey(key: CapKey | string): CapKey | undefined {
  if (key in CAP) return key as CapKey; // already a CapKey
  return FEATURE_TO_CAP[key]; // or a FeatureKey value passed via CAP.*
}

export interface ShopCapabilityRef {
  mode: string;
  region?: string | null;
}

/** Full capability info per CAP key (availability + human-readable reason). */
export async function getShopCapabilities(
  shop: ShopCapabilityRef,
  scopes: string[]
): Promise<Record<CapKey, CapabilityInfo>> {
  const raw = getRawCapabilities({
    mode: shop.mode === "live" ? "live" : "demo",
    scopes,
    region: shop.region ?? undefined,
  });
  const out = {} as Record<CapKey, CapabilityInfo>;
  for (const [capKey, featureKey] of Object.entries(CAP) as Array<[CapKey, keyof typeof raw]>) {
    out[capKey] = raw[featureKey];
  }
  return out;
}

export function hasCapability(
  caps: Record<string, CapabilityInfo> | null | undefined,
  key: CapKey | string
): boolean {
  const capKey = resolveCapKey(key);
  return !!capKey && !!caps?.[capKey]?.available;
}

/** Human-readable explanation for why a capability is unavailable. */
export function capabilityReason(
  caps: Record<string, CapabilityInfo> | null | undefined,
  key: CapKey | string
): string | undefined {
  const capKey = resolveCapKey(key);
  return capKey ? caps?.[capKey]?.reason : undefined;
}

export interface MappedTikTokError {
  code: string;
  message: string;
  status: number;
  fieldErrors?: Record<string, string[]>;
}

/** Map a thrown TikTok error into the API error envelope shape (no secrets). */
export function mapTikTokError(err: unknown): MappedTikTokError {
  if (err instanceof TikTokCapabilityError) {
    return {
      code: "capability_unavailable",
      message: err.reason || "This feature is not available for the connected shop.",
      status: 403,
    };
  }
  if (err instanceof TikTokApiError) {
    const shape = err.toClientShape();
    return {
      code: shape.code,
      message: shape.message,
      status: err.httpStatus > 0 ? err.httpStatus : 502,
      fieldErrors: shape.fieldErrors,
    };
  }
  const message =
    err instanceof Error ? err.message : "TikTok Shop request failed.";
  return { code: "tiktok_error", message: message.slice(0, 500), status: 502 };
}
