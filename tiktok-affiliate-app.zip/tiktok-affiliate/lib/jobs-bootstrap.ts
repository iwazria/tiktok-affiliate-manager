/**
 * lib/jobs-bootstrap.ts — start the DB-backed job runner once per server process.
 *
 * Imported for side effects by lib/db.ts (which every API route loads).
 * The Next.js instrumentation hook cannot be used here: in this Next.js
 * version the instrumentation bundle is compiled without Node.js built-in
 * module support, so importing the job/prisma/crypto chain from
 * instrumentation.ts fails at build time. Route handlers always run in the
 * Node.js runtime, making this lazy bootstrap the reliable alternative.
 *
 * The globalThis guard ensures the poller starts exactly once per process,
 * and only in a real server runtime (never in scripts, seed, or tests where
 * NEXT_RUNTIME is unset).
 */
import { registerJobHandlers, runDueJobs } from "./jobs";

declare global {
  // eslint-disable-next-line no-var
  var __tamJobsStarted: boolean | undefined;
}

function startJobRunner(): void {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  if (globalThis.__tamJobsStarted) return;
  globalThis.__tamJobsStarted = true;

  registerJobHandlers();

  const poll = () => {
    runDueJobs().catch((err) => {
      console.error("[jobs] runDueJobs failed", err);
    });
  };

  // Process anything already queued shortly after boot, then every minute.
  setTimeout(poll, 5_000);
  const timer = setInterval(poll, 60_000);
  // Don't keep the process alive just for the poller in scripts/tests.
  const t = timer as unknown as { unref?: () => void };
  if (typeof t.unref === "function") t.unref();

  console.log("[jobs] background runner started (7 handlers)");
}

startJobRunner();
