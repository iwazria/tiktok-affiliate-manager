import { NextRequest, NextResponse } from "next/server";
import { prisma } from "./db";
import { getSessionUser } from "./auth";

/** Role hierarchy: lower rank = more privilege. */
export const ROLE_RANK: Record<string, number> = {
  owner: 0,
  admin: 1,
  campaign_manager: 2,
  analyst: 3,
  read_only: 4,
};

export const ROLES = Object.keys(ROLE_RANK);

export interface OrgContext {
  userId: string;
  organizationId: string;
  role: string;
}

export function roleAtLeast(role: string, minimum: string): boolean {
  return (ROLE_RANK[role] ?? 99) <= (ROLE_RANK[minimum] ?? 99);
}

/**
 * Resolve the caller's membership in an organization.
 * Returns null when not a member. Throws never — callers map to 403/404.
 */
export async function getOrgMembership(
  userId: string,
  organizationId: string
): Promise<OrgContext | null> {
  const member = await prisma.organizationMember.findUnique({
    where: { organizationId_userId: { organizationId, userId } },
  });
  if (!member || member.status !== "active") return null;
  return { userId, organizationId, role: member.role };
}

/** Require an authenticated user; returns 401 response on failure. */
export async function requireUser(req: NextRequest) {
  const user = await getSessionUser();
  if (!user) {
    return { error: NextResponse.json({ ok: false, error: { code: "unauthorized", message: "Sign in required." } }, { status: 401 }), user: null };
  }
  // NOTE: keep `error: null` literal so the return stays a discriminated union.
  return { error: null, user };
}

/**
 * Require membership in the org with at least `minimumRole`.
 * Returns { ctx } or { error } — always check error first.
 */
export async function requireOrgRole(
  userId: string,
  organizationId: string,
  minimumRole: string
): Promise<{ ctx: OrgContext | null; error: NextResponse | null }> {
  const ctx = await getOrgMembership(userId, organizationId);
  if (!ctx || !roleAtLeast(ctx.role, minimumRole)) {
    return {
      ctx: null,
      error: NextResponse.json(
        { ok: false, error: { code: "forbidden", message: "You don't have permission for this action." } },
        { status: 403 }
      ),
    };
  }
  return { ctx, error: null };
}

/** Very small in-memory rate limiter (per process). For production use Redis. */
const buckets = new Map<string, { count: number; resetAt: number }>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  b.count += 1;
  return b.count <= max;
}
