import { PrismaClient } from "@prisma/client";
// Side effect: start the DB-backed job runner once per server process.
// (See lib/jobs-bootstrap.ts for why the instrumentation hook isn't used.)
import "./jobs-bootstrap";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
