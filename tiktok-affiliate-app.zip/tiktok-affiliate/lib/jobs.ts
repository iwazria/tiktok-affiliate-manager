/**
 * lib/jobs.ts — DB-backed job runner (API agent owned).
 *
 * Jobs are persisted as SyncJob rows and processed by runDueJobs(), which is
 * invoked on a timer from app/instrumentation.ts and can also be triggered
 * on demand via runJobNow() (the "Sync now" button).
 *
 * Guarantees:
 * - Idempotent handlers (upserts / delete-then-insert inside the synced range).
 * - Bounded retries: max 3 attempts with exponential backoff (30s * 2^attempts).
 * - No overlapping syncs: a job is skipped while another `running` job with
 *   the same (shopId, kind) — or (organizationId, kind) when shop-less — exists.
 * - Every run writes SyncJob status/result/error and updates shop sync health.
 * - Users are notified on completion/failure; secrets are never logged.
 *
 * SCHEMA NOTE: SyncJob gained an optional `payload` column (JSON, secrets
 * redacted) so handlers like report_export can find their ExportJob. Run
 * `npx prisma generate && npx prisma db push` after pulling this change.
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { prisma } from "./db";
import { audit, notify } from "./audit";
import { redactSecrets } from "./crypto";
import { getProviderForShopId } from "@/lib/tiktok/provider";
import { refreshAccessToken } from "@/lib/tiktok/oauth";
import type {
  TikTokProvider,
  ProductDto,
  CampaignDto,
  CollaborationDto,
  PerformancePoint,
} from "@/lib/tiktok/types";

// Capability helpers live in lib/capabilities.ts (canonical). Re-exported
// here so older imports keep working.
export {
  CAP,
  getShopCapabilities,
  hasCapability,
  capabilityReason,
  mapTikTokError,
} from "./capabilities";
export type { CapKey, CapabilityInfo, MappedTikTokError } from "./capabilities";

// ------------------------------------------------------------------ types

export type JobKind =
  | "product_sync"
  | "campaign_sync"
  | "collab_sync"
  | "metrics_sync"
  | "token_refresh"
  | "report_export"
  | "cleanup";

export interface EnqueueJobInput {
  organizationId: string;
  shopId?: string;
  kind: JobKind;
  payload?: Record<string, unknown>;
}

export const JOB_MAX_ATTEMPTS = 3;
const RETRY_BASE_MS = 30_000;
const STALE_RUNNING_MS = 30 * 60 * 1000; // reclaim jobs stuck > 30 min
const EXPORT_DIR = path.join(process.cwd(), "storage", "exports");
const TMP_DIR = path.join(process.cwd(), "storage", "tmp");

/** A provider is in demo mode when its data source is simulated. */
function isDemoProvider(provider: TikTokProvider): boolean {
  return provider.source === "demo";
}

// ------------------------------------------------------------- enqueue ---

interface JobRow {
  id: string;
  organizationId: string;
  shopId: string | null;
  kind: string;
  status: string;
  attempts: number;
  startedAt: Date | null;
  finishedAt: Date | null;
  payload: string | null;
}

export async function enqueueJob(input: EnqueueJobInput): Promise<string> {
  const job = await prisma.syncJob.create({
    data: {
      organizationId: input.organizationId,
      shopId: input.shopId ?? null,
      kind: input.kind,
      status: "queued",
      payload: input.payload ? JSON.stringify(redactSecrets(input.payload)) : null,
    },
  });
  return job.id;
}

// --------------------------------------------------------------- runner ---

type JobHandler = (job: JobRow) => Promise<string>;

const handlers = new Map<string, JobHandler>();

function backoffDue(finishedAt: Date, attempts: number): boolean {
  const waitMs = RETRY_BASE_MS * Math.pow(2, Math.max(0, attempts - 1));
  return finishedAt.getTime() + waitMs <= Date.now();
}

/** Process every due job. Safe to call on a timer; skips overlapping syncs. */
export async function runDueJobs(): Promise<number> {
  ensureHandlers();
  const now = new Date();

  // Reclaim jobs stuck in `running` (e.g. crashed process) so they can retry.
  await prisma.syncJob.updateMany({
    where: {
      status: "running",
      startedAt: { lt: new Date(now.getTime() - STALE_RUNNING_MS) },
    },
    data: {
      status: "failed",
      error: "Job was reclaimed after being stuck in running state.",
      finishedAt: now,
    },
  });

  const candidates = (await prisma.syncJob.findMany({
    where: {
      OR: [{ status: "queued" }, { status: "failed", attempts: { lt: JOB_MAX_ATTEMPTS } }],
    },
    orderBy: { createdAt: "asc" },
    take: 10,
  })) as unknown as JobRow[];

  let processed = 0;
  for (const job of candidates) {
    if (job.status === "failed") {
      if (!job.finishedAt || !backoffDue(job.finishedAt, job.attempts)) continue;
    }
    // No overlapping syncs per shop+kind (or org+kind for shop-less jobs).
    const overlapWhere = job.shopId
      ? { shopId: job.shopId, kind: job.kind, status: "running", NOT: { id: job.id } }
      : {
          organizationId: job.organizationId,
          shopId: null,
          kind: job.kind,
          status: "running",
          NOT: { id: job.id },
        };
    const overlapping = await prisma.syncJob.findFirst({ where: overlapWhere });
    if (overlapping) continue; // leave queued for the next pass

    // Claim the job (avoids double-processing across processes).
    const claimed = await prisma.syncJob.updateMany({
      where: { id: job.id, status: job.status },
      data: { status: "running", startedAt: new Date(), attempts: { increment: 1 } },
    });
    if (!claimed.count) continue;

    await processJob({ ...job, status: "running", attempts: job.attempts + 1 });
    processed++;
  }
  return processed;
}

/** Run one job immediately (used by the "Sync now" button). */
export async function runJobNow(id: string): Promise<string> {
  ensureHandlers();
  const job = (await prisma.syncJob.findUnique({ where: { id } })) as unknown as JobRow | null;
  if (!job) throw new Error("Job not found");
  await prisma.syncJob.update({
    where: { id },
    data: { status: "queued", attempts: 0, error: null, resultSummary: null },
  });
  const summary = await processJob({ ...job, status: "queued", attempts: 1 });
  return summary;
}

async function processJob(job: JobRow): Promise<string> {
  const handler = handlers.get(job.kind);
  if (!handler) {
    await finishJob(job, "failed", `No handler registered for job kind "${job.kind}".`);
    throw new Error(`No handler registered for job kind "${job.kind}"`);
  }
  try {
    const summary = await handler(job);
    await finishJob(job, "succeeded", summary);
    return summary;
  } catch (err) {
    const message = sanitizeError(err);
    const failedPermanently = job.attempts >= JOB_MAX_ATTEMPTS;
    await finishJob(
      job,
      "failed",
      failedPermanently
        ? `Failed after ${job.attempts} attempts: ${message}`
        : `Attempt ${job.attempts} failed (will retry): ${message}`
    );
    if (job.shopId) {
      await prisma.connectedShop
        .update({
          where: { id: job.shopId },
          data: { lastSyncStatus: "failed", lastSyncError: message.slice(0, 500) },
        })
        .catch(() => undefined);
      await notify(
        job.organizationId,
        "sync_failed",
        "Sync failed",
        `The ${job.kind.replace(/_/g, " ")} job failed: ${message}`
      ).catch(() => undefined);
    }
    throw err instanceof Error ? err : new Error(message);
  }
}

async function finishJob(job: JobRow, status: "succeeded" | "failed", text: string) {
  const data =
    status === "succeeded"
      ? { status, resultSummary: text.slice(0, 1000), error: null, finishedAt: new Date() }
      : { status, error: text.slice(0, 1000), finishedAt: new Date() };
  await prisma.syncJob.update({ where: { id: job.id }, data });
}

/** Extract a safe, secret-free message from any thrown value. */
function sanitizeError(err: unknown): string {
  const raw =
    err instanceof Error ? err.message : typeof err === "string" ? err : "Unknown error";
  const redacted = redactSecrets(raw);
  return typeof redacted === "string" ? redacted : "Unknown error";
}

function ensureHandlers() {
  if (handlers.size > 0) return;
  registerJobHandlers();
}

/** Called once from app/instrumentation.ts. Idempotent. */
export function registerJobHandlers(): void {
  handlers.set("product_sync", productSync);
  handlers.set("campaign_sync", campaignSync);
  handlers.set("collab_sync", collabSync);
  handlers.set("metrics_sync", metricsSync);
  handlers.set("token_refresh", tokenRefresh);
  handlers.set("report_export", reportExport);
  handlers.set("cleanup", cleanup);
  console.log(`[jobs] registered ${handlers.size} handlers`);
}

// -------------------------------------------------------------- handlers ---

async function getJobShop(job: JobRow) {
  if (!job.shopId) throw new Error("This job requires a shop.");
  const shop = await prisma.connectedShop.findFirst({
    where: { id: job.shopId, organizationId: job.organizationId },
  });
  if (!shop) throw new Error("Shop not found or not in this organization.");
  return shop;
}

async function markShopSynced(shopId: string, ok: boolean, error?: string) {
  await prisma.connectedShop.update({
    where: { id: shopId },
    data: {
      lastSyncAt: new Date(),
      lastSyncStatus: ok ? "succeeded" : "failed",
      lastSyncError: ok ? null : (error ?? null)?.slice(0, 500),
    },
  });
}

async function productSync(job: JobRow): Promise<string> {
  const shop = await getJobShop(job);
  const provider: TikTokProvider = await getProviderForShopId(shop.id);
  const demo = isDemoProvider(provider) || shop.mode === "demo";

  // Paginate the provider (bounded: at most 5 pages of 100).
  const products: ProductDto[] = [];
  for (let page = 1; page <= 5; page++) {
    const res = await provider.listProducts({ page, pageSize: 100 });
    products.push(...res.items);
    if (res.items.length < 100) break;
  }

  let count = 0;
  for (const p of products) {
    if (!p.tiktokProductId || !p.name) continue;
    const data = {
      organizationId: shop.organizationId,
      shopId: shop.id,
      name: p.name,
      imageUrl: p.imageUrl ?? null,
      price: p.price ?? null,
      currency: p.currency ?? shop.currency,
      status: p.status ?? null,
      stock: p.stock ?? null,
      affiliateEligible: !!p.affiliateEligible,
      ineligibilityReason: p.ineligibilityReason ?? null,
      rawFields: null as string | null,
      lastSyncedAt: new Date(),
      isDemo: demo,
    };
    await prisma.product.upsert({
      where: { shopId_tiktokProductId: { shopId: shop.id, tiktokProductId: p.tiktokProductId } },
      update: data,
      create: { tiktokProductId: p.tiktokProductId, ...data },
    });
    count++;
  }
  await markShopSynced(shop.id, true);
  await prisma.onboardingState.upsert({
    where: { organizationId: shop.organizationId },
    update: { productsSynced: true },
    create: { organizationId: shop.organizationId, productsSynced: true },
  });
  await audit({
    organizationId: shop.organizationId,
    action: "shop.products_synced",
    entityType: "ConnectedShop",
    entityId: shop.id,
    details: { count, mode: shop.mode, demo },
  });
  await notify(
    shop.organizationId,
    "sync_completed",
    "Product sync completed",
    `${count} product${count === 1 ? "" : "s"} synced for ${shop.shopName ?? "the shop"}.`
  );
  return `Synced ${count} products`;
}

async function campaignSync(job: JobRow): Promise<string> {
  const shop = await getJobShop(job);
  const provider: TikTokProvider = await getProviderForShopId(shop.id);
  const demo = isDemoProvider(provider) || shop.mode === "demo";

  const campaigns: CampaignDto[] = [];
  for (let page = 1; page <= 5; page++) {
    const res = await provider.listCampaigns({ page, pageSize: 100 });
    campaigns.push(...res.items);
    if (res.items.length < 100) break;
  }

  let count = 0;
  for (const c of campaigns) {
    if (!c.name) continue;
    // External key: TikTok campaign id when known, else the provider's stable id.
    const externalId = c.tiktokCampaignId ?? c.id;
    // Match an existing row by external id, or a same-named local draft.
    const existing = await prisma.campaign.findFirst({
      where: {
        shopId: shop.id,
        OR: [{ tiktokCampaignId: externalId }, { tiktokCampaignId: null, name: c.name }],
      },
    });
    const data = {
      tiktokCampaignId: externalId,
      name: c.name,
      description: c.description ?? null,
      status: c.status,
      commissionRate: c.commissionRate ?? null,
      commissionType: c.commissionType ?? null,
      startAt: c.startAt ? new Date(c.startAt) : null,
      endAt: c.endAt ? new Date(c.endAt) : null,
      collaborationType: c.collaborationType ?? null,
      sampleAvailable: c.sampleAvailable ?? false,
      isDemo: demo,
      lastSyncedAt: new Date(),
      lastError: null as string | null,
    };
    if (existing) {
      await prisma.campaign.update({ where: { id: existing.id }, data });
    } else {
      await prisma.campaign.create({
        data: {
          organizationId: shop.organizationId,
          shopId: shop.id,
          ...data,
        },
      });
    }
    count++;
  }
  await markShopSynced(shop.id, true);
  await audit({
    organizationId: shop.organizationId,
    action: "shop.campaigns_synced",
    entityType: "ConnectedShop",
    entityId: shop.id,
    details: { count, mode: shop.mode },
  });
  await notify(
    shop.organizationId,
    "sync_completed",
    "Campaign sync completed",
    `${count} campaign${count === 1 ? "" : "s"} synced for ${shop.shopName ?? "the shop"}.`
  );
  return `Synced ${count} campaigns`;
}

async function collabSync(job: JobRow): Promise<string> {
  const shop = await getJobShop(job);
  const provider: TikTokProvider = await getProviderForShopId(shop.id);

  // The provider lists collaborations per campaign (external campaign id).
  const localCampaigns = await prisma.campaign.findMany({
    where: { shopId: shop.id, tiktokCampaignId: { not: null } },
    select: { tiktokCampaignId: true },
  });

  let checked = 0;
  let updated = 0;
  for (const lc of localCampaigns) {
    if (!lc.tiktokCampaignId) continue;
    let dtos: CollaborationDto[];
    try {
      dtos = await provider.listCollaborations(lc.tiktokCampaignId);
    } catch (e) {
      // One campaign's failure must not abort the whole sync.
      console.error(
        "[jobs] collabSync: listCollaborations failed",
        redactSecrets(e instanceof Error ? e.message : e)
      );
      continue;
    }
    checked += dtos.length;
    for (const c of dtos) {
      const externalInviteId = c.tiktokInviteId ?? c.id;
      if (!externalInviteId) continue;
      const local = await prisma.collaboration.findFirst({
        where: { organizationId: shop.organizationId, tiktokInviteId: externalInviteId },
      });
      if (!local) continue;
      const nextStatus = c.status || local.status;
      if (nextStatus !== local.status) {
        await prisma.collaboration.update({
          where: { id: local.id },
          data: {
            status: nextStatus,
            invitedAt: c.invitedAt ? new Date(c.invitedAt) : local.invitedAt,
            respondedAt: c.respondedAt ? new Date(c.respondedAt) : local.respondedAt,
          },
        });
        updated++;
        if (["accepted", "declined", "completed"].includes(nextStatus)) {
          await notify(
            shop.organizationId,
            "invite_status",
            `Creator invitation ${nextStatus}`,
            `A collaboration invitation changed status to ${nextStatus}.`
          ).catch(() => undefined);
        }
      }
    }
  }
  await markShopSynced(shop.id, true);
  return `Checked ${checked} collaborations, updated ${updated}`;
}

function fmtDay(d: Date): string {
  return d.toISOString().slice(0, 10);
}

async function metricsSync(job: JobRow): Promise<string> {
  const shop = await getJobShop(job);
  const provider: TikTokProvider = await getProviderForShopId(shop.id);
  const to = new Date();
  const from = new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000);
  const res = await provider.getPerformanceMetrics({ dateFrom: fmtDay(from), dateTo: fmtDay(to) });
  const source = provider.source === "demo" || shop.mode === "demo" ? "demo" : "tiktok_api";
  const points: PerformancePoint[] = res.points;

  // Idempotent: replace this org+shop's synced snapshots inside the window.
  await prisma.performanceSnapshot.deleteMany({
    where: {
      organizationId: shop.organizationId,
      shopId: shop.id,
      date: { gte: from, lte: to },
      source: { in: ["demo", "tiktok_api"] },
    },
  });

  // Resolve local ids from TikTok ids for joinable breakdowns.
  const campaigns = await prisma.campaign.findMany({
    where: { shopId: shop.id, tiktokCampaignId: { not: null } },
    select: { id: true, tiktokCampaignId: true },
  });
  const products = await prisma.product.findMany({
    where: { shopId: shop.id },
    select: { id: true, tiktokProductId: true },
  });
  const campaignByExternal = new Map(campaigns.map((c) => [c.tiktokCampaignId as string, c.id]));
  const productByExternal = new Map(products.map((p) => [p.tiktokProductId, p.id]));

  const rows = points
    .filter((m) => m.date)
    .map((m) => ({
      organizationId: shop.organizationId,
      shopId: shop.id,
      campaignId: m.campaignId ? (campaignByExternal.get(m.campaignId) ?? null) : null,
      productId: m.productId ? (productByExternal.get(m.productId) ?? null) : null,
      creatorId: null as string | null,
      date: new Date(m.date as string),
      clicks: m.clicks ?? null,
      orders: m.orders ?? null,
      revenue: m.revenue ?? null,
      commission: m.commission ?? null,
      currency: m.currency ?? shop.currency,
      quality: m.quality ?? "final",
      source,
      syncedAt: new Date(),
    }));
  if (rows.length > 0) {
    // createMany in chunks to stay within parameter limits.
    for (let i = 0; i < rows.length; i += 500) {
      await prisma.performanceSnapshot.createMany({ data: rows.slice(i, i + 500) });
    }
  }
  await markShopSynced(shop.id, true);
  await audit({
    organizationId: shop.organizationId,
    action: "shop.metrics_synced",
    entityType: "ConnectedShop",
    entityId: shop.id,
    details: { rows: rows.length, source },
  });
  return `Synced ${rows.length} metric snapshots`;
}

async function tokenRefresh(job: JobRow): Promise<string> {
  const shop = await getJobShop(job);
  try {
    // Decrypts the stored refresh token, refreshes, and stores the new set
    // encrypted. Marks the shop expired + notifies when refresh is rejected.
    await refreshAccessToken(shop.id);
    await prisma.connectedShop.update({
      where: { id: shop.id },
      data: { status: "connected", lastSyncError: null },
    });
    return "Tokens refreshed";
  } catch (err) {
    const message = sanitizeError(err);
    await prisma.connectedShop.update({
      where: { id: shop.id },
      data: { status: "expired", lastSyncError: message.slice(0, 500) },
    });
    await notify(
      shop.organizationId,
      "shop_auth_expired",
      "Shop authorization expired",
      `Token refresh failed for ${shop.shopName ?? "the shop"}: ${message}. Reconnect the shop to restore sync.`
    );
    throw err;
  }
}

// ---------------------------------------------------------- report export ---

function toCsv(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0]);
  const esc = (v: unknown) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [
    headers.join(","),
    ...rows.map((r) => headers.map((h) => esc(r[h])).join(",")),
  ].join("\n");
}

async function reportExport(job: JobRow): Promise<string> {
  const payload = job.payload ? (JSON.parse(job.payload) as { exportJobId?: string; kind?: string; filters?: Record<string, unknown> }) : {};
  // Resolve the export job: prefer the payload id, else oldest queued export for the org.
  let exportJob = payload.exportJobId
    ? await prisma.exportJob.findFirst({
        where: { id: payload.exportJobId, organizationId: job.organizationId },
      })
    : null;
  if (!exportJob) {
    exportJob = await prisma.exportJob.findFirst({
      where: { organizationId: job.organizationId, status: "queued" },
      orderBy: { createdAt: "asc" },
    });
  }
  if (!exportJob) return "No queued export jobs";
  if (exportJob.status === "ready") return "Export already ready (idempotent skip)";

  await prisma.exportJob.update({ where: { id: exportJob.id }, data: { status: "running" } });
  try {
    const filters = (payload.filters ?? {}) as { shopId?: string; from?: string; to?: string };
    const kind = payload.kind ?? exportJob.kind;
    let rows: Record<string, unknown>[] = [];

    if (kind === "creators") {
      const creators = await prisma.creator.findMany({
        where: { organizationId: job.organizationId },
        orderBy: { createdAt: "asc" },
      });
      rows = creators.map((c) => ({
        id: c.id,
        handle: c.handle ?? "",
        display_name: c.displayName ?? "",
        follower_count: c.followerCount ?? "",
        source: c.source,
        tags: c.tags ?? "",
        notes: c.notes ?? "",
        created_at: c.createdAt.toISOString(),
      }));
    } else if (kind === "products") {
      const products = await prisma.product.findMany({
        where: {
          organizationId: job.organizationId,
          ...(filters.shopId ? { shopId: filters.shopId } : {}),
        },
        include: { shop: { select: { shopName: true } } },
        orderBy: { name: "asc" },
      });
      rows = products.map((p) => ({
        id: p.id,
        tiktok_product_id: p.tiktokProductId,
        name: p.name,
        price: p.price ?? "",
        currency: p.currency ?? "",
        status: p.status ?? "",
        stock: p.stock ?? "",
        affiliate_eligible: p.affiliateEligible,
        shop: p.shop.shopName ?? "",
        is_demo: p.isDemo,
      }));
    } else {
      // report: performance snapshots
      const from = filters.from ? new Date(filters.from) : new Date(Date.now() - 30 * 86400000);
      const to = filters.to ? new Date(filters.to) : new Date();
      const snaps = await prisma.performanceSnapshot.findMany({
        where: {
          organizationId: job.organizationId,
          ...(filters.shopId ? { shopId: filters.shopId } : {}),
          date: { gte: from, lte: to },
        },
        orderBy: { date: "asc" },
      });
      rows = snaps.map((s) => ({
        date: s.date.toISOString().slice(0, 10),
        campaign_id: s.campaignId ?? "",
        product_id: s.productId ?? "",
        creator_id: s.creatorId ?? "",
        clicks: s.clicks ?? "",
        orders: s.orders ?? "",
        revenue: s.revenue ?? "",
        commission: s.commission ?? "",
        currency: s.currency ?? "",
        quality: s.quality,
        source: s.source,
      }));
    }

    await fs.mkdir(EXPORT_DIR, { recursive: true });
    const fileName = `${kind}-${exportJob.id}.csv`;
    const filePath = path.join(EXPORT_DIR, fileName);
    await fs.writeFile(filePath, toCsv(rows), "utf8");

    await prisma.exportJob.update({
      where: { id: exportJob.id },
      data: { status: "ready", fileName, filePath, rowCount: rows.length, finishedAt: new Date() },
    });
    await audit({
      organizationId: job.organizationId,
      actorId: exportJob.userId,
      action: "export.completed",
      entityType: "ExportJob",
      entityId: exportJob.id,
      details: { kind, rowCount: rows.length },
    });
    await notify(
      job.organizationId,
      "export_ready",
      "Export ready",
      `Your ${kind} export (${rows.length} rows) is ready to download.`,
      exportJob.userId
    );
    return `Exported ${rows.length} rows to ${fileName}`;
  } catch (err) {
    const message = sanitizeError(err);
    await prisma.exportJob.update({
      where: { id: exportJob.id },
      data: { status: "failed", error: message.slice(0, 500), finishedAt: new Date() },
    });
    throw err;
  }
}

// --------------------------------------------------------------- cleanup ---

async function cleanup(job: JobRow): Promise<string> {
  const now = new Date();
  // Expired authorization sessions (single-use states must not linger).
  const sessions = await prisma.authorizationSession.deleteMany({
    where: { expiresAt: { lt: now } },
  });
  // Old temp files.
  let tmpDeleted = 0;
  try {
    await fs.mkdir(TMP_DIR, { recursive: true });
    const files = await fs.readdir(TMP_DIR);
    for (const f of files) {
      const p = path.join(TMP_DIR, f);
      const stat = await fs.stat(p).catch(() => null);
      if (stat && stat.isFile() && stat.mtimeMs < now.getTime() - 24 * 60 * 60 * 1000) {
        await fs.unlink(p).catch(() => undefined);
        tmpDeleted++;
      }
    }
  } catch {
    // tmp dir missing is fine
  }
  // Bound table growth: drop old terminal jobs (keeps 30 days of history).
  const oldJobs = await prisma.syncJob.deleteMany({
    where: {
      organizationId: job.organizationId,
      status: { in: ["succeeded", "failed"] },
      finishedAt: { lt: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000) },
    },
  });
  return `Deleted ${sessions.count} expired auth sessions, ${tmpDeleted} temp files, ${oldJobs.count} old jobs`;
}
