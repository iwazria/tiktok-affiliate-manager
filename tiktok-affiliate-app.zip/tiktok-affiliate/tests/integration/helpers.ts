/**
 * Shared helpers for integration tests.
 *
 * - `next/headers` is mocked with a controllable in-memory cookie jar so
 *   `createSession` / `getSessionUser` / `destroySession` work in vitest.
 * - `ensureTestDb()` resets the isolated SQLite test DB (./test.db) via
 *   `prisma db push --force-reset`. Called from `beforeAll` of each enabled
 *   suite — never at import time.
 * - `routeExists()` lets suites skip gracefully when a route has not been
 *   built yet; the skip is logged and must be listed as a gap.
 * - `makeRequest()` builds a real `NextRequest` (handlers use `req.nextUrl`).
 *
 * Route contracts below mirror the API agent's routes under
 * `app/api/orgs/[orgId]/…`. If a route's contract changes, update the call
 * sites — the assertions (status codes, isolation, RBAC) are the stable part.
 */
import { vi } from "vitest";
import { execSync } from "child_process";
import { createHash, randomBytes } from "crypto";
import { existsSync } from "fs";
import { join } from "path";
import { NextRequest } from "next/server";

const PROJECT_ROOT = process.cwd();

// --- next/headers mock -------------------------------------------------------
export const cookieJar = new Map<string, string>();

vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) => {
      const value = cookieJar.get(name);
      return value === undefined ? undefined : { name, value };
    },
    set: (name: string, value: string, _opts?: unknown) => {
      cookieJar.set(name, value);
    },
    delete: (name: string) => {
      cookieJar.delete(name);
    },
  }),
}));

// --- test database -----------------------------------------------------------
let dbReady = false;

/** Create/reset the isolated SQLite test DB. Idempotent per process. */
export function ensureTestDb(): void {
  if (dbReady) return;
  execSync("npx prisma db push --force-reset --accept-data-loss --skip-generate", {
    cwd: PROJECT_ROOT,
    env: { ...process.env },
    stdio: "pipe",
  });
  dbReady = true;
}

/** Wipe all rows between tests (cascades clear org-scoped tables). */
export async function resetDb(): Promise<void> {
  const { prisma } = await import("@/lib/db");
  await prisma.organization.deleteMany({});
  await prisma.user.deleteMany({});
}

// --- routes ------------------------------------------------------------------
/** e.g. routeExists("orgs/[orgId]/products") -> app/api/orgs/[orgId]/products/route.ts */
export function routeExists(relative: string): boolean {
  return existsSync(join(PROJECT_ROOT, "app", "api", ...relative.split("/"), "route.ts"));
}

/** Import a route module dynamically (throws if missing — check routeExists first). */
export async function importRoute(relative: string) {
  // Literal segments only: callers pass the full path including [orgId].
  const mod = await import(`@/app/api/${relative}/route`);
  return mod as Record<string, (req: NextRequest, ctx?: unknown) => Promise<Response>>;
}

// --- auth --------------------------------------------------------------------
export const SESSION_COOKIE = "tam_session";

export async function createUserWithOrg(input: {
  email: string;
  name?: string;
  role?: string;
  orgName?: string;
}) {
  const { prisma } = await import("@/lib/db");
  const { hashPassword } = await import("@/lib/auth");
  const passwordHash = await hashPassword("password123");
  const user = await prisma.user.create({
    data: {
      email: input.email,
      name: input.name ?? "Test User",
      passwordHash,
      emailVerified: true,
    },
  });
  const slug = `test-org-${randomBytes(4).toString("hex")}`;
  const org = await prisma.organization.create({
    data: { name: input.orgName ?? "Test Org", slug },
  });
  const membership = await prisma.organizationMember.create({
    data: {
      organizationId: org.id,
      userId: user.id,
      role: input.role ?? "owner",
      status: "active",
    },
  });
  return { user, org, membership };
}

/** Add an existing or new user to an org with the given role. */
export async function addMember(
  orgId: string,
  email: string,
  role: string
): Promise<{ userId: string; membershipId: string }> {
  const { prisma } = await import("@/lib/db");
  const { hashPassword } = await import("@/lib/auth");
  let user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    user = await prisma.user.create({
      data: {
        email,
        name: email.split("@")[0],
        passwordHash: await hashPassword("password123"),
        emailVerified: true,
      },
    });
  }
  const membership = await prisma.organizationMember.create({
    data: { organizationId: orgId, userId: user.id, role, status: "active" },
  });
  return { userId: user.id, membershipId: membership.id };
}

/** Create a session row and put its raw token in the mocked cookie jar. */
export async function signInAs(userId: string): Promise<void> {
  const { prisma } = await import("@/lib/db");
  const raw = randomBytes(32).toString("hex");
  const token = createHash("sha256").update(raw).digest("hex");
  await prisma.session.create({
    data: { userId, token, expiresAt: new Date(Date.now() + 3600_000) },
  });
  cookieJar.set(SESSION_COOKIE, raw);
}

export function signOut(): void {
  cookieJar.clear();
}

/** Seed a demo-mode shop with one eligible and one ineligible product. */
export async function seedDemoShop(orgId: string) {
  const { prisma } = await import("@/lib/db");
  const shop = await prisma.connectedShop.create({
    data: {
      organizationId: orgId,
      tiktokShopId: `shop-${randomBytes(4).toString("hex")}`,
      shopName: "Test Shop",
      region: "US",
      currency: "USD",
      mode: "demo",
      status: "connected",
    },
  });
  const eligible = await prisma.product.create({
    data: {
      organizationId: orgId,
      shopId: shop.id,
      tiktokProductId: "tp-ok",
      name: "Eligible Product",
      affiliateEligible: true,
    },
  });
  const ineligible = await prisma.product.create({
    data: {
      organizationId: orgId,
      shopId: shop.id,
      tiktokProductId: "tp-no",
      name: "Ineligible Product",
      affiliateEligible: false,
      ineligibilityReason: "Out of stock",
    },
  });
  return { shop, eligible, ineligible };
}

// --- requests ----------------------------------------------------------------
export function makeRequest(
  path: string,
  opts: {
    method?: string;
    body?: unknown;
    query?: Record<string, string>;
  } = {}
): NextRequest {
  const url = new URL(path, "http://localhost");
  for (const [k, v] of Object.entries(opts.query ?? {})) url.searchParams.set(k, v);
  return new NextRequest(url.toString(), {
    method: opts.method ?? "GET",
    headers: { "Content-Type": "application/json" },
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
  });
}

/** Route-context second arg: { params: Promise<{ orgId, ... }> }. */
export function routeCtx(params: Record<string, string>) {
  return { params: Promise.resolve(params) };
}
