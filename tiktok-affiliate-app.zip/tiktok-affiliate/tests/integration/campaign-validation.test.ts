/**
 * Integration: campaign validation and lifecycle guards.
 *
 * Routes under test:
 * - POST /api/orgs/[orgId]/campaigns
 *   -> 201 on success; 422 when a product is ineligible or missing
 * - POST /api/orgs/[orgId]/campaigns/[id]/end
 *   -> destructive action: requires { confirm: true } in the body
 *      (missing/invalid confirm -> 422 validation error)
 */
import { describe, expect, it, beforeAll, beforeEach } from "vitest";
import {
  ensureTestDb,
  resetDb,
  routeExists,
  importRoute,
  makeRequest,
  routeCtx,
  createUserWithOrg,
  seedDemoShop,
  signInAs,
  signOut,
} from "./helpers";

const CAMPAIGNS = "orgs/[orgId]/campaigns";
const END = "orgs/[orgId]/campaigns/[id]/end";
const hasRoutes = routeExists(CAMPAIGNS) && routeExists(END);

if (!hasRoutes) {
  console.log(
    `[campaign-validation.test] SKIPPED — route files missing: app/api/${CAMPAIGNS}/route.ts and/or app/api/${END}/route.ts not found.`
  );
}

const suite = hasRoutes ? describe : describe.skip;

suite("campaign validation", () => {
  beforeAll(() => ensureTestDb());
  beforeEach(async () => {
    await resetDb();
    signOut();
  });

  async function seedSeller() {
    const { user, org } = await createUserWithOrg({
      email: "seller@example.com",
      role: "campaign_manager",
      orgName: "Seller Org",
    });
    const { shop, eligible, ineligible } = await seedDemoShop(org.id);
    await signInAs(user.id);
    return { org, shop, eligible, ineligible };
  }

  it("creating a campaign with an ineligible product returns 422", async () => {
    const { org, eligible, ineligible } = await seedSeller();
    const { POST } = await importRoute(CAMPAIGNS);

    const res = await POST(
      makeRequest(`/api/orgs/${org.id}/campaigns`, {
        method: "POST",
        body: {
          name: "Bad Campaign",
          productIds: [eligible.id, ineligible.id],
        },
      }),
      routeCtx({ orgId: org.id })
    );
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(body.ok).toBe(false);
    expect(JSON.stringify(body)).toMatch(/eligib/i);
  });

  it("creating a campaign with a missing product returns 422", async () => {
    const { org, eligible } = await seedSeller();
    const { POST } = await importRoute(CAMPAIGNS);

    const res = await POST(
      makeRequest(`/api/orgs/${org.id}/campaigns`, {
        method: "POST",
        body: { name: "Bad Campaign", productIds: [eligible.id, "nonexistent-id"] },
      }),
      routeCtx({ orgId: org.id })
    );
    expect(res.status).toBe(422);
  });

  it("creating a campaign with only eligible products succeeds (201, local draft)", async () => {
    const { org, eligible } = await seedSeller();
    const { POST } = await importRoute(CAMPAIGNS);

    const res = await POST(
      makeRequest(`/api/orgs/${org.id}/campaigns`, {
        method: "POST",
        body: { name: "Good Campaign", productIds: [eligible.id], commissionRate: 10 },
      }),
      routeCtx({ orgId: org.id })
    );
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.data.isLive).toBe(false); // demo shop -> local draft
    expect(body.data.status).toBe("draft");
  });

  it("ending a campaign without { confirm: true } is rejected", async () => {
    const { org, shop } = await seedSeller();
    const { prisma } = await import("@/lib/db");
    const campaign = await prisma.campaign.create({
      data: {
        organizationId: org.id,
        shopId: shop.id,
        name: "Live Campaign",
        status: "active",
      },
    });

    const { POST } = await importRoute(END);
    const ctx = routeCtx({ orgId: org.id, id: campaign.id });

    const res = await POST(
      makeRequest(`/api/orgs/${org.id}/campaigns/${campaign.id}/end`, {
        method: "POST",
        body: {},
      }),
      ctx
    );
    // The route requires confirm: true via zod literal -> validation error.
    expect(res.status).toBe(422);

    const confirmed = await POST(
      makeRequest(`/api/orgs/${org.id}/campaigns/${campaign.id}/end`, {
        method: "POST",
        body: { confirm: true },
      }),
      ctx
    );
    expect(confirmed.status).toBe(200);
    expect((await confirmed.json()).data.status).toBe("ended");
  });
});
