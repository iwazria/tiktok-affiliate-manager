/**
 * Integration: team management permission guards.
 *
 * Routes under test:
 * - POST /api/orgs/[orgId]/invitations (min role: admin)
 *   -> analyst inviting: 403
 * - PATCH /api/orgs/[orgId]/members/[memberId] (min role: admin)
 *   -> admin changing an owner's role: 403
 *   -> demoting the last owner: 400
 * - DELETE /api/orgs/[orgId]/members/[memberId] (min role: admin)
 *   -> removing the last owner: 400
 */
import { describe, expect, it, beforeAll, beforeEach } from "vitest";
import {
  ensureTestDb,
  resetDb,
  routeExists,
  importRoute,
  makeRequest,
  routeCtx,
  createUserWithOrg,
  addMember,
  signInAs,
  signOut,
} from "./helpers";

const INVITATIONS = "orgs/[orgId]/invitations";
const MEMBER = "orgs/[orgId]/members/[memberId]";
const hasRoutes = routeExists(INVITATIONS) && routeExists(MEMBER);

if (!hasRoutes) {
  console.log(
    `[team-permissions.test] SKIPPED — route files missing: app/api/${INVITATIONS}/route.ts and/or app/api/${MEMBER}/route.ts not found.`
  );
}

const suite = hasRoutes ? describe : describe.skip;

suite("team permissions", () => {
  beforeAll(() => ensureTestDb());
  beforeEach(async () => {
    await resetDb();
    signOut();
  });

  async function seedOrg() {
    const { user: owner, org, membership: ownerMembership } =
      await createUserWithOrg({ email: "owner@example.com", role: "owner" });
    const analyst = await addMember(org.id, "analyst@example.com", "analyst");
    const admin = await addMember(org.id, "admin@example.com", "admin");
    return { org, owner, ownerMembership, analyst, admin };
  }

  it("an analyst cannot invite team members (403)", async () => {
    const { org, analyst } = await seedOrg();
    await signInAs(analyst.userId);

    const { POST } = await importRoute(INVITATIONS);
    const res = await POST(
      makeRequest(`/api/orgs/${org.id}/invitations`, {
        method: "POST",
        body: { email: "new@example.com", role: "read_only" },
      }),
      routeCtx({ orgId: org.id })
    );
    expect(res.status).toBe(403);
  });

  it("an admin can invite a read-only member (201)", async () => {
    const { org, admin } = await seedOrg();
    await signInAs(admin.userId);

    const { POST } = await importRoute(INVITATIONS);
    const res = await POST(
      makeRequest(`/api/orgs/${org.id}/invitations`, {
        method: "POST",
        body: { email: "newbie@example.com", role: "read_only" },
      }),
      routeCtx({ orgId: org.id })
    );
    expect(res.status).toBe(201);
    expect((await res.json()).ok).toBe(true);
  });

  it("an admin cannot change the owner's role (403)", async () => {
    const { org, admin, ownerMembership } = await seedOrg();
    await signInAs(admin.userId);

    const { PATCH } = await importRoute(MEMBER);
    const res = await PATCH(
      makeRequest(`/api/orgs/${org.id}/members/${ownerMembership.id}`, {
        method: "PATCH",
        body: { role: "admin" },
      }),
      routeCtx({ orgId: org.id, memberId: ownerMembership.id })
    );
    expect(res.status).toBe(403);
  });

  it("removing the last organization owner returns 400", async () => {
    const { org, owner, ownerMembership } = await seedOrg();
    await signInAs(owner.id);

    const { DELETE } = await importRoute(MEMBER);
    const res = await DELETE(
      makeRequest(`/api/orgs/${org.id}/members/${ownerMembership.id}`, {
        method: "DELETE",
      }),
      routeCtx({ orgId: org.id, memberId: ownerMembership.id })
    );
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(JSON.stringify(body)).toMatch(/owner/i);
  });

  it("an owner can remove a non-owner member", async () => {
    const { org, owner, analyst } = await seedOrg();
    await signInAs(owner.id);

    const { DELETE } = await importRoute(MEMBER);
    const res = await DELETE(
      makeRequest(`/api/orgs/${org.id}/members/${analyst.membershipId}`, {
        method: "DELETE",
      }),
      routeCtx({ orgId: org.id, memberId: analyst.membershipId })
    );
    expect(res.status).toBe(200);
  });
});
