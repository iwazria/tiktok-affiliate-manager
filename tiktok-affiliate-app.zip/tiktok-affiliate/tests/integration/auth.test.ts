/**
 * Integration: authentication flows (signup / signin).
 *
 * ASSUMED ROUTE CONTRACT (sync with the API agent if routes differ):
 * - POST /api/auth/signup { name, email, password, organizationName? }
 *   -> 201 { user, organization }, sets tam_session cookie; duplicate email -> 409
 * - POST /api/auth/signin { email, password }
 *   -> 200 { user }, sets tam_session cookie; wrong password -> 401
 *
 * Gap status (2026-10-16): app/api/ contains no routes yet, so this suite is
 * skipped. It auto-enables when the route files appear.
 */
import { describe, expect, it, beforeAll, beforeEach } from "vitest";
import {
  ensureTestDb,
  resetDb,
  routeExists,
  importRoute,
  makeRequest,
  cookieJar,
  SESSION_COOKIE,
  signOut,
} from "./helpers";

const SIGNUP = "auth/signup";
const SIGNIN = "auth/signin";
const hasRoutes = routeExists(SIGNUP) && routeExists(SIGNIN);

if (!hasRoutes) {
  console.log(
    `[auth.test] SKIPPED — route files missing: app/api/${SIGNUP}/route.ts and/or app/api/${SIGNIN}/route.ts not found. Gap: auth routes not yet built.`
  );
}

const suite = hasRoutes ? describe : describe.skip;

suite("auth routes", () => {
  beforeAll(() => ensureTestDb());
  beforeEach(async () => {
    await resetDb();
    signOut();
  });

  it("signup creates a user, an organization, and an owner membership", async () => {
    const { POST } = await importRoute(SIGNUP);
    const res = await POST(makeRequest("/api/auth/signup", {
      method: "POST",
      body: {
        name: "Ada Seller",
        email: "ada@example.com",
        password: "correct-horse-9",
        organizationName: "Ada Commerce",
      },
    }) as never);

    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.data.user.email).toBe("ada@example.com");
    expect(body.data.organization).toBeDefined();
    // session cookie must be set (httpOnly, via mocked cookie jar)
    expect(cookieJar.get(SESSION_COOKIE)).toBeTruthy();

    const { prisma } = await import("@/lib/db");
    const member = await prisma.organizationMember.findFirst({
      where: { user: { email: "ada@example.com" } },
    });
    expect(member?.role).toBe("owner");
    expect(member?.status).toBe("active");

    // password must not be stored in plain text
    const user = await prisma.user.findUnique({ where: { email: "ada@example.com" } });
    expect(user!.passwordHash).not.toContain("correct-horse-9");
  });

  it("signup with a duplicate email returns 409", async () => {
    const { POST } = await importRoute(SIGNUP);
    const payload = {
      name: "Bo",
      email: "bo@example.com",
      password: "some-password-1",
      organizationName: "Bo Shop",
    };
    const first = await POST(makeRequest("/api/auth/signup", { method: "POST", body: payload }) as never);
    expect(first.status).toBe(201);

    const second = await POST(makeRequest("/api/auth/signup", { method: "POST", body: payload }) as never);
    expect(second.status).toBe(409);
    const body = await second.json();
    expect(body.ok).toBe(false);
    expect(body.error.code).toMatch(/conflict|duplicate|email/i);
  });

  it("signin with a wrong password returns 401", async () => {
    const signup = await importRoute(SIGNUP);
    await signup.POST(
      makeRequest("/api/auth/signup", {
        method: "POST",
        body: { name: "Cy", email: "cy@example.com", password: "right-password-1", organizationName: "Cy Co" },
      }) as never
    );
    signOut();

    const { POST } = await importRoute(SIGNIN);
    const res = await POST(
      makeRequest("/api/auth/signin", {
        method: "POST",
        body: { email: "cy@example.com", password: "wrong-password" },
      }) as never
    );
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.ok).toBe(false);
  });

  it("signin with correct credentials returns 200 and sets a session", async () => {
    const signup = await importRoute(SIGNUP);
    await signup.POST(
      makeRequest("/api/auth/signup", {
        method: "POST",
        body: { name: "Di", email: "di@example.com", password: "right-password-1", organizationName: "Di Co" },
      }) as never
    );
    signOut();

    const { POST } = await importRoute(SIGNIN);
    const res = await POST(
      makeRequest("/api/auth/signin", {
        method: "POST",
        body: { email: "di@example.com", password: "right-password-1" },
      }) as never
    );
    expect(res.status).toBe(200);
    expect(cookieJar.get(SESSION_COOKIE)).toBeTruthy();
  });
});
