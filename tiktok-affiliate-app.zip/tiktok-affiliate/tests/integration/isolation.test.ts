/**
 * Integration: organization data isolation.
 *
 * Routes under test:
 * - GET /api/orgs/[orgId]/products  (min role: read_only)
 * - GET /api/orgs/[orgId]/campaigns (min role: analyst)
 *
 * What must hold: a signed-in member of org A can never see org B's products
 * or campaigns — every query filters by organizationId (ARCHITECTURE.md).
 */
import { describe, expect, it, beforeAll, beforeEach } from "vitest";
import {
  ensureTestDb,
  resetDb,
  routeExists,
  importRoute,
  makeRequest,
  routeCtx,
  createUserWithOrg,
  signInAs,
  signOut,
} from "./helpers";

const PRODUCTS = "orgs/[orgId]/products";
const CAMPAIGNS = "orgs/[orgId]/campaigns";
const hasRoutes = routeExists(PRODUCTS) && routeExists(CAMPAIGNS);

if (!hasRoutes) {
  console.log(
    `[isolation.test] SKIPPED — route files missing: app/api/${PRODUCTS}/route.ts and/or app/api/${CAMPAIGNS}/route.ts not found.`
  );
}

const suite = hasRoutes ? describe : describe.skip;

suite("organization data isolation", () => {
  beforeAll(() => ensureTestDb());
  beforeEach(async () => {
    await resetDb();
    signOut();
  });

  async function seedTwoOrgs() {
    const { prisma } = await import("@/lib/db");
    const a = await createUserWithOrg({ email: "a@example.com", orgName: "Org A" });
    const b = await createUserWithOrg({ email: "b@example.com", orgName: "Org B" });

    for (const { org, tag, prod, camp } of [
      { org: a.org, tag: "a", prod: "Org A Lamp", camp: "Org A Campaign" },
      { org: b.org, tag: "b", prod: "Org B Lamp", camp: "Org B Campaign" },
    ]) {
      const shop = await prisma.connectedShop.create({
        data: { organizationId: org.id, tiktokShopId: `shop-${tag}`, mode: "demo" },
      });
      await prisma.product.create({
        data: {
          organizationId: org.id,
          shopId: shop.id,
          tiktokProductId: `p${tag}-1`,
          name: prod,
        },
      });
      await prisma.campaign.create({
        data: {
          organizationId: org.id,
          shopId: shop.id,
          name: camp,
          status: "active",
        },
      });
    }
    return { a, b };
  }

  it("product queries for org A never return org B rows", async () => {
    const { a } = await seedTwoOrgs();
    await signInAs(a.user.id);

    const { GET } = await importRoute(PRODUCTS);
    const res = await GET(
      makeRequest(`/api/orgs/${a.org.id}/products`),
      routeCtx({ orgId: a.org.id })
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    const names = body.data.items.map((p: { name: string }) => p.name);
    expect(names).toContain("Org A Lamp");
    expect(names).not.toContain("Org B Lamp");
  });

  it("campaign queries for org A never return org B rows", async () => {
    const { a } = await seedTwoOrgs();
    await signInAs(a.user.id);

    const { GET } = await importRoute(CAMPAIGNS);
    const res = await GET(
      makeRequest(`/api/orgs/${a.org.id}/campaigns`),
      routeCtx({ orgId: a.org.id })
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    const names = body.data.items.map((c: { name: string }) => c.name);
    expect(names).toContain("Org A Campaign");
    expect(names).not.toContain("Org B Campaign");
  });

  it("a member of org A cannot read org B's products (403)", async () => {
    const { a, b } = await seedTwoOrgs();
    await signInAs(a.user.id); // member of A only

    const { GET } = await importRoute(PRODUCTS);
    const res = await GET(
      makeRequest(`/api/orgs/${b.org.id}/products`),
      routeCtx({ orgId: b.org.id })
    );
    expect(res.status).toBe(403);
    expect((await res.json()).ok).toBe(false);
  });

  it("an unauthenticated request is rejected (401)", async () => {
    const { a } = await seedTwoOrgs();
    // not signed in
    const { GET } = await importRoute(PRODUCTS);
    const res = await GET(
      makeRequest(`/api/orgs/${a.org.id}/products`),
      routeCtx({ orgId: a.org.id })
    );
    expect(res.status).toBe(401);
  });
});
