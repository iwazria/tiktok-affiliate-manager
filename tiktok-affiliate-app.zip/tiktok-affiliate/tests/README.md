# Tests

## Running

```bash
npm install        # one-time (installs vitest, prisma, next, …)
npx prisma generate  # one-time (builds the Prisma client used by tests)
npm test           # runs the full suite once (vitest run)
npm run test:watch # watch mode during development
```

## Test database isolation

- Unit tests (`tests/unit/`) are pure: they never touch a database.
- Integration tests (`tests/integration/`) run against a **throwaway SQLite
  file** at the project root, `./test.db` — never `dev.db`, never Postgres,
  never anything reachable from production.
  - `tests/setup.ts` sets `DATABASE_URL` to an absolute `file:` URL for
    `./test.db` **before any test file is imported**.
  - Each enabled integration suite calls `ensureTestDb()` in `beforeAll`,
    which runs `prisma db push --force-reset --accept-data-loss` to build a
    fresh schema, and `resetDb()` in `beforeEach` to wipe rows between tests.
- The demo seed (`prisma/seed.ts`) is **not** used by tests; suites seed only
  the minimal rows they need via Prisma.
- `next/headers` is mocked in `tests/integration/helpers.ts` with an
  in-memory cookie jar, so session helpers (`createSession`,
  `getSessionUser`) work without a running Next.js server.

## Graceful skips

Some suites auto-skip when a dependency has not been built yet (integration
agent still writing `lib/tiktok/*`, API agent still writing `app/api/*`).
A skip always prints a `[<file>.test] SKIPPED — …` console note naming the
missing file. Skips are expected during parallel development and must be
listed as gaps in the test report — a skipped test is not a passing test.

## Rules

1. **Never use production credentials in tests.** `tests/setup.ts` deletes
   `TIKTOK_APP_KEY`/`TIKTOK_APP_SECRET` from the environment and pins
   `DEMO_MODE=true`. The encryption key there is a fixed test fixture —
   treat it as public.
2. **Never commit `test.db`.** It is a local artifact (add to `.gitignore`
   if you use git).
3. **Never invent TikTok behavior in tests.** Tests against `lib/tiktok/*`
   verify generic properties (determinism, labeling) or worked examples taken
   verbatim from official Partner Center docs. Anything pending verification
   stays `it.skip` with a TODO pointing at `docs/ASSUMPTIONS.md`.
4. Integration tests authenticate via `signInAs(userId)` (session row +
   mocked cookie), never by calling undocumented internals.
