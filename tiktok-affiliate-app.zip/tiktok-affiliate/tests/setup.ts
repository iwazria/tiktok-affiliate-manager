/**
 * Global vitest setup. Runs BEFORE any test file is imported, so env vars set
 * here are visible to modules (e.g. lib/config.ts) evaluated at import time.
 *
 * Tests always run against an isolated SQLite file (./test.db), demo mode on,
 * and fixed test-only secrets. NEVER point this at a production database or
 * real TikTok credentials — see tests/README.md.
 */
import path from "path";

// NODE_ENV is typed readonly; cast for the test harness.
(process.env as Record<string, string | undefined>).NODE_ENV = "test";
// Absolute file: URL so the Prisma CLI (which resolves relative paths from the
// schema directory) and the Prisma client (same) agree on the same file.
process.env.DATABASE_URL =
  "file:" + path.resolve(process.cwd(), "test.db");
// 64-hex test-only encryption key (test fixture, NOT a real secret).
process.env.ENCRYPTION_KEY =
  "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
process.env.ENCRYPTION_KEY_VERSION = "1";
process.env.SESSION_SECRET = "test-session-secret-do-not-use-in-production";
process.env.DEMO_MODE = "true";
// Ensure no half-configured live credentials leak into tests.
delete process.env.TIKTOK_APP_KEY;
delete process.env.TIKTOK_APP_SECRET;
