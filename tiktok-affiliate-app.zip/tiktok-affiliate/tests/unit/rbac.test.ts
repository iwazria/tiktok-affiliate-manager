import { describe, expect, it } from "vitest";
import { ROLE_RANK, ROLES, roleAtLeast } from "@/lib/rbac";

describe("ROLE_RANK ordering", () => {
  it("defines the documented hierarchy owner > admin > campaign_manager > analyst > read_only", () => {
    expect(ROLE_RANK.owner).toBe(0);
    expect(ROLE_RANK.admin).toBe(1);
    expect(ROLE_RANK.campaign_manager).toBe(2);
    expect(ROLE_RANK.analyst).toBe(3);
    expect(ROLE_RANK.read_only).toBe(4);
  });

  it("exposes every role in ROLES", () => {
    expect(new Set(ROLES)).toEqual(
      new Set(["owner", "admin", "campaign_manager", "analyst", "read_only"])
    );
  });
});

describe("roleAtLeast", () => {
  const roles = ["owner", "admin", "campaign_manager", "analyst", "read_only"] as const;

  it("grants access when the caller's rank is equal or more privileged", () => {
    // For every (role, minimum) pair: allowed iff ROLE_RANK[role] <= ROLE_RANK[minimum]
    for (const role of roles) {
      for (const minimum of roles) {
        const expected = ROLE_RANK[role] <= ROLE_RANK[minimum];
        expect(roleAtLeast(role, minimum), `${role} >= ${minimum}`).toBe(expected);
      }
    }
  });

  it("sanity-checks key pairs", () => {
    expect(roleAtLeast("owner", "read_only")).toBe(true);
    expect(roleAtLeast("read_only", "owner")).toBe(false);
    expect(roleAtLeast("campaign_manager", "campaign_manager")).toBe(true);
    expect(roleAtLeast("analyst", "campaign_manager")).toBe(false);
    expect(roleAtLeast("admin", "owner")).toBe(false);
  });

  it("denies unknown roles (defensive default)", () => {
    expect(roleAtLeast("superadmin", "read_only")).toBe(false);
    expect(roleAtLeast("owner", "nonexistent")).toBe(true); // unknown minimum ranks lowest
    expect(roleAtLeast("nonexistent", "nonexistent")).toBe(true); // 99 <= 99
  });
});
