/**
 * Tests for `signTikTokRequest` in `lib/tiktok/http.ts`.
 *
 * The canonical-string algorithm is documented at the top of http.ts and MUST
 * be re-verified against the current Partner Center "signature generation"
 * docs before production use (see docs/ASSUMPTIONS.md). These tests pin the
 * documented worked example so any drift is caught immediately.
 *
 * Worked example (from lib/tiktok/http.ts):
 *   app_key    = "ttapp123"
 *   app_secret = "s3cr3t"
 *   params     = { page_size: "20", shop_id: "743186299", timestamp: "1718448000" }
 *   string_to_sign = "ttapp123page_size20shop_id743186299timestamp1718448000"
 *   expected sign  = HMAC-SHA256(key="s3cr3t", msg=string_to_sign).hexdigest()
 */
import { describe, expect, it } from "vitest";
import { createHmac } from "crypto";
import { signTikTokRequest } from "@/lib/tiktok/http";

const EXAMPLE = {
  appKey: "ttapp123",
  appSecret: "s3cr3t",
  params: { page_size: "20", shop_id: "743186299", timestamp: "1718448000" },
};
// Independently computed from the documented canonical string (not from the
// implementation under test): HMAC-SHA256("s3cr3t",
// "ttapp123page_size20shop_id743186299timestamp1718448000").
const EXPECTED_SIGN = "89f51657c31da852d83247bf6f2319cdc48a247edd59ef04087bb8a137fe30bd";

describe("signTikTokRequest", () => {
  it("matches the documented worked example", () => {
    expect(signTikTokRequest(EXAMPLE)).toBe(EXPECTED_SIGN);
  });

  it("cross-checks against an independent HMAC computation", () => {
    const canonical = "ttapp123page_size20shop_id743186299timestamp1718448000";
    const independent = createHmac("sha256", "s3cr3t").update(canonical, "utf8").digest("hex");
    expect(independent).toBe(EXPECTED_SIGN);
    expect(signTikTokRequest(EXAMPLE)).toBe(independent);
  });

  it("sorts parameters alphabetically regardless of input order", () => {
    const shuffled = signTikTokRequest({
      ...EXAMPLE,
      params: { timestamp: "1718448000", page_size: "20", shop_id: "743186299" },
    });
    expect(shuffled).toBe(EXPECTED_SIGN);
  });

  it("excludes sign and access_token from the canonical string", () => {
    const withExtras = signTikTokRequest({
      ...EXAMPLE,
      params: { ...EXAMPLE.params, sign: "old", access_token: "tok" },
    });
    expect(withExtras).toBe(EXPECTED_SIGN);
  });

  it("appends the raw body string for requests with a body", () => {
    const withBody = signTikTokRequest({ ...EXAMPLE, bodyString: '{"a":1}' });
    expect(withBody).not.toBe(EXPECTED_SIGN);
    expect(withBody).toMatch(/^[0-9a-f]{64}$/);
    // determinism with body
    expect(signTikTokRequest({ ...EXAMPLE, bodyString: '{"a":1}' })).toBe(withBody);
  });

  it("is deterministic and key-sensitive", () => {
    expect(signTikTokRequest(EXAMPLE)).toBe(signTikTokRequest(EXAMPLE));
    expect(signTikTokRequest({ ...EXAMPLE, appSecret: "other" })).not.toBe(EXPECTED_SIGN);
  });

  it("returns lowercase hex", () => {
    expect(signTikTokRequest(EXAMPLE)).toMatch(/^[0-9a-f]{64}$/);
  });
});
