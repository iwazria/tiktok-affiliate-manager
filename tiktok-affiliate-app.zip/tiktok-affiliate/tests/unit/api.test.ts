import { describe, expect, it } from "vitest";
import { z } from "zod";
import { ok, fail, zodFail } from "@/lib/api";

describe("API response envelope (ARCHITECTURE.md contract)", () => {
  it("ok() returns { ok: true, data } with status 200", async () => {
    const res = ok({ campaigns: [1, 2] });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toEqual({ ok: true, data: { campaigns: [1, 2] } });
  });

  it("ok() honors a custom status", async () => {
    const res = ok({ id: "x" }, 201);
    expect(res.status).toBe(201);
    expect((await res.json()).ok).toBe(true);
  });

  it("fail() returns { ok: false, error: { code, message } }", async () => {
    const res = fail("not_found", "Campaign not found.", 404);
    expect(res.status).toBe(404);
    const body = await res.json();
    expect(body).toEqual({
      ok: false,
      error: { code: "not_found", message: "Campaign not found." },
    });
  });

  it("fail() includes fieldErrors when provided", async () => {
    const res = fail("validation_error", "Fix fields.", 422, {
      name: ["Required"],
    });
    const body = await res.json();
    expect(body.ok).toBe(false);
    expect(body.error.fieldErrors).toEqual({ name: ["Required"] });
  });

  it("zodFail() maps Zod issues to field errors with status 422", async () => {
    const schema = z.object({
      name: z.string().min(3),
      commissionRate: z.number().min(0).max(100),
    });
    const parsed = schema.safeParse({ name: "ab", commissionRate: 150 });
    expect(parsed.success).toBe(false);
    if (parsed.success) return;
    const res = zodFail(parsed.error);
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(body.ok).toBe(false);
    expect(body.error.code).toBe("validation_error");
    expect(body.error.fieldErrors.name).toBeDefined();
    expect(body.error.fieldErrors.commissionRate).toBeDefined();
  });

  it("zodFail() handles top-level (pathless) issues under '_'", async () => {
    const schema = z.string().refine((s) => s === "x", { message: "must be x" });
    const parsed = schema.safeParse("y");
    expect(parsed.success).toBe(false);
    if (parsed.success) return;
    const body = await zodFail(parsed.error).json();
    expect(body.error.fieldErrors._).toEqual(["must be x"]);
  });
});
