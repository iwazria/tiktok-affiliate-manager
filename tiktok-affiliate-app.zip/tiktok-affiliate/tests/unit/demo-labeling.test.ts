/**
 * Tests for `DemoTikTokAdapter` (lib/tiktok/demoAdapter.ts).
 *
 * Spec §1 / ARCHITECTURE.md rule: EVERY payload produced in demo mode must
 * carry demo labeling (`source: "demo"`) so the UI can never present
 * simulated values as live TikTok data.
 */
import { describe, expect, it, beforeEach } from "vitest";
import { DemoTikTokAdapter } from "@/lib/tiktok/demoAdapter";
import { TikTokCapabilityError } from "@/lib/tiktok/errors";

let adapter: DemoTikTokAdapter;

beforeEach(() => {
  adapter = new DemoTikTokAdapter();
});

describe("demo adapter labeling", () => {
  it("every product payload carries source 'demo'", async () => {
    const page = await adapter.listProducts({ page: 1, pageSize: 50 });
    expect(page.items.length).toBeGreaterThan(0);
    expect(page.source).toBe("demo");
    for (const p of page.items) {
      expect(p.source).toBe("demo");
    }
    const one = await adapter.getProduct("p-1001");
    expect(one?.source).toBe("demo");
  });

  it("every campaign payload carries source 'demo'", async () => {
    const page = await adapter.listCampaigns({ page: 1, pageSize: 50 });
    expect(page.items.length).toBeGreaterThan(0);
    expect(page.source).toBe("demo");
    for (const c of page.items) {
      expect(c.source).toBe("demo");
    }
  });

  it("every collaboration payload carries source 'demo'", async () => {
    const collabs = await adapter.listCollaborations("demo-campaign-1");
    expect(collabs.length).toBeGreaterThan(0);
    for (const c of collabs) {
      expect(c.source).toBe("demo");
    }
  });

  it("performance metrics carry source 'demo' with quality markers", async () => {
    const metrics = await adapter.getPerformanceMetrics({
      dateFrom: "2026-09-16",
      dateTo: "2026-10-15",
      campaignId: "demo-campaign-1",
    });
    expect(metrics.source).toBe("demo");
    expect(metrics.points.length).toBeGreaterThan(0);
    for (const p of metrics.points) {
      expect(["pending", "final"]).toContain(p.quality);
    }
    expect(["pending", "final"]).toContain(metrics.quality);
    expect(metrics.timezone).toBeTruthy();
    expect(metrics.syncedAt).toBeTruthy();
  });

  it("shop info is labeled demo", async () => {
    const info = await adapter.getAuthorizedShopInfo();
    expect(info.source).toBe("demo");
    expect(info.tiktokShopId).toBeTruthy();
  });

  it("creator search throws TikTokCapabilityError (not approved, even in demo)", async () => {
    await expect(adapter.searchCreators("beauty")).rejects.toBeInstanceOf(
      TikTokCapabilityError
    );
  });

  it("created demo campaigns are labeled demo and stay local drafts", async () => {
    const created = await adapter.createCampaign({
      name: "Test draft",
      productIds: ["p-1001"],
    });
    expect(created.source).toBe("demo");
    expect(created.status).toBe("draft");
    expect(created.tiktokCampaignId).toBeNull();
  });

  it("rejects campaigns with ineligible products (PRODUCT_INELIGIBLE)", async () => {
    await expect(
      adapter.createCampaign({ name: "Bad", productIds: ["p-1003"] })
    ).rejects.toMatchObject({ code: "PRODUCT_INELIGIBLE" });
  });

  it("rejects duplicate invitations (DUPLICATE_INVITATION)", async () => {
    await expect(
      adapter.inviteCreator("demo-campaign-1", {
        creatorRef: { handle: "@desksetupdan" },
      })
    ).rejects.toMatchObject({ code: "DUPLICATE_INVITATION" });
  });

  it("never exposes secrets in adapter output", async () => {
    const json = JSON.stringify([
      await adapter.listProducts({ page: 1, pageSize: 5 }),
      await adapter.listCampaigns({ page: 1, pageSize: 5 }),
      await adapter.getAuthorizedShopInfo(),
    ]);
    expect(json).not.toMatch(/app_secret|access_token|refresh_token/i);
  });
});
