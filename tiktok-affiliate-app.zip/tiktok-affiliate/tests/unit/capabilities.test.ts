/**
 * Tests for `lib/tiktok/capabilities.ts` — the feature capability registry.
 *
 * Contract (ARCHITECTURE.md + spec §6):
 * - demo mode enables product_sync/campaign_create as demoOnly (labeled)
 * - live mode without granted scopes disables scope-gated features w/ reason
 * - creator_search is unavailable with a pending-approval explanation
 */
import { describe, expect, it } from "vitest";
import { getCapabilities } from "@/lib/tiktok/capabilities";

describe("getCapabilities", () => {
  it("demo mode enables product_sync and campaign_create as demoOnly", () => {
    const caps = getCapabilities({ mode: "demo", scopes: [], region: "US" });
    for (const key of ["product_sync", "campaign_create"] as const) {
      const cap = caps[key];
      expect(cap.available, key).toBe(true);
      expect(cap.demoOnly, `${key} must be labeled demo`).toBe(true);
    }
  });

  it("demo mode still marks creator_search unavailable with a pending-approval reason", () => {
    const caps = getCapabilities({ mode: "demo", scopes: [], region: "US" });
    const cap = caps.creator_search;
    expect(cap.available).toBe(false);
    expect(cap.reason ?? "").toMatch(/approv/i);
  });

  it("live mode without scopes disables scope-gated capabilities with reasons", () => {
    const caps = getCapabilities({ mode: "live", scopes: [], region: "US" });
    for (const key of ["product_sync", "campaign_create", "metrics"] as const) {
      const cap = caps[key];
      expect(cap.available, key).toBe(false);
      expect(cap.reason, `${key} should explain why`).toBeTruthy();
      expect(cap.requiredScope, `${key} should name the scope`).toBeTruthy();
    }
  });

  it("live mode with the right scopes enables features whose endpoints are verified", () => {
    // productSearch is the one endpoint marked "verified" in endpoints.ts.
    const caps = getCapabilities({
      mode: "live",
      scopes: ["product.info"],
      region: "US",
    });
    expect(caps.product_sync.available).toBe(true);
    // affiliate endpoints are pending_approval → still disabled even with scopes
    const campaignCaps = getCapabilities({
      mode: "live",
      scopes: ["product.info", "affiliate.campaign", "affiliate.creator"],
      region: "US",
    });
    expect(campaignCaps.campaign_create.available).toBe(false);
    expect(campaignCaps.campaign_create.approval).toBe("pending_approval");
  });

  it("creator_search is unavailable in live mode with a pending-approval reason", () => {
    const caps = getCapabilities({
      mode: "live",
      scopes: ["affiliate.creator"],
      region: "US",
    });
    expect(caps.creator_search.available).toBe(false);
    expect(caps.creator_search.reason ?? "").toMatch(/approv/i);
  });

  it("the export capability is local and always available", () => {
    expect(getCapabilities({ mode: "demo", scopes: [] }).export.available).toBe(true);
    expect(getCapabilities({ mode: "live", scopes: [] }).export.available).toBe(true);
  });

  it("never reports live availability for demo-mode capabilities", () => {
    const caps = getCapabilities({ mode: "demo", scopes: [], region: "US" });
    for (const [key, cap] of Object.entries(caps)) {
      if (cap.available) {
        expect(cap.demoOnly === true || key === "export", `${key}`).toBe(true);
      }
    }
  });
});
