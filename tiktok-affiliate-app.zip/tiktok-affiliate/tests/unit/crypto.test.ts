import { describe, expect, it, beforeEach, afterEach } from "vitest";
import {
  encryptSecret,
  decryptSecret,
  redactSecrets,
  type EncryptedEnvelope,
} from "@/lib/crypto";
import { config } from "@/lib/config";

describe("encryptSecret / decryptSecret (AES-256-GCM envelope)", () => {
  it("round-trips arbitrary plaintext", () => {
    const plaintext = "tiktok-access-token-abc123";
    const payload = encryptSecret(plaintext);
    expect(typeof payload).toBe("string");
    expect(decryptSecret(payload)).toBe(plaintext);
  });

  it("round-trips unicode and empty strings", () => {
    for (const s of ["", "🔑 shop-机密", "a".repeat(4096)]) {
      expect(decryptSecret(encryptSecret(s))).toBe(s);
    }
  });

  it("produces non-deterministic ciphertext (random IV)", () => {
    const a = encryptSecret("same");
    const b = encryptSecret("same");
    expect(a).not.toBe(b);
    expect(decryptSecret(a)).toBe("same");
    expect(decryptSecret(b)).toBe("same");
  });

  it("envelope carries the key version", () => {
    const env = JSON.parse(encryptSecret("x")) as EncryptedEnvelope;
    expect(env.alg).toBe("aes-256-gcm");
    expect(env.keyVersion).toBe(config.encryptionKeyVersion);
    expect(env.iv).toBeTruthy();
    expect(env.tag).toBeTruthy();
    expect(env.data).toBeTruthy();
  });

  it("decryption with the wrong key fails (authentication tag mismatch)", () => {
    const payload = encryptSecret("super-secret");
    const original = config.encryptionKey;
    config.encryptionKey =
      "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";
    try {
      expect(() => decryptSecret(payload)).toThrow();
    } finally {
      config.encryptionKey = original;
    }
    // sanity: original key still works after restore
    expect(decryptSecret(payload)).toBe("super-secret");
  });

  it("tampered ciphertext fails authentication", () => {
    const env = JSON.parse(encryptSecret("token")) as EncryptedEnvelope;
    // flip a character in the base64 payload
    env.data = (env.data[0] === "A" ? "B" : "A") + env.data.slice(1);
    expect(() => decryptSecret(JSON.stringify(env))).toThrow();
  });

  it("rejects a non-GCM envelope", () => {
    const bad = JSON.stringify({ alg: "aes-256-cbc", iv: "x", tag: "y", data: "z", keyVersion: 1 });
    expect(() => decryptSecret(bad)).toThrow(/Unsupported encryption algorithm/);
  });
});

describe("redactSecrets", () => {
  it("redacts values whose keys look like secrets (case-insensitive)", () => {
    const input = {
      accessToken: "abc",
      appSecret: "def",
      password: "hunter2",
      authCode: "xyz",
      apiKey: "k",
      authorization: "Bearer t",
      nested: { refresh_token: "r", plain: "keep" },
    };
    const out = redactSecrets(input) as Record<string, unknown>;
    expect(out.accessToken).toBe("[redacted]");
    expect(out.appSecret).toBe("[redacted]");
    expect(out.password).toBe("[redacted]");
    expect(out.authCode).toBe("[redacted]");
    expect(out.apiKey).toBe("[redacted]");
    expect(out.authorization).toBe("[redacted]");
    const nested = out.nested as Record<string, unknown>;
    expect(nested.refresh_token).toBe("[redacted]");
    expect(nested.plain).toBe("keep");
  });

  it("redacts string content that itself mentions a secret keyword", () => {
    expect(redactSecrets("here is my access token: abc")).toBe("[redacted]");
    expect(redactSecrets("plain harmless message")).toBe("plain harmless message");
  });

  it("handles arrays and primitives", () => {
    const out = redactSecrets([{ secret: "s" }, 42, null, "ok"]) as unknown[];
    expect((out[0] as Record<string, unknown>).secret).toBe("[redacted]");
    expect(out[1]).toBe(42);
    expect(out[2]).toBe(null);
    expect(out[3]).toBe("ok");
  });

  it("does not mutate the input object", () => {
    const input = { accessToken: "abc" };
    redactSecrets(input);
    expect(input.accessToken).toBe("abc");
  });
});

// Suppress unused-import lint noise for afterEach/beforeEach kept for future fixtures.
void beforeEach;
void afterEach;
