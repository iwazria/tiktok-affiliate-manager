"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { apiFetch } from "@/lib/client";
import type { MeResponse } from "@/lib/types";

/** Root: send signed-in users to their first org, everyone else to /signin. */
export default function RootPage(): React.JSX.Element {
  const router = useRouter();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const me = await apiFetch<MeResponse>("/api/auth/me");
        if (cancelled) return;
        const first = me.memberships[0];
        router.replace(first ? `/${first.organization.slug}/overview` : "/signin");
      } catch {
        if (!cancelled) router.replace("/signin");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [router]);

  return (
    <div className="grid min-h-screen place-items-center bg-slate-50">
      <div className="flex flex-col items-center gap-3" role="status" aria-label="Loading">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-indigo-600" />
        <p className="text-sm text-slate-500">Loading your workspace…</p>
      </div>
    </div>
  );
}
