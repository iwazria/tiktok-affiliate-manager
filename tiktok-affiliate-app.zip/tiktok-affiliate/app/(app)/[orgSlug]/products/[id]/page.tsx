"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { apiFetch, ApiRequestError, getErrorMessage, isForbidden } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/format";
import type { Product } from "@/lib/types";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";
import { Alert } from "@/components/Alert";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { PermissionDenied } from "@/components/PermissionDenied";
import { DataSourceLabel } from "@/components/DataSourceLabel";
import { EmptyBoxIcon } from "@/components/icons";

function extractProduct(data: unknown): Product | null {
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    const inner = (d.product ?? d) as Record<string, unknown>;
    if (typeof inner.id === "string") return inner as unknown as Product;
  }
  return null;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">
        {label}
      </dt>
      <dd className="mt-1 text-sm text-slate-900">{children}</dd>
    </div>
  );
}

export default function ProductDetailPage(): React.JSX.Element {
  const { orgId, orgSlug } = useOrg();
  const params = useParams<{ orgSlug: string; id: string }>();
  const slug = orgSlug || params.orgSlug;
  const id = params.id;

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [forbidden, setForbidden] = useState(false);

  useEffect(() => {
    if (!orgId || !id) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      setForbidden(false);
      try {
        let p: Product | null = null;
        try {
          const data = await apiFetch<unknown>(
            `/api/orgs/${orgId}/products/${encodeURIComponent(id)}`
          );
          p = extractProduct(data);
        } catch (err) {
          // Fallback: the detail endpoint may not exist; find the product via the list.
          if (!(err instanceof ApiRequestError) || (err.status !== 404 && err.status !== 405)) {
            throw err;
          }
          const list = await apiFetch<unknown>(
            `/api/orgs/${orgId}/products?page=1&pageSize=100`
          );
          const items = Array.isArray(list)
            ? list
            : Array.isArray((list as { items?: unknown }).items)
              ? (list as { items: unknown[] }).items
              : [];
          p = (items as Product[]).find((it) => it.id === id) ?? null;
        }
        if (cancelled) return;
        if (!p) throw new Error("Product not found.");
        setProduct(p);
      } catch (err) {
        if (cancelled) return;
        if (isForbidden(err)) setForbidden(true);
        else setError(getErrorMessage(err));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [orgId, id]);

  if (loading) {
    return (
      <div aria-label="Loading product">
        <Link
          href={`/${slug}/products`}
          className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
        >
          ← Products
        </Link>
        <div className="mt-4">
          <SkeletonLines lines={10} />
        </div>
      </div>
    );
  }

  if (forbidden) {
    return (
      <PermissionDenied
        title="You don't have access to this product"
        body="Your role doesn't include permission to view products. Ask an admin to upgrade your role."
      />
    );
  }

  if (error || !product) {
    return (
      <div className="space-y-6">
        <Link
          href={`/${slug}/products`}
          className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
        >
          ← Products
        </Link>
        <Alert tone="error" title="Could not load product">
          {error ?? "This product could not be found."}
        </Alert>
        <EmptyState
          icon={<EmptyBoxIcon className="h-10 w-10" />}
          title="Product unavailable"
          body="The product may have been removed from the catalog."
          action={
            <Button variant="secondary" href={`/${slug}/products`}>
              Back to products
            </Button>
          }
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link
        href={`/${slug}/products`}
        className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
      >
        ← Products
      </Link>

      <Card
        title={product.name || "Unnamed product"}
        actions={
          product.isDemo ? (
            <Badge tone="yellow">Demo</Badge>
          ) : undefined
        }
      >
        <div className="flex flex-col gap-6 sm:flex-row">
          {product.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={product.imageUrl}
              alt={product.name ?? "Product image"}
              className="h-48 w-48 shrink-0 rounded-xl object-cover"
            />
          ) : (
            <span
              className="flex h-48 w-48 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-400"
              aria-label="No product image"
            >
              <EmptyBoxIcon className="h-12 w-12" />
            </span>
          )}

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={product.status === "ACTIVE" ? "green" : "gray"}>
                {product.status ?? "Unknown"}
              </Badge>
              <Badge tone={product.affiliateEligible ? "green" : "gray"}>
                {product.affiliateEligible ? "Eligible" : "Not eligible"}
              </Badge>
              {product.isDemo && <DataSourceLabel source="demo" />}
            </div>

            <dl className="mt-6 grid gap-4 sm:grid-cols-2">
              <Field label="Product ID">
                <span className="font-mono text-xs">{product.id}</span>
              </Field>
              <Field label="TikTok product ID">
                <span className="font-mono text-xs">
                  {product.tiktokProductId || "—"}
                </span>
              </Field>
              <Field label="Price">
                {formatCurrency(product.price, product.currency)}
              </Field>
              <Field label="Currency">{product.currency ?? "—"}</Field>
              <Field label="Status">{product.status ?? "—"}</Field>
              <Field label="Stock">{formatNumber(product.stock)}</Field>
              <Field label="Affiliate eligibility">
                {product.affiliateEligible ? "Eligible" : "Not eligible"}
              </Field>
              <Field label="Last synced">
                {product.lastSyncedAt ? formatDateTime(product.lastSyncedAt) : "—"}
              </Field>
            </dl>

            {product.lastSyncedAt && (
              <div className="mt-4">
                <DataSourceLabel
                  source={product.isDemo ? "demo" : "live"}
                  syncedAt={product.lastSyncedAt}
                />
              </div>
            )}
          </div>
        </div>

        {!product.affiliateEligible && product.ineligibilityReason && (
          <div className="mt-6">
            <Alert tone="warning" title="Not eligible for affiliate promotion">
              {product.ineligibilityReason}
            </Alert>
          </div>
        )}

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button
            variant="primary"
            href={`/${slug}/campaigns/new?products=${encodeURIComponent(product.id)}`}
            disabled={!product.affiliateEligible}
          >
            Use in campaign
          </Button>
        </div>

        <p className="mt-4 text-xs text-slate-500">
          Product details come from TikTok Shop and can't be edited here.
        </p>
      </Card>
    </div>
  );
}
