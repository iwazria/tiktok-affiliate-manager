"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { apiFetch, getErrorMessage, isForbidden } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import { formatCurrency, formatNumber, timeAgo } from "@/lib/format";
import type { Paginated, Product } from "@/lib/types";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";
import { Alert } from "@/components/Alert";
import { EmptyState } from "@/components/EmptyState";
import { Input } from "@/components/Input";
import { Select } from "@/components/Select";
import { Table } from "@/components/Table";
import { Pagination } from "@/components/Pagination";
import { SkeletonLines } from "@/components/Skeleton";
import { PermissionDenied } from "@/components/PermissionDenied";
import { DataSourceLabel } from "@/components/DataSourceLabel";
import { EmptyBoxIcon, SearchIcon } from "@/components/icons";

const PAGE_SIZE = 12;

function extractPage(data: unknown): Paginated<Product> {
  if (data && typeof data === "object") {
    const d = data as Partial<Paginated<Product>>;
    if (Array.isArray(d.items)) {
      return {
        items: d.items,
        page: typeof d.page === "number" ? d.page : 1,
        pageSize: typeof d.pageSize === "number" ? d.pageSize : PAGE_SIZE,
        total: typeof d.total === "number" ? d.total : d.items.length,
        totalPages:
          typeof d.totalPages === "number"
            ? d.totalPages
            : Math.max(1, Math.ceil((d.total ?? d.items.length) / PAGE_SIZE)),
      };
    }
  }
  if (Array.isArray(data)) {
    return {
      items: data as Product[],
      page: 1,
      pageSize: PAGE_SIZE,
      total: data.length,
      totalPages: 1,
    };
  }
  return { items: [], page: 1, pageSize: PAGE_SIZE, total: 0, totalPages: 1 };
}

export default function ProductsPage(): React.JSX.Element {
  const { orgId, orgSlug, selectedShop, shopsLoading, loading: orgLoading } = useOrg();
  const params = useParams<{ orgSlug: string }>();
  const slug = orgSlug || params.orgSlug;

  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [eligible, setEligible] = useState("");
  const [sort, setSort] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Paginated<Product> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [forbidden, setForbidden] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // Debounce the search input before it hits the API.
  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(searchInput.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [searchInput]);

  const shopId = selectedShop?.id ?? null;

  const query = useMemo(() => {
    const qs = new URLSearchParams();
    if (shopId) qs.set("shopId", shopId);
    if (search) qs.set("search", search);
    if (status) qs.set("status", status);
    if (eligible) qs.set("eligible", eligible);
    if (sort) qs.set("sort", sort);
    qs.set("page", String(page));
    qs.set("pageSize", String(PAGE_SIZE));
    return qs.toString();
  }, [shopId, search, status, eligible, sort, page]);

  const load = useCallback(async () => {
    if (!orgId || !shopId) return;
    setLoading(true);
    setError(null);
    try {
      const result = await apiFetch<unknown>(`/api/orgs/${orgId}/products?${query}`);
      setData(extractPage(result));
    } catch (err) {
      if (isForbidden(err)) setForbidden(true);
      else setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [orgId, shopId, query]);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  if (orgLoading || shopsLoading) {
    return (
      <div aria-label="Loading products">
        <div className="h-8 w-48 animate-pulse rounded-lg bg-slate-200" />
        <div className="mt-6">
          <SkeletonLines lines={6} />
        </div>
      </div>
    );
  }

  if (!selectedShop) {
    return (
      <div className="space-y-6">
        <PageHeader title="Products" />
        <Card>
          <EmptyState
            icon={<EmptyBoxIcon className="h-10 w-10" />}
            title="Connect a shop to browse products"
            body="Products sync from your connected TikTok Shop catalog."
            action={
              <Button variant="primary" href={`/${slug}/settings`}>
                Go to Settings
              </Button>
            }
          />
        </Card>
      </div>
    );
  }

  if (forbidden) {
    return (
      <PermissionDenied
        title="You don't have access to products"
        body="Your role doesn't include permission to view products. Ask an admin to upgrade your role."
      />
    );
  }

  const retry = () => setRefreshKey((k) => k + 1);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Products"
        subtitle={
          selectedShop.mode === "demo" ? "Demo catalog — clearly labeled" : undefined
        }
        actions={
          selectedShop.mode === "demo" ? (
            <DataSourceLabel source="demo" syncedAt={selectedShop.lastSyncAt} />
          ) : undefined
        }
      />

      {error && (
        <Alert tone="error" title="Could not load products">
          <div className="flex items-center justify-between gap-4">
            <span>{error}</span>
            <Button variant="secondary" size="sm" onClick={retry}>
              Retry
            </Button>
          </div>
        </Alert>
      )}

      <Card>
        <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="relative">
            <Input
              label="Search"
              name="search"
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search products…"
              disabled={loading && !data}
            />
            <span className="pointer-events-none absolute right-3 top-[38px] text-slate-400">
              <SearchIcon className="h-4 w-4" />
            </span>
          </div>
          <Select
            label="Status"
            name="status"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
            options={[
              { value: "", label: "All statuses" },
              { value: "ACTIVE", label: "Active" },
              { value: "INACTIVE", label: "Inactive" },
            ]}
          />
          <Select
            label="Eligibility"
            name="eligible"
            value={eligible}
            onChange={(e) => {
              setEligible(e.target.value);
              setPage(1);
            }}
            options={[
              { value: "", label: "All products" },
              { value: "true", label: "Eligible only" },
              { value: "false", label: "Not eligible" },
            ]}
          />
          <Select
            label="Sort"
            name="sort"
            value={sort}
            onChange={(e) => {
              setSort(e.target.value);
              setPage(1);
            }}
            options={[
              { value: "", label: "Default" },
              { value: "name", label: "Name A–Z" },
              { value: "price-asc", label: "Price low → high" },
              { value: "price-desc", label: "Price high → low" },
              { value: "updated-desc", label: "Recently synced" },
            ]}
          />
        </div>

        {loading && !data ? (
          <SkeletonLines lines={8} />
        ) : data && data.items.length === 0 ? (
          <EmptyState
            icon={<EmptyBoxIcon className="h-10 w-10" />}
            title="No products found"
            body={
              search || status || eligible
                ? "Try adjusting your filters to see more products."
                : "Your product catalog is empty. Sync your shop from Settings to pull products in."
            }
            action={
              !search && !status && !eligible ? (
                <Button variant="secondary" href={`/${slug}/settings`}>
                  Sync in Settings
                </Button>
              ) : undefined
            }
          />
        ) : (
          data && (
            <>
              <Table
                ariaLabel="Products"
                rowKey={(row: Product) => row.id}
                data={data.items}
                columns={[
                  {
                    key: "product",
                    header: "Product",
                    render: (row: Product) => (
                      <div className="flex items-center gap-3">
                        {row.imageUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={row.imageUrl}
                            alt=""
                            className="h-10 w-10 shrink-0 rounded-lg object-cover"
                            loading="lazy"
                          />
                        ) : (
                          <span
                            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-400"
                            aria-hidden="true"
                          >
                            <EmptyBoxIcon className="h-5 w-5" />
                          </span>
                        )}
                        <div className="min-w-0">
                          <Link
                            href={`/${slug}/products/${row.id}`}
                            className="block truncate font-medium text-indigo-700 hover:text-indigo-800 hover:underline"
                          >
                            {row.name || "Unnamed product"}
                          </Link>
                          <p className="truncate font-mono text-xs text-slate-400">
                            {row.id}
                          </p>
                        </div>
                      </div>
                    ),
                  },
                  {
                    key: "price",
                    header: "Price",
                    render: (row: Product) => (
                      <span className="whitespace-nowrap text-sm text-slate-900">
                        {formatCurrency(row.price, row.currency)}
                      </span>
                    ),
                  },
                  {
                    key: "status",
                    header: "Status",
                    render: (row: Product) => (
                      <Badge tone={row.status === "ACTIVE" ? "green" : "gray"}>
                        {row.status ?? "—"}
                      </Badge>
                    ),
                  },
                  {
                    key: "stock",
                    header: "Stock",
                    render: (row: Product) => (
                      <span className="text-sm text-slate-900">
                        {formatNumber(row.stock)}
                      </span>
                    ),
                  },
                  {
                    key: "eligibility",
                    header: "Eligibility",
                    render: (row: Product) => (
                      <div>
                        <Badge tone={row.affiliateEligible ? "green" : "gray"}>
                          {row.affiliateEligible ? "Eligible" : "Not eligible"}
                        </Badge>
                        {!row.affiliateEligible && row.ineligibilityReason && (
                          <p
                            className="mt-1 max-w-48 truncate text-xs text-slate-500"
                            title={row.ineligibilityReason}
                          >
                            {row.ineligibilityReason}
                          </p>
                        )}
                      </div>
                    ),
                  },
                  {
                    key: "synced",
                    header: "Synced",
                    render: (row: Product) => (
                      <span className="whitespace-nowrap text-xs text-slate-500">
                        {row.lastSyncedAt ? timeAgo(row.lastSyncedAt) : "—"}
                      </span>
                    ),
                  },
                ]}
              />
              {data.totalPages > 1 && (
                <div className="mt-4 flex items-center justify-between">
                  <p className="text-sm text-slate-500">
                    {formatNumber(data.total)} product{data.total === 1 ? "" : "s"}
                  </p>
                  <Pagination
                    page={data.page}
                    totalPages={data.totalPages}
                    onChange={setPage}
                  />
                </div>
              )}
            </>
          )
        )}
      </Card>
    </div>
  );
}
