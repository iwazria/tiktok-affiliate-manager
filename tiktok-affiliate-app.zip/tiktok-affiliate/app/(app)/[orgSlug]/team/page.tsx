"use client";

import { useEffect, useMemo, useState } from "react";
import { apiFetch, getErrorMessage, getFieldErrors } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import type { TeamInvitation, TeamMember } from "@/lib/types";
import { formatDate } from "@/lib/format";
import { roleLabel, ROLE_OPTIONS } from "@/lib/roles";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { Input } from "@/components/Input";
import { Select } from "@/components/Select";
import { Alert } from "@/components/Alert";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { PageHeader } from "@/components/PageHeader";
import { Table } from "@/components/Table";
import { Can } from "@/components/RoleGate";
import { FormErrors } from "@/components/FieldError";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { TeamIcon, RefreshIcon } from "@/components/icons";

function asArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const items = (data as { items?: unknown }).items;
    if (Array.isArray(items)) return items as T[];
  }
  return [];
}

function statusTone(status: string): "green" | "yellow" | "gray" {
  if (status === "active") return "green";
  if (status === "invited") return "yellow";
  return "gray";
}

function statusLabel(status: string): string {
  if (status === "active") return "Active";
  if (status === "invited") return "Invited";
  if (status === "revoked") return "Revoked";
  return status;
}

export default function TeamPage(): React.JSX.Element {
  const { orgId, role } = useOrg();

  const [members, setMembers] = useState<TeamMember[]>([]);
  const [membersLoading, setMembersLoading] = useState(true);
  const [membersError, setMembersError] = useState<string | null>(null);
  const [membersNonce, setMembersNonce] = useState(0);

  const [invitations, setInvitations] = useState<TeamInvitation[]>([]);
  const [invitationsLoading, setInvitationsLoading] = useState(true);
  const [invitationsError, setInvitationsError] = useState<string | null>(null);

  const [roleSaving, setRoleSaving] = useState<string | null>(null);
  const [roleError, setRoleError] = useState<string | null>(null);

  const [removeTarget, setRemoveTarget] = useState<TeamMember | null>(null);
  const [removing, setRemoving] = useState(false);
  const [removeError, setRemoveError] = useState<string | null>(null);

  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("campaign_manager");
  const [inviteErrors, setInviteErrors] = useState<Record<string, string[]> | null>(null);
  const [inviteSubmitting, setInviteSubmitting] = useState(false);
  const [inviteSuccess, setInviteSuccess] = useState<string | null>(null);

  const [revokeTarget, setRevokeTarget] = useState<TeamInvitation | null>(null);
  const [revoking, setRevoking] = useState(false);
  const [resendNote, setResendNote] = useState<string | null>(null);
  const [resending, setResending] = useState<string | null>(null);

  const owners = useMemo(
    () => members.filter((m) => m.role === "owner" && m.status === "active"),
    [members]
  );
  const pending = useMemo(
    () => invitations.filter((i) => i.status === "pending"),
    [invitations]
  );

  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    setMembersLoading(true);
    setMembersError(null);
    apiFetch<unknown>(`/api/orgs/${orgId}/members`)
      .then((d) => {
        if (cancelled) return;
        setMembers(asArray<TeamMember>(d));
        setMembersLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setMembersError(getErrorMessage(e));
        setMembersLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, membersNonce]);

  const loadInvitations = () => {
    if (!orgId) return;
    setInvitationsLoading(true);
    setInvitationsError(null);
    apiFetch<unknown>(`/api/orgs/${orgId}/invitations`)
      .then((d) => {
        setInvitations(asArray<TeamInvitation>(d));
        setInvitationsLoading(false);
      })
      .catch((e) => {
        setInvitationsError(getErrorMessage(e));
        setInvitationsLoading(false);
      });
  };

  useEffect(() => {
    loadInvitations();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  const changeRole = async (member: TeamMember, newRole: string) => {
    if (!orgId || !newRole || newRole === member.role) return;
    if (member.role === "owner" && owners.length === 1) {
      setRoleError("You can't change the role of the final owner.");
      return;
    }
    setRoleSaving(member.id);
    setRoleError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/members/${member.id}`, {
        method: "PATCH",
        body: JSON.stringify({ role: newRole }),
      });
      setMembersNonce((n) => n + 1);
    } catch (e) {
      setRoleError(getErrorMessage(e));
    } finally {
      setRoleSaving(null);
    }
  };

  const requestRemove = (member: TeamMember) => {
    if (member.role === "owner" && owners.length === 1) {
      setRemoveError("You can't remove the final owner.");
      return;
    }
    setRemoveError(null);
    setRemoveTarget(member);
  };

  const confirmRemove = async () => {
    if (!orgId || !removeTarget) return;
    setRemoving(true);
    setRemoveError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/members/${removeTarget.id}`, {
        method: "DELETE",
      });
      setRemoveTarget(null);
      setMembersNonce((n) => n + 1);
    } catch (e) {
      setRemoveError(getErrorMessage(e));
    } finally {
      setRemoving(false);
    }
  };

  const sendInvite = async () => {
    if (!orgId || inviteSubmitting) return;
    setInviteSubmitting(true);
    setInviteErrors(null);
    setInviteSuccess(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/invitations`, {
        method: "POST",
        body: JSON.stringify({ email: inviteEmail.trim(), role: inviteRole }),
      });
      setInviteSuccess(`Invitation sent to ${inviteEmail.trim()}.`);
      setInviteEmail("");
      setInviteErrors(null);
      loadInvitations();
      setMembersNonce((n) => n + 1);
    } catch (e) {
      const fieldErrors = getFieldErrors(e);
      setInviteErrors(fieldErrors ?? { _form: [getErrorMessage(e)] });
      // input is preserved on error (email/role state untouched)
    } finally {
      setInviteSubmitting(false);
    }
  };

  const resendInvite = async (inv: TeamInvitation) => {
    if (!orgId) return;
    setResending(inv.id);
    setResendNote(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/invitations/${inv.id}/resend`, {
        method: "POST",
      });
      setResendNote(`Invitation re-sent to ${inv.email}.`);
    } catch (e) {
      setResendNote(getErrorMessage(e));
    } finally {
      setResending(null);
    }
  };

  const confirmRevoke = async () => {
    if (!orgId || !revokeTarget) return;
    setRevoking(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/invitations/${revokeTarget.id}`, {
        method: "DELETE",
      });
      setRevokeTarget(null);
      loadInvitations();
    } catch (e) {
      setInvitationsError(getErrorMessage(e));
      setRevokeTarget(null);
    } finally {
      setRevoking(false);
    }
  };

  const isLastActiveOwner = (m: TeamMember) =>
    m.role === "owner" && m.status === "active" && owners.length === 1;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Team"
        subtitle="Manage who can access this organization."
      />

      <Card title="Members" subtitle="People with access to this organization.">
        {roleError && (
          <Alert tone="error" title="Couldn’t change role" onDismiss={() => setRoleError(null)}>
            <p className="text-sm">{roleError}</p>
          </Alert>
        )}
        {removeError && (
          <Alert tone="error" title="Couldn’t remove member" onDismiss={() => setRemoveError(null)}>
            <p className="text-sm">{removeError}</p>
          </Alert>
        )}
        {membersLoading ? (
          <SkeletonLines lines={5} />
        ) : membersError ? (
          <div className="space-y-3">
            <Alert tone="error" title="Couldn’t load members">
              <p className="text-sm">{membersError}</p>
            </Alert>
            <Button variant="secondary" size="sm" onClick={() => setMembersNonce((n) => n + 1)}>
              <RefreshIcon className="h-4 w-4" /> Retry
            </Button>
          </div>
        ) : members.length === 0 ? (
          <EmptyState
            icon={<TeamIcon className="h-10 w-10" />}
            title="No members yet"
            body="Invite someone below to get started."
          />
        ) : (
          <Table
            ariaLabel="Team members"
            rowKey={(m: TeamMember) => m.id}
            data={members}
            columns={[
              {
                key: "member",
                header: "Member",
                render: (m: TeamMember) => (
                  <div>
                    <p className="font-medium text-slate-900">{m.name || "—"}</p>
                    <p className="text-sm text-slate-500">{m.email}</p>
                  </div>
                ),
              },
              {
                key: "role",
                header: "Role",
                render: (m: TeamMember) => (
                  <Can
                    minRole="admin"
                    fallback={<span className="text-sm text-slate-700">{roleLabel(m.role)}</span>}
                  >
                    <Select
                      label={`Role for ${m.email}`}
                      name={`role-${m.id}`}
                      value={m.role}
                      disabled={roleSaving === m.id || isLastActiveOwner(m)}
                      onChange={(e) => changeRole(m, e.target.value)}
                      options={ROLE_OPTIONS}
                    />
                  </Can>
                ),
              },
              {
                key: "status",
                header: "Status",
                render: (m: TeamMember) => (
                  <Badge tone={statusTone(m.status)}>{statusLabel(m.status)}</Badge>
                ),
              },
              {
                key: "joined",
                header: "Joined",
                render: (m: TeamMember) => (
                  <span className="text-sm text-slate-600">{formatDate(m.createdAt)}</span>
                ),
              },
              {
                key: "actions",
                header: "Actions",
                render: (m: TeamMember) => (
                  <Can minRole="admin">
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => requestRemove(m)}
                      ariaLabel={`Remove ${m.email}`}
                    >
                      Remove
                    </Button>
                  </Can>
                ),
              },
            ]}
          />
        )}
      </Card>

      <Card title="Invite a member" subtitle="They’ll receive an email invitation to join.">
        <Can
          minRole="admin"
          fallback={
            <p className="text-sm text-slate-500">
              Only admins can invite new members.
            </p>
          }
        >
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              sendInvite();
            }}
          >
            {inviteSuccess && (
              <Alert tone="success" title="Invitation sent" onDismiss={() => setInviteSuccess(null)}>
                <p className="text-sm">{inviteSuccess}</p>
              </Alert>
            )}
            <FormErrors errors={inviteErrors} />
            <div className="grid gap-4 sm:grid-cols-2">
              <Input
                label="Email"
                name="invite-email"
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="teammate@example.com"
                required
                disabled={inviteSubmitting}
                error={inviteErrors?.email?.[0]}
              />
              <Select
                label="Role"
                name="invite-role"
                value={inviteRole}
                onChange={(e) => setInviteRole(e.target.value)}
                options={ROLE_OPTIONS}
                disabled={inviteSubmitting}
                error={inviteErrors?.role?.[0]}
              />
            </div>
            <Button type="submit" variant="primary" loading={inviteSubmitting} disabled={!inviteEmail.trim()}>
              Send invitation
            </Button>
          </form>
        </Can>
      </Card>

      <Card title="Pending invitations" subtitle="Invitations that haven’t been accepted yet.">
        {resendNote && (
          <Alert tone="info" title="Invitation" onDismiss={() => setResendNote(null)}>
            <p className="text-sm">{resendNote}</p>
          </Alert>
        )}
        {invitationsLoading ? (
          <SkeletonLines lines={3} />
        ) : invitationsError ? (
          <div className="space-y-3">
            <Alert tone="error" title="Couldn’t load invitations">
              <p className="text-sm">{invitationsError}</p>
            </Alert>
            <Button variant="secondary" size="sm" onClick={loadInvitations}>
              <RefreshIcon className="h-4 w-4" /> Retry
            </Button>
          </div>
        ) : pending.length === 0 ? (
          <EmptyState
            icon={<TeamIcon className="h-10 w-10" />}
            title="No pending invitations"
            body="Invitations you send will show up here until they’re accepted."
          />
        ) : (
          <Table
            ariaLabel="Pending invitations"
            rowKey={(i: TeamInvitation) => i.id}
            data={pending}
            columns={[
              {
                key: "email",
                header: "Email",
                render: (i: TeamInvitation) => (
                  <span className="font-medium text-slate-900">{i.email}</span>
                ),
              },
              {
                key: "role",
                header: "Role",
                render: (i: TeamInvitation) => (
                  <span className="text-sm text-slate-700">{roleLabel(i.role)}</span>
                ),
              },
              {
                key: "expires",
                header: "Expires",
                render: (i: TeamInvitation) => (
                  <span className="text-sm text-slate-600">{formatDate(i.expiresAt)}</span>
                ),
              },
              {
                key: "actions",
                header: "Actions",
                render: (i: TeamInvitation) => (
                  <Can minRole="admin">
                    <div className="flex gap-2">
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => resendInvite(i)}
                        loading={resending === i.id}
                      >
                        Resend
                      </Button>
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => setRevokeTarget(i)}
                        ariaLabel={`Revoke invitation for ${i.email}`}
                      >
                        Revoke
                      </Button>
                    </div>
                  </Can>
                ),
              },
            ]}
          />
        )}
      </Card>

      <p className="text-xs text-slate-400">
        Permissions are enforced on the server for every request.
      </p>

      <ConfirmDialog
        open={removeTarget !== null}
        title={`Remove ${removeTarget?.email ?? "member"}?`}
        body="They will immediately lose access to this organization. You can re-invite them later."
        confirmLabel="Remove member"
        cancelLabel="Cancel"
        danger
        loading={removing}
        onConfirm={confirmRemove}
        onCancel={() => setRemoveTarget(null)}
      />

      <ConfirmDialog
        open={revokeTarget !== null}
        title={`Revoke invitation for ${revokeTarget?.email ?? ""}?`}
        body="The invitation link will stop working. You can send a new invitation later."
        confirmLabel="Revoke invitation"
        cancelLabel="Cancel"
        danger
        loading={revoking}
        onConfirm={confirmRevoke}
        onCancel={() => setRevokeTarget(null)}
      />
    </div>
  );
}
