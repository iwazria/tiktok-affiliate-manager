"use client";

import { useEffect, useState } from "react";
import { apiFetch, getErrorMessage } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import type { NotificationItem } from "@/lib/types";
import { cx, timeAgo } from "@/lib/format";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { Alert } from "@/components/Alert";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { PageHeader } from "@/components/PageHeader";
import { BellIcon, RefreshIcon } from "@/components/icons";

function asArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const items = (data as { items?: unknown }).items;
    if (Array.isArray(items)) return items as T[];
  }
  return [];
}

export default function NotificationsPage(): React.JSX.Element {
  const { orgId, orgSlug } = useOrg();
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);
  const [markingAll, setMarkingAll] = useState(false);
  const [markingOne, setMarkingOne] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    apiFetch<unknown>(`/api/orgs/${orgId}/notifications`)
      .then((d) => {
        if (cancelled) return;
        setItems(asArray<NotificationItem>(d));
        setLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setError(getErrorMessage(e));
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, nonce]);

  const markAllRead = async () => {
    if (!orgId) return;
    setMarkingAll(true);
    setActionError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/notifications/read-all`, {
        method: "POST",
      });
      setItems((prev) =>
        prev.map((n) => (n.readAt ? n : { ...n, readAt: new Date().toISOString() }))
      );
    } catch (e) {
      setActionError(getErrorMessage(e));
    } finally {
      setMarkingAll(false);
    }
  };

  const markOneRead = async (id: string) => {
    if (!orgId) return;
    setMarkingOne(id);
    setActionError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/notifications/${id}/read`, {
        method: "POST",
      });
      setItems((prev) =>
        prev.map((n) => (n.id === id ? { ...n, readAt: new Date().toISOString() } : n))
      );
    } catch (e) {
      setActionError(getErrorMessage(e));
    } finally {
      setMarkingOne(null);
    }
  };

  const unreadCount = items.filter((n) => !n.readAt).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Notifications"
        subtitle="What’s happening across your workspace."
        actions={
          <Button
            variant="secondary"
            size="sm"
            onClick={markAllRead}
            loading={markingAll}
            disabled={items.length === 0 || unreadCount === 0}
          >
            Mark all as read
          </Button>
        }
      />

      {actionError && (
        <Alert tone="error" title="Action failed" onDismiss={() => setActionError(null)}>
          <p className="text-sm">{actionError}</p>
        </Alert>
      )}

      <Card title="Inbox" subtitle={unreadCount > 0 ? `${unreadCount} unread` : "All caught up"}>
        {loading ? (
          <SkeletonLines lines={5} />
        ) : error ? (
          <div className="space-y-3">
            <Alert tone="error" title="Couldn’t load notifications">
              <p className="text-sm">{error}</p>
            </Alert>
            <Button variant="secondary" size="sm" onClick={() => setNonce((n) => n + 1)}>
              <RefreshIcon className="h-4 w-4" /> Retry
            </Button>
          </div>
        ) : items.length === 0 ? (
          <EmptyState
            icon={<BellIcon className="h-10 w-10" />}
            title="You're all caught up."
            body="Syncs, campaign changes, and team activity will show up here."
          />
        ) : (
          <ul className="divide-y divide-slate-100">
            {items.map((n) => {
              const unread = !n.readAt;
              return (
                <li
                  key={n.id}
                  className={cx(
                    "flex gap-3 px-3 py-4",
                    unread && "rounded-lg bg-indigo-50/50"
                  )}
                >
                  {unread && (
                    <span
                      className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-indigo-600"
                      aria-label="Unread"
                    />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p
                        className={cx(
                          "text-sm",
                          unread ? "font-semibold text-slate-900" : "font-medium text-slate-700"
                        )}
                      >
                        {n.title}
                      </p>
                      <Badge tone="gray">{n.type}</Badge>
                    </div>
                    {n.body && (
                      <p className="mt-1 text-sm text-slate-600">{n.body}</p>
                    )}
                    <p className="mt-1 text-xs text-slate-400" title={n.createdAt}>
                      {timeAgo(n.createdAt)}
                    </p>
                  </div>
                  {unread && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markOneRead(n.id)}
                      loading={markingOne === n.id}
                      ariaLabel={`Mark "${n.title}" as read`}
                    >
                      Mark as read
                    </Button>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      <p className="text-sm text-slate-500">
        <a
          href={`/${orgSlug}/settings`}
          className="font-medium text-indigo-600 hover:underline"
        >
          Notification preferences
        </a>{" "}
        — choose which events notify you.
      </p>
    </div>
  );
}
