"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { apiFetch, getErrorMessage } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import type {
  BreakdownMeta,
  BreakdownRow,
  ExportJobItem,
  MetricValue,
  ReportSummary,
} from "@/lib/types";
import {
  daysAgoIso,
  formatCurrency,
  formatDate,
  formatNumber,
  todayIso,
  truncate,
} from "@/lib/format";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { Input } from "@/components/Input";
import { Alert } from "@/components/Alert";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton, SkeletonLines } from "@/components/Skeleton";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { DataSourceLabel } from "@/components/DataSourceLabel";
import { Table } from "@/components/Table";
import { Can } from "@/components/RoleGate";
import { BarChart, LineChart } from "@/components/Charts";
import { ChartIcon, DownloadIcon, RefreshIcon } from "@/components/icons";

type Preset = "7" | "30" | "90" | "custom";
type BreakdownBy = "day" | "campaign" | "product" | "creator";

const TABS: Array<{ key: BreakdownBy; label: string }> = [
  { key: "day", label: "By day" },
  { key: "campaign", label: "By campaign" },
  { key: "product", label: "By product" },
  { key: "creator", label: "By creator" },
];

function asArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const items = (data as { items?: unknown }).items;
    if (Array.isArray(items)) return items as T[];
  }
  return [];
}

function qs(params: Record<string, string>): string {
  return Object.entries(params)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join("&");
}

function MetricCard({
  title,
  metric,
  currency,
  format,
}: {
  title: string;
  metric: MetricValue | null | undefined;
  currency: string | null | undefined;
  format: (v: number, currency?: string | null) => string;
}): React.JSX.Element {
  // The API marks metrics it doesn't provide as available:false with a note.
  const unavailable = metric == null || metric.available === false || metric.value == null;
  return (
    <StatCard
      title={title}
      value={unavailable ? "Not available" : format(metric.value as number, currency)}
      hint={
        unavailable
          ? metric?.note ?? "Not available from connected TikTok Shop data."
          : metric?.note ?? undefined
      }
      source={metric?.source ?? "tiktok_api"}
      quality={metric?.quality}
      syncedAt={metric?.syncedAt}
    />
  );
}

type ExportPhase = "idle" | "starting" | "polling" | "ready" | "failed" | "timeout";

export default function ReportsPage(): React.JSX.Element {
  const { orgId, selectedShop } = useOrg();
  const shopId = selectedShop?.id ?? null;

  const [preset, setPreset] = useState<Preset>("30");
  const [from, setFrom] = useState<string>(() => daysAgoIso(30));
  const [to, setTo] = useState<string>(() => todayIso());

  const [summary, setSummary] = useState<ReportSummary | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);
  const [summaryNonce, setSummaryNonce] = useState(0);

  const [by, setBy] = useState<BreakdownBy>("day");
  const [rows, setRows] = useState<BreakdownRow[]>([]);
  const [breakdownMeta, setBreakdownMeta] = useState<BreakdownMeta | null>(null);
  const [breakdownLoading, setBreakdownLoading] = useState(false);
  const [breakdownError, setBreakdownError] = useState<string | null>(null);
  const [breakdownNonce, setBreakdownNonce] = useState(0);

  const [exportPhase, setExportPhase] = useState<ExportPhase>("idle");
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportJobId, setExportJobId] = useState<string | null>(null);
  const pollTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (pollTimer.current) clearInterval(pollTimer.current);
    };
  }, []);

  const pickPreset = (p: Preset) => {
    setPreset(p);
    if (p !== "custom") {
      setFrom(daysAgoIso(Number(p)));
      setTo(todayIso());
    }
  };

  // --- Summary ---
  useEffect(() => {
    if (!orgId || !shopId || !from || !to) {
      setSummary(null);
      setSummaryLoading(false);
      return;
    }
    if (from > to) {
      setSummary(null);
      setSummaryLoading(false);
      setSummaryError("Start date must be on or before the end date.");
      return;
    }
    let cancelled = false;
    setSummaryLoading(true);
    setSummaryError(null);
    apiFetch<ReportSummary>(
      `/api/orgs/${orgId}/reports/summary?${qs({ from, to, shopId })}`
    )
      .then((d) => {
        if (cancelled) return;
        setSummary(d ?? null);
        setSummaryLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setSummary(null);
        setSummaryError(getErrorMessage(e));
        setSummaryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, shopId, from, to, summaryNonce]);

  // --- Breakdown: API returns { rows: [...], meta: { source, quality, syncedAt, note } }
  useEffect(() => {
    if (!orgId || !shopId || !from || !to || from > to) {
      setRows([]);
      setBreakdownMeta(null);
      setBreakdownLoading(false);
      return;
    }
    let cancelled = false;
    setBreakdownLoading(true);
    setBreakdownError(null);
    apiFetch<unknown>(
      `/api/orgs/${orgId}/reports/breakdown?${qs({ by, from, to, shopId })}`
    )
      .then((d) => {
        if (cancelled) return;
        const obj = (d ?? {}) as { rows?: unknown; meta?: BreakdownMeta };
        setRows(Array.isArray(obj.rows) ? (obj.rows as BreakdownRow[]) : asArray<BreakdownRow>(d));
        setBreakdownMeta(obj.meta ?? null);
        setBreakdownLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setRows([]);
        setBreakdownMeta(null);
        setBreakdownError(getErrorMessage(e));
        setBreakdownLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, shopId, from, to, by, breakdownNonce]);

  // The API doesn't return a currency; use the shop's currency.
  const currency = selectedShop?.currency ?? "USD";

  const chartData = useMemo(() => {
    if (by === "day") {
      return rows.map((r) => ({
        label: formatDate(r.label ?? r.key),
        value: r.revenue ?? 0,
      }));
    }
    return [...rows]
      .sort((a, b) => (b.revenue ?? 0) - (a.revenue ?? 0))
      .slice(0, 12)
      .map((r) => ({
        label: truncate(r.label ?? r.key, 24),
        value: r.revenue ?? 0,
      }));
  }, [rows, by]);

  // --- CSV export ---
  const pollExport = (id: string) => {
    if (!orgId) return;
    setExportPhase("polling");
    setExportJobId(id);
    let attempts = 0;
    if (pollTimer.current) clearInterval(pollTimer.current);
    pollTimer.current = setInterval(async () => {
      attempts += 1;
      try {
        const jobs = asArray<ExportJobItem>(
          await apiFetch<unknown>(`/api/orgs/${orgId}/exports`)
        );
        const job = jobs.find((j) => j.id === id);
        if (job?.status === "ready") {
          if (pollTimer.current) clearInterval(pollTimer.current);
          setExportPhase("ready");
        } else if (job?.status === "failed") {
          if (pollTimer.current) clearInterval(pollTimer.current);
          setExportError(job.error ?? "Export failed.");
          setExportPhase("failed");
        } else if (attempts >= 20) {
          if (pollTimer.current) clearInterval(pollTimer.current);
          setExportPhase("timeout");
        }
      } catch {
        if (attempts >= 20) {
          if (pollTimer.current) clearInterval(pollTimer.current);
          setExportPhase("timeout");
        }
      }
    }, 3000);
  };

  const startExport = async () => {
    if (!orgId || !shopId || !from || !to) return;
    setExportPhase("starting");
    setExportError(null);
    try {
      const job = await apiFetch<ExportJobItem>(`/api/orgs/${orgId}/exports`, {
        method: "POST",
        body: JSON.stringify({ kind: "report", from, to, shopId }),
      });
      if (!job?.id) throw new Error("The export did not return a job id.");
      pollExport(job.id);
    } catch (e) {
      setExportError(getErrorMessage(e));
      setExportPhase("idle");
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Reports"
        subtitle="Performance from your connected TikTok Shop."
      />

      <Card title="Filters" subtitle="Choose a date range for this report.">
        <div className="flex flex-wrap items-center gap-2">
          {(["7", "30", "90"] as const).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => pickPreset(p)}
              aria-pressed={preset === p}
              className={
                preset === p
                  ? "rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-medium text-white"
                  : "rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
              }
            >
              Last {p} days
            </button>
          ))}
          <div className="ml-2 flex flex-wrap items-end gap-3">
            <Input
              label="From"
              name="from"
              type="date"
              value={from}
              onChange={(e) => {
                setFrom(e.target.value);
                setPreset("custom");
              }}
            />
            <Input
              label="To"
              name="to"
              type="date"
              value={to}
              onChange={(e) => {
                setTo(e.target.value);
                setPreset("custom");
              }}
            />
          </div>
        </div>
        <p className="mt-3 text-sm text-slate-500">
          Shop:{" "}
          <span className="font-medium text-slate-800">
            {selectedShop?.shopName ?? "No shop selected"}
          </span>{" "}
          · Change shop in the top bar.
        </p>
        {!shopId && (
          <Alert tone="info" title="No shop selected" >
            <p className="text-sm">
              Select a shop in the top bar to view its performance.
            </p>
          </Alert>
        )}
      </Card>

      {summaryError && (
        <Alert
          tone="error"
          title="Couldn’t load the summary"
          onDismiss={() => setSummaryError(null)}
        >
          <p className="text-sm">{summaryError}</p>
          <div className="mt-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setSummaryNonce((n) => n + 1)}
            >
              <RefreshIcon className="h-4 w-4" /> Retry
            </Button>
          </div>
        </Alert>
      )}

      {summaryLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      ) : summary ? (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <MetricCard
              title="Clicks"
              metric={summary.clicks}
              currency={currency}
              format={(v) => formatNumber(v)}
            />
            <MetricCard
              title="Orders"
              metric={summary.orders}
              currency={currency}
              format={(v) => formatNumber(v)}
            />
            <MetricCard
              title="Revenue"
              metric={summary.revenue}
              currency={currency}
              format={(v, c) => formatCurrency(v, c)}
            />
            <MetricCard
              title="Commission"
              metric={summary.commission}
              currency={currency}
              format={(v, c) => formatCurrency(v, c)}
            />
          </div>
          <Alert tone="info" title="About these numbers">
            <p className="text-sm">
              Times shown in {summary.timezone ?? "UTC"}. TikTok source data may
              be delayed or revised.
            </p>
          </Alert>
        </>
      ) : null}

      <Card title="Breakdown" subtitle="Slice performance by day, campaign, product, or creator.">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div role="tablist" aria-label="Breakdown" className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={by === t.key}
              onClick={() => setBy(t.key)}
              className={
                by === t.key
                  ? "rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-medium text-white"
                  : "rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
              }
            >
              {t.label}
            </button>
          ))}
          </div>
          {breakdownMeta && (
            <DataSourceLabel
              source={breakdownMeta.source}
              quality={breakdownMeta.quality}
              syncedAt={breakdownMeta.syncedAt}
              className="ml-auto"
            />
          )}
        </div>
        {breakdownMeta?.note && (
          <p className="mb-4 text-xs text-slate-500">{breakdownMeta.note}</p>
        )}

        {breakdownError && (
          <Alert
            tone="error"
            title="Couldn’t load the breakdown"
            onDismiss={() => setBreakdownError(null)}
          >
            <p className="text-sm">{breakdownError}</p>
            <div className="mt-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setBreakdownNonce((n) => n + 1)}
              >
                <RefreshIcon className="h-4 w-4" /> Retry
              </Button>
            </div>
          </Alert>
        )}

        {breakdownLoading ? (
          <SkeletonLines lines={6} />
        ) : rows.length === 0 ? (
          <EmptyState
            icon={<ChartIcon className="h-10 w-10" />}
            title="No data for this period"
            body="Try a different date range, or sync your shop to pull the latest data."
          />
        ) : (
          <div className="space-y-6">
            {by === "day" ? (
              <LineChart
                data={chartData}
                height={240}
                ariaLabel="Revenue by day"
                formatValue={(v) => formatCurrency(v, currency)}
              />
            ) : (
              <BarChart
                data={chartData}
                height={260}
                ariaLabel={`Top revenue by ${by}`}
                formatValue={(v) => formatCurrency(v, currency)}
              />
            )}
            <Table
              ariaLabel="Breakdown table"
              rowKey={(r: BreakdownRow) => r.key}
              data={rows}
              columns={[
                {
                  key: "label",
                  header: by === "day" ? "Date" : "Name",
                  render: (r: BreakdownRow) =>
                    by === "day" ? formatDate(r.label ?? r.key) : r.label ?? r.key,
                },
                {
                  key: "clicks",
                  header: "Clicks",
                  render: (r: BreakdownRow) => formatNumber(r.clicks),
                },
                {
                  key: "orders",
                  header: "Orders",
                  render: (r: BreakdownRow) => formatNumber(r.orders),
                },
                {
                  key: "revenue",
                  header: "Revenue",
                  render: (r: BreakdownRow) => formatCurrency(r.revenue, currency),
                },
                {
                  key: "commission",
                  header: "Commission",
                  render: (r: BreakdownRow) => formatCurrency(r.commission, currency),
                },
              ]}
            />
          </div>
        )}
      </Card>

      <Card
        title="CSV export"
        subtitle="Generate a CSV of this report for the selected range."
      >
        <Can
          minRole="campaign_manager"
          fallback={
            <p className="text-sm text-slate-500">
              Exports require the campaign manager role or above.
            </p>
          }
        >
          <div className="space-y-3">
            {exportPhase === "starting" || exportPhase === "polling" ? (
              <div className="space-y-2">
                <Button variant="secondary" loading disabled>
                  Generating export…
                </Button>
                <p className="text-sm text-slate-500">
                  This usually takes a few seconds. You can keep working —
                  the download will appear here.
                </p>
              </div>
            ) : (
              <Button
                variant="primary"
                onClick={startExport}
                disabled={!shopId || !from || !to}
              >
                <DownloadIcon className="h-4 w-4" /> Generate CSV export
              </Button>
            )}
            {exportPhase === "ready" && orgId && exportJobId && (
              <div className="space-y-3">
                <Alert tone="success" title="Export is ready">
                  <p className="text-sm">
                    Your CSV has been generated for {formatDate(from)} –{" "}
                    {formatDate(to)}.
                  </p>
                </Alert>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="primary"
                    href={`/api/orgs/${orgId}/exports/${exportJobId}/download`}
                  >
                    <DownloadIcon className="h-4 w-4" /> Download CSV
                  </Button>
                  <Button variant="secondary" onClick={() => setExportPhase("idle")}>
                    Start a new export
                  </Button>
                </div>
              </div>
            )}
            {exportPhase === "failed" && (
              <div className="space-y-3">
                <Alert tone="error" title="Export failed">
                  <p className="text-sm">{exportError ?? "Something went wrong."}</p>
                </Alert>
                <Button variant="secondary" onClick={startExport}>
                  <RefreshIcon className="h-4 w-4" /> Try again
                </Button>
              </div>
            )}
            {exportPhase === "timeout" && (
              <div className="space-y-3">
                <Alert tone="warning" title="Still working on it">
                  <p className="text-sm">
                    The export is taking longer than expected. It will be
                    available shortly — try checking again.
                  </p>
                </Alert>
                <Button
                  variant="secondary"
                  onClick={() => exportJobId && pollExport(exportJobId)}
                >
                  <RefreshIcon className="h-4 w-4" /> Check again
                </Button>
              </div>
            )}
          </div>
        </Can>
      </Card>
    </div>
  );
}
