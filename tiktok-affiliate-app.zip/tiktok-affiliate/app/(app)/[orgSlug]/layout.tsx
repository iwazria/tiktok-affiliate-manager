"use client";

import { use, useEffect, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { OrgProvider, useOrg } from "@/components/OrgContext";
import { DemoBanner } from "@/components/DemoBanner";
import { apiFetch } from "@/lib/client";
import { cx, timeAgo } from "@/lib/format";
import {
  BellIcon,
  BoxIcon,
  ChartIcon,
  ChevronDownIcon,
  DashboardIcon,
  GearIcon,
  MegaphoneIcon,
  MenuIcon,
  TeamIcon,
  UsersIcon,
  XIcon,
  InfoIcon,
} from "@/components/icons";

const NAV = [
  { key: "overview", label: "Overview", href: "overview", Icon: DashboardIcon },
  { key: "products", label: "Products", href: "products", Icon: BoxIcon },
  { key: "campaigns", label: "Campaigns", href: "campaigns", Icon: MegaphoneIcon },
  { key: "creators", label: "Creators", href: "creators", Icon: UsersIcon },
  { key: "reports", label: "Reports", href: "reports", Icon: ChartIcon },
  { key: "team", label: "Team", href: "team", Icon: TeamIcon },
  { key: "settings", label: "Settings", href: "settings", Icon: GearIcon },
];

function initials(name: string | undefined, email: string | undefined): string {
  const src = (name || email || "?").trim();
  const parts = src.split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return src.slice(0, 2).toUpperCase();
}

function SyncPill(): React.JSX.Element | null {
  const { selectedShop, shopsLoading } = useOrg();
  if (shopsLoading) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-xs text-slate-500">
        <span className="h-2 w-2 animate-pulse rounded-full bg-slate-300" />
        Checking sync…
      </span>
    );
  }
  if (!selectedShop) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
        <span className="h-2 w-2 rounded-full bg-slate-400" aria-hidden="true" />
        No shop selected
      </span>
    );
  }
  if (selectedShop.lastSyncStatus === "failed") {
    return (
      <span
        className="inline-flex items-center gap-1.5 rounded-full bg-red-50 px-2.5 py-1 text-xs font-medium text-red-700"
        title={selectedShop.lastSyncError ?? "Last sync failed"}
      >
        <span className="h-2 w-2 rounded-full bg-red-500" aria-hidden="true" />
        Sync failed
      </span>
    );
  }
  if (selectedShop.lastSyncAt) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
        <span className="h-2 w-2 rounded-full bg-emerald-500" aria-hidden="true" />
        Synced {timeAgo(selectedShop.lastSyncAt)}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
      <span className="h-2 w-2 rounded-full bg-slate-400" aria-hidden="true" />
      Never synced
    </span>
  );
}

function NotificationsBell(): React.JSX.Element {
  const { orgId, orgSlug } = useOrg();
  const [unread, setUnread] = useState<number | null>(null);

  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    const load = async () => {
      try {
        const data = await apiFetch<unknown>(`/api/orgs/${orgId}/notifications`);
        if (cancelled) return;
        const items: Array<{ readAt: string | null }> = Array.isArray(data)
          ? data
          : ((data as { items?: Array<{ readAt: string | null }> }).items ?? []);
        setUnread(items.filter((n) => !n.readAt).length);
      } catch {
        if (!cancelled) setUnread(null);
      }
    };
    load();
    const t = setInterval(load, 60000);
    return () => {
      cancelled = true;
      clearInterval(t);
    };
  }, [orgId]);

  return (
    <Link
      href={`/${orgSlug}/notifications`}
      className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700"
      aria-label={unread ? `Notifications, ${unread} unread` : "Notifications"}
    >
      <BellIcon className="h-5 w-5" />
      {unread !== null && unread > 0 && (
        <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-bold text-white">
          {unread > 99 ? "99+" : unread}
        </span>
      )}
    </Link>
  );
}

function ProfileMenu(): React.JSX.Element {
  const { me, orgSlug } = useOrg();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, [open ]);

  const signOut = async () => {
    setSigningOut(true);
    try {
      await apiFetch("/api/auth/signout", { method: "POST" });
    } catch {
      // proceed to signin regardless
    }
    router.replace("/signin");
  };

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label="Profile menu"
        className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-slate-100"
      >
        <span
          className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white"
          aria-hidden="true"
        >
          {initials(me?.user.name, me?.user.email)}
        </span>
        <ChevronDownIcon className="hidden h-4 w-4 text-slate-400 sm:block" />
      </button>
      {open && (
        <div
          role="menu"
          aria-label="Profile"
          className="absolute right-0 z-50 mt-2 w-64 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg"
        >
          <div className="border-b border-slate-100 px-4 py-3">
            <p className="truncate text-sm font-semibold text-slate-900">
              {me?.user.name ?? "—"}
            </p>
            <p className="truncate text-xs text-slate-500">{me?.user.email ?? ""}</p>
          </div>
          <div className="p-1.5">
            <Link
              href={`/${orgSlug}/notifications`}
              role="menuitem"
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-slate-100"
            >
              Notifications
            </Link>
            <Link
              href={`/${orgSlug}/docs`}
              role="menuitem"
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-slate-100"
            >
              Help &amp; docs
            </Link>
            <button
              type="button"
              role="menuitem"
              onClick={signOut}
              disabled={signingOut}
              className="block w-full rounded-lg px-3 py-2 text-left text-sm text-red-700 hover:bg-red-50 disabled:opacity-50"
            >
              {signingOut ? "Signing out…" : "Sign out"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ShopSelector(): React.JSX.Element {
  const { shops, selectedShop, selectShop, shopsLoading, orgSlug } = useOrg();

  if (shopsLoading) {
    return <div className="h-9 w-44 animate-pulse rounded-lg bg-slate-100" aria-hidden="true" />;
  }
  if (shops.length === 0) {
    return (
      <Link
        href={`/${orgSlug}/settings`}
        className="inline-flex items-center gap-1.5 rounded-lg border border-dashed border-slate-300 px-3 py-1.5 text-sm text-slate-500 hover:border-indigo-400 hover:text-indigo-600"
      >
        <InfoIcon className="h-4 w-4" />
        Connect a shop
      </Link>
    );
  }
  return (
    <label className="flex items-center gap-2">
      <span className="sr-only">Select shop</span>
      <select
        value={selectedShop?.id ?? ""}
        onChange={(e) => selectShop(e.target.value)}
        className="max-w-52 truncate rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-sm font-medium text-slate-700 hover:border-slate-300"
        aria-label="Select TikTok Shop"
      >
        {shops.map((s) => (
          <option key={s.id} value={s.id}>
            {(s.shopName ?? "Unnamed shop") + (s.mode === "demo" ? " (demo)" : "")}
          </option>
        ))}
      </select>
    </label>
  );
}

function SidebarNav({ onNavigate }: { onNavigate?: () => void }): React.JSX.Element {
  const { orgSlug } = useOrg();
  const pathname = usePathname();

  return (
    <nav aria-label="Main navigation" className="flex-1 overflow-y-auto px-3 py-4">
      <ul className="space-y-1">
        {NAV.map(({ key, label, href, Icon }) => {
          const full = `/${orgSlug}/${href}`;
          const active = pathname === full || pathname.startsWith(`${full}/`);
          return (
            <li key={key}>
              <Link
                href={full}
                onClick={onNavigate}
                aria-current={active ? "page" : undefined}
                className={cx(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium",
                  active
                    ? "bg-indigo-50 text-indigo-700"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                )}
              >
                <Icon className="h-5 w-5 shrink-0" />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

function Brand(): React.JSX.Element {
  const { org } = useOrg();
  return (
    <div className="flex h-16 shrink-0 items-center gap-2.5 border-b border-slate-200 px-4">
      <span
        className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-sm font-bold text-white"
        aria-hidden="true"
      >
        TA
      </span>
      <div className="min-w-0">
        <p className="truncate text-sm font-bold text-slate-900">{org?.name ?? "…"}</p>
        <p className="truncate text-[11px] text-slate-500">TikTok Shop Affiliates</p>
      </div>
    </div>
  );
}

function Shell({ children }: { children: ReactNode }): React.JSX.Element {
  const { loading, error, errorMessage, isDemo, orgSlug } = useOrg();
  const router = useRouter();
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    if (!loading && error === "unauthorized") router.replace("/signin");
  }, [loading, error, router]);

  // Close drawer on Escape
  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setDrawerOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [drawerOpen]);

  if (loading) {
    return (
      <div className="flex min-h-screen bg-slate-50" aria-label="Loading workspace">
        <div className="hidden w-64 shrink-0 border-r border-slate-200 bg-white lg:block">
          <div className="h-16 border-b border-slate-200" />
          <div className="space-y-2 p-4">
            {Array.from({ length: 7 }).map((_, i) => (
              <div key={i} className="h-9 animate-pulse rounded-lg bg-slate-100" />
            ))}
          </div>
        </div>
        <div className="flex-1">
          <div className="h-16 animate-pulse border-b border-slate-200 bg-white" />
          <div className="space-y-3 p-6">
            <div className="h-8 w-64 animate-pulse rounded-lg bg-slate-200" />
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-28 animate-pulse rounded-xl bg-slate-200" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error === "unauthorized") return <></>;

  if (error) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-50 px-4">
        <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
          <h1 className="text-lg font-semibold text-slate-900">Can’t open this workspace</h1>
          <p className="mt-2 text-sm text-slate-600">
            {errorMessage ?? "Something went wrong while loading."}
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Try again
            </button>
            <Link
              href="/signin"
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
            >
              Back to sign in
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white lg:flex">
        <Brand />
        <SidebarNav />
        <div className="border-t border-slate-200 p-3">
          <p className="px-2 text-[11px] text-slate-400">
            Signed in{isDemo ? " · demo data shown" : ""}
          </p>
        </div>
      </aside>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
          <div
            className="absolute inset-0 bg-slate-900/40"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <aside className="absolute inset-y-0 left-0 flex w-72 flex-col bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 pr-2">
              <div className="flex-1">
                <Brand />
              </div>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                aria-label="Close navigation"
                className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
              >
                <XIcon className="h-5 w-5" />
              </button>
            </div>
            <SidebarNav onNavigate={() => setDrawerOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 flex h-16 items-center gap-2 border-b border-slate-200 bg-white px-3 sm:px-4">
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            aria-label="Open navigation"
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 lg:hidden"
          >
            <MenuIcon className="h-5 w-5" />
          </button>
          <div className="min-w-0 flex-1">
            <ShopSelector />
          </div>
          <div className="hidden sm:block">
            <SyncPill />
          </div>
          <NotificationsBell />
          <Link
            href={`/${orgSlug}/docs`}
            className="hidden rounded-lg px-2.5 py-2 text-sm font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-700 md:block"
          >
            Help
          </Link>
          <ProfileMenu />
        </header>

        {isDemo && <DemoBanner />}

        <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-7xl">{children}</div>
        </main>
      </div>
    </div>
  );
}

export default function OrgLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ orgSlug: string }>;
}): React.JSX.Element {
  const { orgSlug } = use(params);
  return (
    <OrgProvider orgSlug={orgSlug}>
      <Shell>{children}</Shell>
    </OrgProvider>
  );
}
