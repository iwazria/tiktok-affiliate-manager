"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import type { OnboardingState } from "@/lib/types";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { CheckIcon, XIcon } from "@/components/icons";
import { cx } from "@/lib/format";

interface Step {
  key: string;
  title: string;
  why: string;
  done: boolean;
  href?: string;
  cta?: string;
}

const DEFAULT_STATE: OnboardingState = {
  shopConnected: false,
  shopConfirmed: false,
  productsSynced: false,
  firstCampaign: false,
  teamInvited: false,
  dismissed: false,
};

export function OnboardingCard({ orgId }: { orgId: string }): React.JSX.Element | null {
  const { orgSlug } = useOrg();
  const [state, setState] = useState<OnboardingState | null>(null);
  const [dismissing, setDismissing] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await apiFetch<Partial<OnboardingState> | null>(
          `/api/orgs/${orgId}/onboarding`
        );
        if (cancelled) return;
        setState({ ...DEFAULT_STATE, ...(data ?? {}) });
      } catch {
        // Fetch failing hides the card (render null below).
        if (!cancelled) setState(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [orgId]);

  if (state === null || state.dismissed) return null;

  const steps: Step[] = [
    {
      key: "org",
      title: "Create or join an organization",
      why: "Your team shares one workspace.",
      done: true,
    },
    {
      key: "shop",
      title: "Connect a TikTok Shop",
      why: "Link your seller account, or keep exploring in demo mode.",
      done: state.shopConnected,
      href: `/${orgSlug}/settings`,
      cta: "Connect shop",
    },
    {
      key: "confirm",
      title: "Confirm the connected shop identity",
      why: "Make sure the right shop is linked.",
      done: state.shopConfirmed,
      href: `/${orgSlug}/settings`,
    },
    {
      key: "products",
      title: "Sync products",
      why: "Pull your catalog so campaigns can use it.",
      done: state.productsSynced,
      href: `/${orgSlug}/products`,
      cta: "View products",
    },
    {
      key: "campaign",
      title: "Create the first campaign",
      why: "Set commission terms and pick products.",
      done: state.firstCampaign,
      href: `/${orgSlug}/campaigns/new`,
      cta: "New campaign",
    },
    {
      key: "team",
      title: "Invite team members",
      why: "Optional: bring collaborators in with the right roles.",
      done: state.teamInvited,
      href: `/${orgSlug}/team`,
      cta: "Invite team",
    },
  ];

  const doneCount = steps.filter((s) => s.done).length;

  const dismiss = async () => {
    setDismissing(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/onboarding/dismiss`, { method: "POST" });
    } catch {
      // Hide anyway — a failed dismiss shouldn't block the workspace.
    } finally {
      setState((s) => (s ? { ...s, dismissed: true } : s));
      setDismissing(false);
    }
  };

  return (
    <Card
      title="Getting started"
      subtitle={`${doneCount} of ${steps.length} complete`}
      actions={
        <button
          type="button"
          onClick={dismiss}
          disabled={dismissing}
          aria-label="Dismiss onboarding checklist"
          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 disabled:opacity-50"
        >
          <XIcon className="h-5 w-5" />
        </button>
      }
    >
      <div
        className="mb-4 h-2 overflow-hidden rounded-full bg-slate-100"
        role="progressbar"
        aria-valuenow={doneCount}
        aria-valuemin={0}
        aria-valuemax={steps.length}
        aria-label={`Onboarding progress: ${doneCount} of ${steps.length} complete`}
      >
        <div
          className="h-full rounded-full bg-indigo-600 transition-all"
          style={{ width: `${(doneCount / steps.length) * 100}%` }}
        />
      </div>
      <ol className="space-y-3">
        {steps.map((step) => (
          <li key={step.key} className="flex items-start gap-3">
            <span
              className={cx(
                "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full",
                step.done ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400"
              )}
              aria-hidden="true"
            >
              {step.done && <CheckIcon className="h-4 w-4" />}
            </span>
            <div className="min-w-0 flex-1">
              <p
                className={cx(
                  "text-sm font-medium",
                  step.done ? "text-slate-500 line-through" : "text-slate-900"
                )}
              >
                {step.title}
              </p>
              <p className="text-xs text-slate-500">{step.why}</p>
            </div>
            {!step.done && step.href && step.cta && (
              <Link
                href={step.href}
                className="shrink-0 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-indigo-700 hover:bg-indigo-50"
              >
                {step.cta}
              </Link>
            )}
            {!step.done && step.href && !step.cta && (
              <Link
                href={step.href}
                className="shrink-0 text-xs font-medium text-indigo-600 hover:text-indigo-700"
              >
                Review
              </Link>
            )}
          </li>
        ))}
      </ol>
      <div className="mt-4 flex justify-end">
        <Button variant="ghost" size="sm" onClick={dismiss} disabled={dismissing}>
          {dismissing ? "Dismissing…" : "Dismiss checklist"}
        </Button>
      </div>
    </Card>
  );
}
