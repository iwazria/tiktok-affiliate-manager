"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { apiFetch, getErrorMessage, isForbidden } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import {
  cx,
  daysAgoIso,
  formatCurrency,
  formatNumber,
  timeAgo,
  todayIso,
} from "@/lib/format";
import type {
  AuditLogItem,
  Campaign,
  MetricValue,
  ReportSummary,
  Shop,
  ShopDetail,
} from "@/lib/types";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";
import { Alert } from "@/components/Alert";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/Skeleton";
import { StatCard } from "@/components/StatCard";
import { PermissionDenied } from "@/components/PermissionDenied";
import { DataSourceLabel } from "@/components/DataSourceLabel";
import {
  BoxIcon,
  ChartIcon,
  EmptyBoxIcon,
  MegaphoneIcon,
  RefreshIcon,
  UsersIcon,
} from "@/components/icons";
import { OnboardingCard } from "./OnboardingCard";

function extractItems<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.items)) return d.items as T[];
  }
  return [];
}

function extractTotal(data: unknown): number | null {
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (typeof d.total === "number") return d.total;
  }
  if (Array.isArray(data)) return data.length;
  return null;
}

function statusTone(status: string): "green" | "red" | "gray" {
  if (status === "connected") return "green";
  if (status === "expired" || status === "revoked" || status === "error")
    return "red";
  return "gray";
}

function humanizeAction(action: string): string {
  const label = action.replace(/[_-]+/g, " ").trim();
  return label ? label.charAt(0).toUpperCase() + label.slice(1) : action;
}

const RANGE_OPTIONS = [7, 30, 90] as const;

export default function OverviewPage(): React.JSX.Element {
  const {
    orgId,
    orgSlug,
    org,
    selectedShop,
    shops,
    loading: orgLoading,
    shopsLoading,
  } = useOrg();

  const [range, setRange] = useState<(typeof RANGE_OPTIONS)[number]>(30);
  const [productsTotal, setProductsTotal] = useState<number | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [summary, setSummary] = useState<ReportSummary | null>(null);
  const [auditItems, setAuditItems] = useState<AuditLogItem[]>([]);
  const [unavailableCaps, setUnavailableCaps] = useState<
    Array<{ feature: string; reason: string }>
  >([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [forbidden, setForbidden] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const shopId = selectedShop?.id ?? null;
  const shopModeSource: "demo" | "live" =
    selectedShop?.mode === "demo" ? "demo" : "live";

  const load = useCallback(async () => {
    if (!orgId) return;
    setLoading(true);
    setError(null);
    setForbidden(false);
    try {
      const from = daysAgoIso(range);
      const to = todayIso();
      const calls: Array<Promise<unknown>> = [];
      if (shopId) {
        calls.push(
          apiFetch<unknown>(
            `/api/orgs/${orgId}/products?shopId=${encodeURIComponent(shopId)}&page=1&pageSize=1`
          )
        );
        calls.push(
          apiFetch<unknown>(
            `/api/orgs/${orgId}/reports/summary?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&shopId=${encodeURIComponent(shopId)}`
          )
        );
      }
      calls.push(
        apiFetch<unknown>(`/api/orgs/${orgId}/campaigns?page=1&pageSize=100`)
      );
      calls.push(apiFetch<unknown>(`/api/orgs/${orgId}/audit-logs`));

      const results = await Promise.allSettled(calls);
      let idx = 0;
      if (shopId) {
        const r = results[idx++];
        if (r.status === "fulfilled") setProductsTotal(extractTotal(r.value));
        else {
          if (isForbidden(r.reason)) setForbidden(true);
          else throw r.reason;
        }
        const s = results[idx++];
        if (s.status === "fulfilled") setSummary(s.value as ReportSummary);
        else {
          if (isForbidden(s.reason)) setForbidden(true);
          else throw s.reason;
        }
      } else {
        setProductsTotal(null);
        setSummary(null);
      }
      const c = results[idx++];
      if (c.status === "fulfilled") setCampaigns(extractItems<Campaign>(c.value));
      else {
        if (isForbidden(c.reason)) setForbidden(true);
        else throw c.reason;
      }
      const a = results[idx++];
      if (a.status === "fulfilled") setAuditItems(extractItems<AuditLogItem>(a.value));
      else {
        if (isForbidden(a.reason)) setForbidden(true);
        else throw a.reason;
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [orgId, shopId, range]);

  useEffect(() => {
    if (!orgLoading && orgId) load();
  }, [orgLoading, orgId, load, refreshKey]);

  // Capabilities notice: best-effort, never blocks the page.
  // GET .../shops/[shopId]/capabilities → { capabilities: Record<key, {available, reason}>, mode, scopes }
  useEffect(() => {
    if (!orgId || !shopId) {
      setUnavailableCaps([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const data = await apiFetch<{
          capabilities?: Record<string, { available: boolean; reason?: string }>;
        }>(`/api/orgs/${orgId}/shops/${shopId}/capabilities`);
        if (cancelled) return;
        const caps = data?.capabilities ?? {};
        const unavailable = Object.entries(caps)
          .filter(([, info]) => info && info.available === false)
          .map(([feature, info]) => ({
            feature,
            reason: info.reason ?? "Not available for the connected shop.",
          }));
        setUnavailableCaps(unavailable);
      } catch {
        if (!cancelled) setUnavailableCaps([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [orgId, shopId]);

  const campaignStats = useMemo(() => {
    const active = campaigns.filter((c) => c.status === "active").length;
    const scheduled = campaigns.filter((c) => c.status === "scheduled").length;
    const ended = campaigns.filter((c) => c.status === "ended").length;
    return { active, scheduled, ended };
  }, [campaigns]);

  const collaborationTotal = useMemo<number | null>(() => {
    // Real API shape: collaborationCounts: Record<status, count>
    const withCounts = campaigns.filter(
      (c) => c.collaborationCounts && Object.keys(c.collaborationCounts).length > 0
    );
    if (withCounts.length > 0) {
      return withCounts.reduce(
        (sum, c) =>
          sum +
          Object.values(c.collaborationCounts ?? {}).reduce(
            (n, v) => n + (typeof v === "number" ? v : 0),
            0
          ),
        0
      );
    }
    const legacy = campaigns.filter(
      (c) => c.counts && typeof c.counts.invited === "number"
    );
    if (legacy.length === 0) return null;
    return legacy.reduce(
      (sum, c) => sum + (c.counts?.invited ?? 0) + (c.counts?.accepted ?? 0),
      0
    );
  }, [campaigns]);

  const campaignActivity = useMemo(
    () =>
      auditItems
        .filter((i) => typeof i.action === "string" && i.action.startsWith("campaign"))
        .slice(0, 5),
    [auditItems]
  );
  const creatorActivity = useMemo(
    () =>
      auditItems
        .filter(
          (i) =>
            typeof i.action === "string" &&
            (i.action.startsWith("collaboration") ||
              i.action.startsWith("invitation") ||
              i.action.startsWith("creator"))
        )
        .slice(0, 5),
    [auditItems]
  );

  if (orgLoading || shopsLoading) {
    return (
      <div className="space-y-6" aria-label="Loading overview">
        <div className="h-8 w-64 animate-pulse rounded-lg bg-slate-200" />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-32 animate-pulse rounded-xl bg-slate-200" />
          ))}
        </div>
        <div className="h-48 animate-pulse rounded-xl bg-slate-200" />
      </div>
    );
  }

  if (forbidden) {
    return (
      <PermissionDenied
        title="You don't have access to this workspace data"
        body="Your role doesn't include permission to view these metrics. Ask an admin to upgrade your role."
      />
    );
  }

  const metrics: Array<{ title: string; metric: MetricValue | null; money: boolean }> = [
    { title: "Clicks", metric: summary?.clicks ?? null, money: false },
    { title: "Orders", metric: summary?.orders ?? null, money: false },
    { title: "Revenue", metric: summary?.revenue ?? null, money: true },
    { title: "Commission", metric: summary?.commission ?? null, money: true },
  ];

  const retry = () => setRefreshKey((k) => k + 1);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Overview"
        subtitle={org?.name ?? undefined}
        actions={
          <div className="flex items-center gap-2" role="group" aria-label="Date range">
            {RANGE_OPTIONS.map((days) => (
              <button
                key={days}
                type="button"
                onClick={() => setRange(days)}
                aria-pressed={range === days}
                className={cx(
                  "rounded-lg px-3 py-1.5 text-sm font-medium",
                  range === days
                    ? "bg-indigo-600 text-white"
                    : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50"
                )}
              >
                {days}d
              </button>
            ))}
          </div>
        }
      />

      {orgId && <OnboardingCard orgId={orgId} />}

      {selectedShop?.status === "expired" && (
        <Alert
          tone="error"
          title="Shop authorization expired"
          onDismiss={undefined}
        >
          <span>
            Shop authorization expired —{" "}
            <Link
              href={`/${orgSlug}/settings`}
              className="font-medium text-red-700 underline"
            >
              reconnect your shop in Settings
            </Link>
            .
          </span>
        </Alert>
      )}

      {selectedShop?.lastSyncStatus === "failed" && (
        <Alert tone="error" title="Last product sync failed">
          {selectedShop.lastSyncError ?? "The last sync failed with an unknown error."}{" "}
          Try syncing again from{" "}
          <Link
            href={`/${orgSlug}/settings`}
            className="font-medium text-red-700 underline"
          >
            Settings
          </Link>
          .
        </Alert>
      )}

      {unavailableCaps.length > 0 && (
        <Alert tone="warning" title="Some features are unavailable">
          <ul className="mt-1 list-disc space-y-1 pl-5">
            {unavailableCaps.map((cap) => (
              <li key={cap.feature}>
                <span className="font-medium">{cap.feature}</span> — {cap.reason}
              </li>
            ))}
          </ul>
        </Alert>
      )}

      {error && (
        <Alert tone="error" title="Could not load overview data">
          <div className="flex items-center justify-between gap-4">
            <span>{error}</span>
            <Button variant="secondary" size="sm" onClick={retry}>
              Retry
            </Button>
          </div>
        </Alert>
      )}

      {/* Shop summary */}
      {selectedShop ? (
        <Card title="Shop" subtitle={selectedShop.shopName ?? "Unnamed shop"}>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
            <div>
              <p className="text-xs text-slate-500">Region</p>
              <p className="text-sm font-medium text-slate-900">
                {selectedShop.region ?? "—"}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Currency</p>
              <p className="text-sm font-medium text-slate-900">
                {selectedShop.currency ?? "—"}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Status</p>
              <Badge tone={statusTone(selectedShop.status)}>
                {selectedShop.status}
              </Badge>
            </div>
            <div>
              <p className="text-xs text-slate-500">Mode</p>
              <Badge tone={selectedShop.mode === "demo" ? "yellow" : "green"}>
                {selectedShop.mode === "demo" ? "Demo" : "Live"}
              </Badge>
            </div>
            <div>
              <p className="text-xs text-slate-500">Last sync</p>
              <p className="text-sm font-medium text-slate-900">
                {selectedShop.lastSyncAt ? timeAgo(selectedShop.lastSyncAt) : "Never"}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Source</p>
              <DataSourceLabel
                source={shopModeSource}
                syncedAt={selectedShop.lastSyncAt}
              />
            </div>
          </div>
        </Card>
      ) : (
        <Card title="Shop">
          <EmptyState
            icon={<EmptyBoxIcon className="h-10 w-10" />}
            title="No shop connected"
            body="Connect your TikTok Shop to see products, campaigns, and performance metrics."
            action={
              <Button variant="primary" href={`/${orgSlug}/settings`}>
                Go to Settings
              </Button>
            }
          />
        </Card>
      )}

      {/* Stat cards */}
      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 7 }).map((_, i) => (
            <div key={i} className="h-32 animate-pulse rounded-xl bg-slate-200" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Products"
            value={productsTotal !== null ? formatNumber(productsTotal) : "—"}
            source={shopModeSource}
            hint={shopId ? "Synced from your shop catalog" : "Connect a shop to sync products"}
            icon={<BoxIcon className="h-5 w-5" />}
          />
          <StatCard
            title="Campaigns"
            value={formatNumber(campaignStats.active)}
            source="manual"
            hint={`${campaignStats.scheduled} scheduled · ${campaignStats.ended} ended`}
            icon={<MegaphoneIcon className="h-5 w-5" />}
          />
          <StatCard
            title="Collaborations"
            value={
              collaborationTotal !== null ? formatNumber(collaborationTotal) : "Not available"
            }
            source="manual"
            hint={
              collaborationTotal !== null
                ? "Across all campaigns and invitation statuses"
                : "Invitation data isn't returned by the connected API"
            }
            icon={<UsersIcon className="h-5 w-5" />}
          />
          {metrics.map(({ title, metric, money }) =>
            metric && metric.value !== null ? (
              <StatCard
                key={title}
                title={title}
                value={
                  money
                    ? formatCurrency(metric.value, selectedShop?.currency ?? "USD")
                    : formatNumber(metric.value)
                }
                source={metric.source}
                quality={metric.quality}
                syncedAt={metric.syncedAt}
                icon={<ChartIcon className="h-5 w-5" />}
              />
            ) : (
              <StatCard
                key={title}
                title={title}
                value="Not available from connected TikTok Shop data."
                source={metric?.source ?? shopModeSource}
                quality={metric?.quality}
                syncedAt={metric?.syncedAt}
                icon={<ChartIcon className="h-5 w-5" />}
              />
            )
          )}
        </div>
      )}

      {/* Recent activity */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Recent campaign activity">
          {campaignActivity.length === 0 ? (
            <p className="text-sm text-slate-500">No campaign activity yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {campaignActivity.map((item) => (
                <li key={item.id} className="flex items-start justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900">
                      {humanizeAction(item.action)}
                    </p>
                    {item.entityType && (
                      <p className="truncate text-xs text-slate-500">
                        {item.entityType}
                        {item.details ? ` · ${item.details}` : ""}
                      </p>
                    )}
                  </div>
                  <span className="shrink-0 text-xs text-slate-500">
                    {timeAgo(item.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Recent creator activity">
          {creatorActivity.length === 0 ? (
            <p className="text-sm text-slate-500">No creator activity yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {creatorActivity.map((item) => (
                <li key={item.id} className="flex items-start justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900">
                      {humanizeAction(item.action)}
                    </p>
                    {item.entityType && (
                      <p className="truncate text-xs text-slate-500">
                        {item.entityType}
                        {item.details ? ` · ${item.details}` : ""}
                      </p>
                    )}
                  </div>
                  <span className="shrink-0 text-xs text-slate-500">
                    {timeAgo(item.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {/* Sync health */}
      <Card
        title="Sync health"
        actions={
          <Button
            variant="ghost"
            size="sm"
            onClick={retry}
            ariaLabel="Refresh overview"
          >
            <RefreshIcon className="h-4 w-4" />
          </Button>
        }
      >
        {shops.length === 0 ? (
          <p className="text-sm text-slate-500">No shops connected yet.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {shops.map((shop: Shop) => (
              <li key={shop.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 py-2.5">
                <span className="text-sm font-medium text-slate-900">
                  {shop.shopName ?? "Unnamed shop"}
                </span>
                <Badge tone={shop.mode === "demo" ? "yellow" : "green"}>
                  {shop.mode === "demo" ? "Demo" : "Live"}
                </Badge>
                <span className="text-xs text-slate-500">
                  Last sync: {shop.lastSyncAt ? timeAgo(shop.lastSyncAt) : "Never"}
                </span>
                {shop.lastSyncStatus && (
                  <Badge
                    tone={
                      shop.lastSyncStatus === "failed"
                        ? "red"
                        : shop.lastSyncStatus === "ok" || shop.lastSyncStatus === "success"
                          ? "green"
                          : "gray"
                    }
                  >
                    {shop.lastSyncStatus}
                  </Badge>
                )}
                {shop.lastSyncError && (
                  <span className="w-full text-xs text-red-600">
                    {shop.lastSyncError}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
