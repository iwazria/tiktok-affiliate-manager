"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useOrg } from "@/components/OrgContext";
import {
  apiFetch,
  getErrorMessage,
  getFieldErrors,
} from "@/lib/client";
import { cx, formatNumber, parseTags } from "@/lib/format";
import type {
  Campaign,
  Creator,
  CreatorList,
  ExportJobItem,
} from "@/lib/types";
import { Button } from "@/components/Button";
import { PageHeader } from "@/components/PageHeader";
import { Can } from "@/components/RoleGate";
import { Input } from "@/components/Input";
import { Select } from "@/components/Select";
import { Textarea } from "@/components/Textarea";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { Alert } from "@/components/Alert";
import { Modal } from "@/components/Modal";
import { FieldError, FormErrors } from "@/components/FieldError";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Table } from "@/components/Table";
import { Pagination } from "@/components/Pagination";
import {
  PlusIcon,
  UsersIcon,
  EmptyBoxIcon,
  DownloadIcon,
  XIcon,
} from "@/components/icons";

const PAGE_SIZE = 12;

const TABS = [
  { key: "creators", label: "Creators" },
  { key: "lists", label: "Lists" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

/** Defensive extractor: API may return Paginated<T> or a bare array. */
function extractPage<T>(
  data: unknown,
  pageSize: number
): { items: T[]; page: number; totalPages: number } {
  if (Array.isArray(data)) {
    return { items: data as T[], page: 1, totalPages: 1 };
  }
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    const items = Array.isArray(d.items) ? (d.items as T[]) : [];
    return {
      items,
      page: typeof d.page === "number" ? d.page : 1,
      totalPages:
        typeof d.totalPages === "number"
          ? d.totalPages
          : Math.max(1, Math.ceil(items.length / pageSize)),
    };
  }
  return { items: [], page: 1, totalPages: 1 };
}

function extractArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.items)) return d.items as T[];
  }
  return [];
}

function extractListDetail(data: unknown): { members: Creator[]; name: string } {
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    const list = (d.list && typeof d.list === "object" ? d.list : d) as Record<string, unknown>;
    const members = Array.isArray(list.members)
      ? (list.members as Creator[])
      : Array.isArray(d.members)
        ? (d.members as Creator[])
        : extractArray<Creator>(d.items);
    return {
      members,
      name: typeof list.name === "string" ? list.name : "",
    };
  }
  return { members: [], name: "" };
}

function creatorLabel(c: Creator): string {
  return c.displayName || c.handle || "Unknown creator";
}

function initialsFor(c: Creator): string {
  const src = creatorLabel(c).trim() || "?";
  return src.slice(0, 2).toUpperCase();
}

function Avatar({ creator }: { creator: Creator }): React.JSX.Element {
  if (creator.avatarUrl) {
    return (
      <img
        src={creator.avatarUrl}
        alt=""
        className="h-9 w-9 rounded-full object-cover"
      />
    );
  }
  return (
    <span
      className="flex h-9 w-9 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700"
      aria-hidden="true"
    >
      {initialsFor(creator)}
    </span>
  );
}

interface CreatorFormState {
  handle: string;
  displayName: string;
  followerCount: string;
  tags: string;
  notes: string;
}

const EMPTY_FORM: CreatorFormState = {
  handle: "",
  displayName: "",
  followerCount: "",
  tags: "",
  notes: "",
};

export default function CreatorsPage(): React.JSX.Element {
  const { orgId, selectedShop, isDemo } = useOrg();

  const [tab, setTab] = useState<TabKey>("creators");

  // ---------- Creators tab state ----------
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [tag, setTag] = useState("");
  const [listId, setListId] = useState("all");
  const [page, setPage] = useState(1);

  const [creators, setCreators] = useState<Creator[]>([]);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  // Client-side fallback membership when the API ignores listId.
  const [listMembers, setListMembers] = useState<Creator[] | null>(null);

  // Add/Edit modal.
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Creator | null>(null);
  const [form, setForm] = useState<CreatorFormState>(EMPTY_FORM);
  const [formSaving, setFormSaving] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]> | null>(null);
  const [formErrors, setFormErrors] = useState<string[]>([]);

  // Delete.
  const [deleting, setDeleting] = useState<Creator | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Invite to campaign.
  const [inviteCreator, setInviteCreator] = useState<Creator | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [campaignsLoading, setCampaignsLoading] = useState(false);
  const [inviteCampaignId, setInviteCampaignId] = useState("");
  const [inviteSaving, setInviteSaving] = useState(false);
  const [inviteResult, setInviteResult] = useState<{ ok: boolean; message: string } | null>(null);

  // Export.
  const [exportJobId, setExportJobId] = useState<string | null>(null);
  const [exportStatus, setExportStatus] = useState<"idle" | "running" | "ready" | "failed">("idle");
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportStarting, setExportStarting] = useState(false);
  const pollTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ---------- Lists tab state ----------
  const [lists, setLists] = useState<CreatorList[]>([]);
  const [listsLoading, setListsLoading] = useState(true);
  const [listsError, setListsError] = useState<string | null>(null);
  const [newListName, setNewListName] = useState("");
  const [creatingList, setCreatingList] = useState(false);
  const [renaming, setRenaming] = useState<CreatorList | null>(null);
  const [renameName, setRenameName] = useState("");
  const [renameSaving, setRenameSaving] = useState(false);
  const [deletingList, setDeletingList] = useState<CreatorList | null>(null);
  const [deleteListLoading, setDeleteListLoading] = useState(false);
  const [selectedListId, setSelectedListId] = useState<string | null>(null);
  const [members, setMembers] = useState<Creator[]>([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [addMemberId, setAddMemberId] = useState("");
  const [addMemberLoading, setAddMemberLoading] = useState(false);
  const [removeMember, setRemoveMember] = useState<Creator | null>(null);
  const [removeMemberLoading, setRemoveMemberLoading] = useState(false);

  // Debounce search + tag inputs (400ms).
  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(searchInput.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [searchInput]);

  useEffect(() => {
    const t = setTimeout(() => {
      setTag(tagInput.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [tagInput]);

  const loadCreators = useCallback(async () => {
    if (!orgId) return;
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({
        page: String(page),
        pageSize: String(PAGE_SIZE),
      });
      if (search) qs.set("search", search);
      if (tag) qs.set("tag", tag);
      if (listId !== "all") qs.set("listId", listId);
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/creators?${qs.toString()}`);
      let { items, page: p, totalPages: tp } = extractPage<Creator>(data, PAGE_SIZE);
      // Client-side fallback: the API may not support tag/listId filters.
      if (tag) {
        const q = tag.toLowerCase();
        items = items.filter((c) =>
          parseTags(c.tags).some((t) => t.toLowerCase().includes(q))
        );
      }
      if (listId !== "all" && listMembers !== null) {
        const memberIds = new Set(listMembers.map((m) => m.id));
        items = items.filter((c) => memberIds.has(c.id));
      }
      setCreators(items);
      setCurrentPage(p);
      setTotalPages(tp);
    } catch (e: unknown) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, [orgId, search, tag, listId, page, listMembers]);

  useEffect(() => {
    if (tab === "creators") loadCreators();
  }, [tab, loadCreators, reloadKey]);

  // Fetch list members client-side when a list filter is chosen (fallback).
  useEffect(() => {
    if (!orgId || listId === "all") {
      setListMembers(null);
      return;
    }
    let cancelled = false;
    apiFetch<unknown>(`/api/orgs/${orgId}/creator-lists/${listId}`)
      .then((data) => {
        if (!cancelled) setListMembers(extractListDetail(data).members);
      })
      .catch(() => {
        if (!cancelled) setListMembers(null);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, listId]);

  const loadLists = useCallback(async () => {
    if (!orgId) return;
    setListsLoading(true);
    setListsError(null);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/creator-lists`);
      setLists(extractArray<CreatorList>(data));
    } catch (e: unknown) {
      setListsError(getErrorMessage(e));
    } finally {
      setListsLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    loadLists();
  }, [loadLists]);

  useEffect(() => {
    return () => {
      if (pollTimer.current) clearTimeout(pollTimer.current);
    };
  }, []);

  // ---------- Creator CRUD ----------
  const openAdd = () => {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFieldErrors(null);
    setFormErrors([]);
    setFormOpen(true);
  };

  const openEdit = (c: Creator) => {
    setEditing(c);
    setForm({
      handle: c.handle ?? "",
      displayName: c.displayName ?? "",
      followerCount: c.followerCount != null ? String(c.followerCount) : "",
      tags: parseTags(c.tags).join(", "),
      notes: c.notes ?? "",
    });
    setFieldErrors(null);
    setFormErrors([]);
    setFormOpen(true);
  };

  const saveCreator = async () => {
    if (!orgId) return;
    setFormSaving(true);
    setFieldErrors(null);
    setFormErrors([]);
    const payload = {
      handle: form.handle.trim(),
      displayName: form.displayName.trim() || null,
      followerCount: form.followerCount === "" ? null : Number(form.followerCount),
      tags: form.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
      notes: form.notes.trim() || null,
    };
    try {
      if (editing) {
        await apiFetch(`/api/orgs/${orgId}/creators/${editing.id}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
      } else {
        await apiFetch(`/api/orgs/${orgId}/creators`, {
          method: "POST",
          body: JSON.stringify(payload),
        });
      }
      setFormOpen(false);
      setReloadKey((k) => k + 1);
    } catch (e: unknown) {
      const fe = getFieldErrors(e);
      if (fe) setFieldErrors(fe);
      else setFormErrors([getErrorMessage(e)]);
      // Inputs are preserved on failure.
    } finally {
      setFormSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!orgId || !deleting) return;
    setDeleteLoading(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/creators/${deleting.id}`, { method: "DELETE" });
      setDeleting(null);
      setReloadKey((k) => k + 1);
    } catch (e: unknown) {
      setError(getErrorMessage(e));
      setDeleting(null);
    } finally {
      setDeleteLoading(false);
    }
  };

  // ---------- Invite to campaign ----------
  const openInvite = async (c: Creator) => {
    setInviteCreator(c);
    setInviteCampaignId("");
    setInviteResult(null);
    if (!orgId) return;
    setCampaignsLoading(true);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/campaigns?page=1&pageSize=100`);
      setCampaigns(extractArray<Campaign>(data));
    } catch {
      setCampaigns([]);
    } finally {
      setCampaignsLoading(false);
    }
  };

  const submitInvite = async () => {
    if (!orgId || !inviteCreator || !inviteCampaignId) return;
    setInviteSaving(true);
    setInviteResult(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/campaigns/${inviteCampaignId}/collaborations`, {
        method: "POST",
        body: JSON.stringify({ creatorId: inviteCreator.id }),
      });
      setInviteResult({ ok: true, message: "Invitation created." });
      setInviteCreator(null);
    } catch (e: unknown) {
      setInviteResult({ ok: false, message: getErrorMessage(e) });
    } finally {
      setInviteSaving(false);
    }
  };

  // ---------- Export ----------
  const pollExport = useCallback(
    async (jobId: string, attempt: number) => {
      if (!orgId) return;
      if (attempt * 3 >= 60) {
        setExportStatus("failed");
        setExportError("Export timed out. Please try again.");
        return;
      }
      try {
        const data = await apiFetch<unknown>(`/api/orgs/${orgId}/exports`);
        const jobs = extractArray<ExportJobItem>(data);
        const job = jobs.find((j) => j.id === jobId);
        if (!job) {
          setExportStatus("failed");
          setExportError("Export job not found.");
          return;
        }
        if (job.status === "ready") {
          setExportStatus("ready");
          return;
        }
        if (job.status === "failed") {
          setExportStatus("failed");
          setExportError(job.error ?? "Export failed.");
          return;
        }
        setExportStatus("running");
        pollTimer.current = setTimeout(() => pollExport(jobId, attempt + 1), 3000);
      } catch (e: unknown) {
        setExportStatus("failed");
        setExportError(getErrorMessage(e));
      }
    },
    [orgId]
  );

  const startExport = async () => {
    if (!orgId) return;
    setExportStarting(true);
    setExportError(null);
    setExportStatus("idle");
    try {
      const data = await apiFetch<{ id: string }>(`/api/orgs/${orgId}/exports`, {
        method: "POST",
        body: JSON.stringify({ kind: "creators" }),
      });
      const jobId = data?.id ?? (data as unknown as { job?: { id: string } })?.job?.id;
      if (!jobId) throw new Error("Export job could not be started.");
      setExportJobId(jobId);
      setExportStatus("running");
      pollExport(jobId, 0);
    } catch (e: unknown) {
      setExportStatus("failed");
      setExportError(getErrorMessage(e));
    } finally {
      setExportStarting(false);
    }
  };

  // ---------- Lists ----------
  const createList = async () => {
    if (!orgId || !newListName.trim()) return;
    setCreatingList(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/creator-lists`, {
        method: "POST",
        body: JSON.stringify({ name: newListName.trim() }),
      });
      setNewListName("");
      loadLists();
    } catch (e: unknown) {
      setListsError(getErrorMessage(e));
    } finally {
      setCreatingList(false);
    }
  };

  const openRename = (l: CreatorList) => {
    setRenaming(l);
    setRenameName(l.name);
  };

  const saveRename = async () => {
    if (!orgId || !renaming) return;
    setRenameSaving(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/creator-lists/${renaming.id}`, {
        method: "PATCH",
        body: JSON.stringify({ name: renameName.trim() }),
      });
      setRenaming(null);
      loadLists();
    } catch (e: unknown) {
      setListsError(getErrorMessage(e));
    } finally {
      setRenameSaving(false);
    }
  };

  const confirmDeleteList = async () => {
    if (!orgId || !deletingList) return;
    setDeleteListLoading(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/creator-lists/${deletingList.id}`, { method: "DELETE" });
      if (selectedListId === deletingList.id) {
        setSelectedListId(null);
        setMembers([]);
      }
      if (listId === deletingList.id) setListId("all");
      setDeletingList(null);
      loadLists();
    } catch (e: unknown) {
      setListsError(getErrorMessage(e));
      setDeletingList(null);
    } finally {
      setDeleteListLoading(false);
    }
  };

  const loadMembers = useCallback(
    async (list: CreatorList) => {
      if (!orgId) return;
      setMembersLoading(true);
      try {
        const data = await apiFetch<unknown>(`/api/orgs/${orgId}/creator-lists/${list.id}`);
        const detail = extractListDetail(data);
        setMembers(detail.members);
        if (!list.name && detail.name) {
          setLists((prev) => prev.map((l) => (l.id === list.id ? { ...l, name: detail.name } : l)));
        }
      } catch (e: unknown) {
        setListsError(getErrorMessage(e));
        setMembers([]);
      } finally {
        setMembersLoading(false);
      }
    },
    [orgId]
  );

  const selectList = (l: CreatorList) => {
    setSelectedListId(l.id);
    setAddMemberId("");
    loadMembers(l);
  };

  const addMember = async () => {
    if (!orgId || !selectedListId || !addMemberId) return;
    setAddMemberLoading(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/creator-lists/${selectedListId}/members`, {
        method: "POST",
        body: JSON.stringify({ creatorId: addMemberId }),
      });
      setAddMemberId("");
      const list = lists.find((l) => l.id === selectedListId);
      if (list) loadMembers(list);
      loadLists();
    } catch (e: unknown) {
      setListsError(getErrorMessage(e));
    } finally {
      setAddMemberLoading(false);
    }
  };

  const confirmRemoveMember = async () => {
    if (!orgId || !selectedListId || !removeMember) return;
    setRemoveMemberLoading(true);
    try {
      await apiFetch(`/api/orgs/${orgId}/creator-lists/${selectedListId}/members`, {
        method: "DELETE",
        body: JSON.stringify({ creatorId: removeMember.id }),
      });
      setRemoveMember(null);
      const list = lists.find((l) => l.id === selectedListId);
      if (list) loadMembers(list);
      loadLists();
    } catch (e: unknown) {
      setListsError(getErrorMessage(e));
      setRemoveMember(null);
    } finally {
      setRemoveMemberLoading(false);
    }
  };

  const creatorsNotInList = useMemo(() => {
    const memberIds = new Set(members.map((m) => m.id));
    return creators.filter((c) => !memberIds.has(c.id));
  }, [creators, members]);

  const creatorColumns = [
    {
      key: "creator",
      header: "Creator",
      render: (c: Creator) => (
        <div className="flex items-center gap-3">
          <Avatar creator={c} />
          <div className="flex flex-col">
            <span className="font-medium text-slate-900">{creatorLabel(c)}</span>
            {c.handle && <span className="text-xs text-slate-500">@{c.handle}</span>}
          </div>
        </div>
      ),
    },
    {
      key: "followers",
      header: "Followers",
      render: (c: Creator) => formatNumber(c.followerCount),
    },
    {
      key: "source",
      header: "Source",
      render: (c: Creator) => (
        <div className="flex flex-wrap gap-1">
          {c.source === "tiktok_api" ? (
            <Badge tone="blue">TikTok API</Badge>
          ) : (
            <Badge tone="gray">Entered manually</Badge>
          )}
          {(c.isDemo ?? isDemo) && <Badge tone="yellow">Demo</Badge>}
        </div>
      ),
    },
    {
      key: "tags",
      header: "Tags",
      render: (c: Creator) => {
        const tags = parseTags(c.tags);
        if (tags.length === 0) return "—";
        return (
          <div className="flex flex-wrap gap-1">
            {tags.slice(0, 3).map((t) => (
              <Badge key={t} tone="gray">
                {t}
              </Badge>
            ))}
            {tags.length > 3 && <Badge tone="gray">+{tags.length - 3}</Badge>}
          </div>
        );
      },
    },
    {
      key: "actions",
      header: "",
      className: "text-right",
      render: (c: Creator) => (
        <Can minRole="campaign_manager">
          <div className="flex justify-end gap-1">
            <Button variant="ghost" size="sm" onClick={() => openEdit(c)} ariaLabel={`Edit ${creatorLabel(c)}`}>
              Edit
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => openInvite(c)}
              ariaLabel={`Invite ${creatorLabel(c)} to campaign`}
              title="Invite to campaign"
            >
              <PlusIcon className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDeleting(c)}
              ariaLabel={`Delete ${creatorLabel(c)}`}
              title="Delete"
            >
              <XIcon className="h-4 w-4" aria-hidden="true" />
            </Button>
          </div>
        </Can>
      ),
    },
  ];

  const memberColumns = [
    {
      key: "creator",
      header: "Creator",
      render: (c: Creator) => (
        <div className="flex items-center gap-3">
          <Avatar creator={c} />
          <div className="flex flex-col">
            <span className="font-medium text-slate-900">{creatorLabel(c)}</span>
            {c.handle && <span className="text-xs text-slate-500">@{c.handle}</span>}
          </div>
        </div>
      ),
    },
    {
      key: "followers",
      header: "Followers",
      render: (c: Creator) => formatNumber(c.followerCount),
    },
    {
      key: "actions",
      header: "",
      className: "text-right",
      render: (c: Creator) => (
        <Can minRole="campaign_manager">
          <Button variant="ghost" size="sm" onClick={() => setRemoveMember(c)}>
            Remove
          </Button>
        </Can>
      ),
    },
  ];

  const selectedList = lists.find((l) => l.id === selectedListId) ?? null;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Creators"
        subtitle="Manage the creators you work with and organize them into lists."
        actions={
          inviteResult?.ok ? (
            <Alert tone="success" title="Invitation created" onDismiss={() => setInviteResult(null)}>
              The creator has been invited to the campaign.
            </Alert>
          ) : inviteResult ? (
            <Alert tone="error" title="Invitation failed" onDismiss={() => setInviteResult(null)}>
              {inviteResult.message}
            </Alert>
          ) : null
        }
      />

      <div role="tablist" aria-label="Creators sections" className="flex gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => setTab(t.key)}
            className={cx(
              "px-4 py-2 text-sm font-medium",
              tab === t.key
                ? "border-b-2 border-indigo-600 text-indigo-700"
                : "text-slate-500 hover:text-slate-800"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "creators" && (
        <div className="space-y-6">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
            <div className="flex-1">
              <Input
                label="Search creators"
                name="search"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search by name or handle…"
              />
            </div>
            <div className="w-full lg:w-48">
              <Input
                label="Filter by tag"
                name="tag"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Filter by tag"
              />
            </div>
            <div className="w-full lg:w-48">
              <Select
                label="List"
                name="listFilter"
                value={listId}
                onChange={(e) => {
                  setListId(e.target.value);
                  setPage(1);
                }}
                options={[
                  { value: "all", label: "All lists" },
                  ...lists.map((l) => ({ value: l.id, label: l.name })),
                ]}
              />
            </div>
            <div className="flex gap-2">
              <Can minRole="campaign_manager">
                <Button onClick={openAdd}>
                  <PlusIcon className="h-4 w-4" aria-hidden="true" />
                  Add creator
                </Button>
              </Can>
              {/* CSV export: server requires campaign_manager; enforced by the API. */}
              <Can minRole="campaign_manager">
                <Button
                  variant="secondary"
                  onClick={startExport}
                  loading={exportStarting || exportStatus === "running"}
                  disabled={exportStarting || exportStatus === "running"}
                >
                  <DownloadIcon className="h-4 w-4" aria-hidden="true" />
                  Export
                </Button>
              </Can>
            </div>
          </div>

          {exportError && (
            <Alert tone="error" title="Export failed" onDismiss={() => setExportError(null)}>
              {exportError}
            </Alert>
          )}
          {exportStatus === "ready" && exportJobId && (
            <Alert tone="success" title="Export ready">
              <a
                href={`/api/orgs/${orgId}/exports/${exportJobId}/download`}
                className="font-medium text-indigo-600 hover:underline"
                download
              >
                Download CSV
              </a>
            </Alert>
          )}

          {error && (
            <Alert tone="error" title="Couldn't load creators" onDismiss={() => setError(null)}>
              <div className="flex flex-col gap-2">
                <p>{error}</p>
                <div>
                  <Button variant="secondary" size="sm" onClick={() => setReloadKey((k) => k + 1)}>
                    Retry
                  </Button>
                </div>
              </div>
            </Alert>
          )}

          {loading ? (
            <SkeletonLines lines={6} />
          ) : creators.length === 0 ? (
            <EmptyState
              icon={<UsersIcon className="h-10 w-10" aria-hidden="true" />}
              title="No creators yet"
              body="Add creators manually to keep track of who you work with."
              action={
                <Can minRole="campaign_manager">
                  <Button onClick={openAdd}>
                    <PlusIcon className="h-4 w-4" aria-hidden="true" />
                    Add creator
                  </Button>
                </Can>
              }
            />
          ) : (
            <>
              <Table
                columns={creatorColumns}
                data={creators}
                rowKey={(c) => c.id}
                ariaLabel="Creators"
              />
              {totalPages > 1 && (
                <Pagination page={currentPage} totalPages={totalPages} onChange={setPage} />
              )}
            </>
          )}
        </div>
      )}

      {tab === "lists" && (
        <div className="grid gap-6 lg:grid-cols-3">
          <Card title="Lists">
            <div className="mb-4 flex gap-2">
              <div className="flex-1">
                <Input
                  label="New list name"
                  name="newListName"
                  value={newListName}
                  onChange={(e) => setNewListName(e.target.value)}
                  placeholder="e.g. Fitness creators"
                />
              </div>
              <div className="pt-6">
                <Can minRole="campaign_manager">
                  <Button
                    size="sm"
                    onClick={createList}
                    loading={creatingList}
                    disabled={creatingList || !newListName.trim()}
                  >
                    <PlusIcon className="h-4 w-4" aria-hidden="true" />
                    Create
                  </Button>
                </Can>
              </div>
            </div>
            {listsLoading ? (
              <SkeletonLines lines={3} />
            ) : listsError ? (
              <Alert tone="error" title="Couldn't load lists" onDismiss={() => setListsError(null)}>
                <div className="flex flex-col gap-2">
                  <p>{listsError}</p>
                  <div>
                    <Button variant="secondary" size="sm" onClick={loadLists}>
                      Retry
                    </Button>
                  </div>
                </div>
              </Alert>
            ) : lists.length === 0 ? (
              <p className="text-sm text-slate-500">No lists yet. Create one to organize creators.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {lists.map((l) => (
                  <li
                    key={l.id}
                    className={cx(
                      "flex items-center justify-between gap-2 py-2",
                      selectedListId === l.id && "font-semibold"
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => selectList(l)}
                      className="flex-1 truncate text-left text-sm text-slate-900 hover:text-indigo-600"
                    >
                      {l.name}
                      {typeof l.memberCount === "number" && (
                        <span className="ml-2 text-xs text-slate-400">({l.memberCount})</span>
                      )}
                    </button>
                    <Can minRole="campaign_manager">
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openRename(l)}>
                          Rename
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setDeletingList(l)}>
                          Delete
                        </Button>
                      </div>
                    </Can>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <div className="lg:col-span-2">
            <Card
              title={selectedList ? `Members — ${selectedList.name}` : "Members"}
              subtitle={selectedList ? "Creators in this list." : "Select a list to see its members."}
            >
              {!selectedList ? (
                <EmptyState
                  icon={<EmptyBoxIcon className="h-10 w-10" aria-hidden="true" />}
                  title="No list selected"
                  body="Pick a list on the left to view and manage its members."
                />
              ) : (
                <div className="space-y-4">
                  <Can minRole="campaign_manager">
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <Select
                          label="Add creator"
                          name="addMember"
                          value={addMemberId}
                          onChange={(e) => setAddMemberId(e.target.value)}
                          options={[
                            { value: "", label: "Select a creator to add" },
                            ...creatorsNotInList.map((c) => ({
                              value: c.id,
                              label: `${creatorLabel(c)}${c.handle ? ` (@${c.handle})` : ""}`,
                            })),
                          ]}
                        />
                      </div>
                      <div className="pt-6">
                        <Button
                          size="sm"
                          onClick={addMember}
                          loading={addMemberLoading}
                          disabled={addMemberLoading || !addMemberId}
                        >
                          Add
                        </Button>
                      </div>
                    </div>
                  </Can>
                  {membersLoading ? (
                    <SkeletonLines lines={4} />
                  ) : members.length === 0 ? (
                    <EmptyState
                      icon={<UsersIcon className="h-10 w-10" aria-hidden="true" />}
                      title="No members yet"
                      body="Add creators to this list to keep them organized."
                    />
                  ) : (
                    <Table
                      columns={memberColumns}
                      data={members}
                      rowKey={(c) => c.id}
                      ariaLabel={`Members of ${selectedList.name}`}
                    />
                  )}
                </div>
              )}
            </Card>
          </div>
        </div>
      )}

      {/* Add/Edit creator modal */}
      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editing ? "Edit creator" : "Add creator"}
        footer={
          <>
            <Button variant="secondary" onClick={() => setFormOpen(false)} disabled={formSaving}>
              Cancel
            </Button>
            <Button onClick={saveCreator} loading={formSaving} disabled={formSaving}>
              {editing ? "Save changes" : "Add creator"}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formErrors.length > 0 && (
            <Alert tone="error" title="Couldn't save creator">
              <ul className="list-disc pl-5">
                {formErrors.map((m, i) => (
                  <li key={i}>{m}</li>
                ))}
              </ul>
            </Alert>
          )}
          <FormErrors errors={fieldErrors} />
          <div>
            <Input
              label="Handle"
              name="handle"
              value={form.handle}
              onChange={(e) => setForm((f) => ({ ...f, handle: e.target.value }))}
              placeholder="@username"
              required
            />
            {fieldErrors?.handle && <FieldError error={fieldErrors.handle} />}
          </div>
          <div>
            <Input
              label="Display name"
              name="displayName"
              value={form.displayName}
              onChange={(e) => setForm((f) => ({ ...f, displayName: e.target.value }))}
              placeholder="Creator's display name"
            />
            {fieldErrors?.displayName && <FieldError error={fieldErrors.displayName} />}
          </div>
          <div>
            <Input
              label="Follower count"
              name="followerCount"
              type="number"
              value={form.followerCount}
              onChange={(e) => setForm((f) => ({ ...f, followerCount: e.target.value }))}
              placeholder="e.g. 12500"
            />
            {fieldErrors?.followerCount && <FieldError error={fieldErrors.followerCount} />}
          </div>
          <div>
            <Input
              label="Tags"
              name="tags"
              value={form.tags}
              onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))}
              placeholder="fitness, skincare, unboxing"
              hint="Comma-separated"
            />
            {fieldErrors?.tags && <FieldError error={fieldErrors.tags} />}
          </div>
          <div>
            <p className="mb-1 text-sm font-medium text-slate-700">
              Your notes <span className="font-normal text-slate-500">(stored locally in this app — never sent to TikTok)</span>
            </p>
            <Textarea
              label="Notes"
              name="notes"
              value={form.notes}
              onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
              placeholder="Private notes about this creator…"
              rows={3}
            />
            {fieldErrors?.notes && <FieldError error={fieldErrors.notes} />}
          </div>
        </div>
      </Modal>

      {/* Delete creator confirm */}
      <ConfirmDialog
        open={deleting !== null}
        title="Delete creator"
        body={
          deleting
            ? `Delete ${creatorLabel(deleting)} from your creators? This cannot be undone.`
            : ""
        }
        confirmLabel="Delete"
        cancelLabel="Cancel"
        danger
        loading={deleteLoading}
        onConfirm={confirmDelete}
        onCancel={() => setDeleting(null)}
      />

      {/* Invite to campaign modal */}
      <Modal
        open={inviteCreator !== null}
        onClose={() => setInviteCreator(null)}
        title={
          inviteCreator ? `Invite ${creatorLabel(inviteCreator)} to a campaign` : "Invite to campaign"
        }
        footer={
          <>
            <Button variant="secondary" onClick={() => setInviteCreator(null)} disabled={inviteSaving}>
              Cancel
            </Button>
            <Button
              onClick={submitInvite}
              loading={inviteSaving}
              disabled={inviteSaving || !inviteCampaignId}
            >
              Send invitation
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {inviteResult && !inviteResult.ok && (
            <Alert tone="error" title="Couldn't create invitation" onDismiss={() => setInviteResult(null)}>
              {inviteResult.message}
            </Alert>
          )}
          <Select
            label="Campaign"
            name="inviteCampaign"
            value={inviteCampaignId}
            onChange={(e) => setInviteCampaignId(e.target.value)}
            disabled={campaignsLoading}
            required
            options={[
              { value: "", label: campaignsLoading ? "Loading campaigns…" : "Select a campaign" },
              ...campaigns.map((c) => ({ value: c.id, label: c.name })),
            ]}
          />
        </div>
      </Modal>

      {/* Rename list modal */}
      <Modal
        open={renaming !== null}
        onClose={() => setRenaming(null)}
        title="Rename list"
        footer={
          <>
            <Button variant="secondary" onClick={() => setRenaming(null)} disabled={renameSaving}>
              Cancel
            </Button>
            <Button onClick={saveRename} loading={renameSaving} disabled={renameSaving || !renameName.trim()}>
              Save
            </Button>
          </>
        }
      >
        <Input
          label="List name"
          name="renameName"
          value={renameName}
          onChange={(e) => setRenameName(e.target.value)}
          required
        />
      </Modal>

      {/* Delete list confirm */}
      <ConfirmDialog
        open={deletingList !== null}
        title="Delete list"
        body={
          deletingList
            ? `Delete the list "${deletingList.name}"? The creators themselves will not be deleted.`
            : ""
        }
        confirmLabel="Delete"
        cancelLabel="Cancel"
        danger
        loading={deleteListLoading}
        onConfirm={confirmDeleteList}
        onCancel={() => setDeletingList(null)}
      />

      {/* Remove member confirm */}
      <ConfirmDialog
        open={removeMember !== null}
        title="Remove from list"
        body={
          removeMember && selectedList
            ? `Remove ${creatorLabel(removeMember)} from "${selectedList.name}"?`
            : ""
        }
        confirmLabel="Remove"
        cancelLabel="Cancel"
        danger
        loading={removeMemberLoading}
        onConfirm={confirmRemoveMember}
        onCancel={() => setRemoveMember(null)}
      />
    </div>
  );
}
