import { Card } from "@/components/Card";
import { PageHeader } from "@/components/PageHeader";
import { Table } from "@/components/Table";
import { Alert } from "@/components/Alert";
import { roleLabel } from "@/lib/roles";

interface RoleRow {
  role: string;
  can: string;
}

const ROLE_ROWS: RoleRow[] = [
  {
    role: "owner",
    can: "Full control: everything below, plus managing owners and deleting the organization.",
  },
  {
    role: "admin",
    can: "Manage everything except ownership: team, shops, settings, syncs, exports.",
  },
  {
    role: "campaign_manager",
    can: "Create and manage campaigns, products, creators, and invitations to collaborate; run syncs and generate exports.",
  },
  {
    role: "analyst",
    can: "View dashboards, reports, products, campaigns, and creators. No changes.",
  },
  {
    role: "read_only",
    can: "View permitted data only. No changes of any kind.",
  },
];

export default function DocsPage(): React.JSX.Element {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Help & docs"
        subtitle="Answers to common questions about this workspace."
      />

      <Card
        title="Demo mode"
        subtitle="What simulated data means."
      >
        <div id="demo-mode" className="space-y-3 text-sm text-slate-600 scroll-mt-24">
          <p>
            When a shop is connected in demo mode, every number you see is
            simulated — clearly labeled with amber “Demo data” badges. Nothing
            here touches TikTok in demo mode, and nothing is sent to any real
            account.
          </p>
          <p>
            Demo data exists so you can explore the app, try syncs, campaigns,
            and exports before connecting a real TikTok Shop. When you’re ready,
            connect a real shop from <strong>Settings → Connected shops</strong>
            and your live data replaces the simulated data.
          </p>
          <Alert tone="warning" title="Demo data is simulated">
            <p className="text-sm">
              Never make business decisions from demo numbers. Look for the
              amber “Demo data” label on every metric.
            </p>
          </Alert>
        </div>
      </Card>

      <Card
        title="Connecting your TikTok Shop"
        subtitle="The seller authorization flow."
      >
        <div id="connecting" className="space-y-3 text-sm text-slate-600 scroll-mt-24">
          <ol className="list-decimal space-y-2 pl-5">
            <li>
              Go to <strong>Settings → Connected shops</strong> and choose
              “Connect shop”.
            </li>
            <li>
              You’ll be sent to TikTok to approve access. Log in with the
              account that manages your TikTok Shop.
            </li>
            <li>Review the permissions being requested and approve them.</li>
            <li>
              You’ll be redirected back here — confirm the shop’s identity
              before syncing.
            </li>
          </ol>
          <p>
            Seller authorization and creator authorization are separate: a
            seller connects their shop here, while creators accept campaign
            invitations through their own flow. One doesn’t grant the other.
          </p>
          <p>
            If a feature shows as unavailable after connecting, check the
            “Granted scopes” on the shop’s details panel — the shop may not
            have approved every permission.
          </p>
        </div>
      </Card>

      <Card
        title="Roles & permissions"
        subtitle="Who can do what."
      >
        <div id="roles" className="space-y-3 scroll-mt-24">
          <Table
            ariaLabel="Roles and permissions"
            rowKey={(r: RoleRow) => r.role}
            data={ROLE_ROWS}
            columns={[
              {
                key: "role",
                header: "Role",
                render: (r: RoleRow) => (
                  <span className="font-medium text-slate-900">{roleLabel(r.role)}</span>
                ),
              },
              {
                key: "can",
                header: "What they can do",
                render: (r: RoleRow) => (
                  <span className="text-sm text-slate-600">{r.can}</span>
                ),
              },
            ]}
          />
          <p className="text-sm text-slate-600">
            The final owner of an organization can’t be demoted or removed —
            transfer ownership first. Roles shown in the UI are a convenience:
            every permission is enforced on the server for every request.
          </p>
        </div>
      </Card>

      <Card
        title="Data freshness"
        subtitle="How current your numbers are."
      >
        <div id="data-freshness" className="space-y-3 text-sm text-slate-600 scroll-mt-24">
          <p>
            Every metric shows its source and sync time (e.g. “TikTok API ·
            synced 5m ago”). TikTok’s own data may be delayed or revised, so
            recent numbers can shift slightly as TikTok finalizes them.
          </p>
          <p>
            If a metric shows <strong>“Not available”</strong>, the connected
            TikTok Shop API didn’t return it for that period. It is never
            estimated silently — you’ll always see an explicit notice instead
            of a guessed number.
          </p>
        </div>
      </Card>

      <Card
        title="Exports & privacy"
        subtitle="Your data, under your control."
      >
        <div id="exports-privacy" className="space-y-4 text-sm text-slate-600 scroll-mt-24">
          <p>
            CSV exports (for example from the Reports page) download straight
            to your device. The audit log records who did what, and is visible
            to admins under <strong>Settings → Audit log</strong>.
          </p>
          <h3 id="privacy" className="font-semibold text-slate-900 scroll-mt-24">
            Privacy
          </h3>
          <p>
            Your workspace stores the data you sync from TikTok Shop in order
            to show dashboards, reports, and exports. Disconnecting a shop
            deletes its stored credentials immediately.
          </p>
          <h3 id="terms" className="font-semibold text-slate-900 scroll-mt-24">
            Terms
          </h3>
          <p>
            Use of TikTok Shop data is subject to TikTok’s own platform terms
            in addition to this workspace’s terms. You’re responsible for how
            you use exported data.
          </p>
        </div>
      </Card>

      <Card title="Support" subtitle="Where to get help.">
        <div id="support" className="space-y-3 text-sm text-slate-600 scroll-mt-24">
          <p>
            Contact your workspace admin or TikTok Shop Partner Center for API
            approval questions.
          </p>
        </div>
      </Card>
    </div>
  );
}
