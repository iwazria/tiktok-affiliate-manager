"use client";

import { useEffect, useState } from "react";
import { apiFetch, getErrorMessage } from "@/lib/client";
import { useOrg } from "@/components/OrgContext";
import type {
  AuditLogItem,
  NotificationPref,
  Shop,
} from "@/lib/types";
import {
  cx,
  formatDateTime,
  timeAgo,
  truncate,
} from "@/lib/format";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { Input } from "@/components/Input";
import { Alert } from "@/components/Alert";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { PageHeader } from "@/components/PageHeader";
import { Table } from "@/components/Table";
import { Can } from "@/components/RoleGate";
import { PermissionDenied } from "@/components/PermissionDenied";
import { CapabilityNote } from "@/components/CapabilityNote";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { GearIcon, RefreshIcon } from "@/components/icons";

function asArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const items = (data as { items?: unknown }).items;
    if (Array.isArray(items)) return items as T[];
  }
  return [];
}

/* ---------------- Organization profile ---------------- */

function OrgProfileCard(): React.JSX.Element {
  const { org, orgId, orgSlug } = useOrg();
  const [name, setName] = useState(org?.name ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    setName(org?.name ?? "");
  }, [org?.name]);

  const save = async () => {
    if (!orgId || !name.trim()) return;
    setSaving(true);
    setError(null);
    setSuccess(false);
    try {
      await apiFetch(`/api/orgs/${orgId}`, {
        method: "PATCH",
        body: JSON.stringify({ name: name.trim() }),
      });
      setSuccess(true);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card title="Organization profile" subtitle="The name shown across your workspace.">
      <div className="space-y-4">
        {error && (
          <Alert tone="error" title="Couldn’t save" onDismiss={() => setError(null)}>
            <p className="text-sm">{error}</p>
          </Alert>
        )}
        {success && (
          <Alert tone="success" title="Saved" onDismiss={() => setSuccess(false)}>
            <p className="text-sm">Organization name updated.</p>
          </Alert>
        )}
        <Can
          minRole="admin"
          fallback={
            <div>
              <p className="text-sm text-slate-500">Name</p>
              <p className="mt-1 text-base font-medium text-slate-900">{org?.name ?? "—"}</p>
            </div>
          }
        >
          <div className="max-w-md space-y-3">
            <Input
              label="Organization name"
              name="org-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={saving}
              required
            />
            <Button variant="primary" onClick={save} loading={saving} disabled={!name.trim()}>
              Save
            </Button>
          </div>
        </Can>
        <p className="text-sm text-slate-500">
          Slug: <span className="font-mono text-slate-700">{orgSlug}</span> (read-only)
        </p>
      </div>
    </Card>
  );
}

/* ---------------- Connected shops ---------------- */

function modeBadge(shop: Shop): React.JSX.Element {
  return shop.mode === "demo" ? (
    <Badge tone="yellow">demo</Badge>
  ) : (
    <Badge tone="green">live</Badge>
  );
}

function statusBadge(status: string): React.JSX.Element {
  if (status === "connected") return <Badge tone="green">connected</Badge>;
  if (status === "expired") return <Badge tone="yellow">expired</Badge>;
  if (status === "revoked") return <Badge tone="gray">revoked</Badge>;
  if (status === "error") return <Badge tone="red">error</Badge>;
  return <Badge tone="gray">{status}</Badge>;
}

/** Real shape: GET /api/orgs/[orgId]/shops/[shopId] → { shop, scopes: string[], capabilities: Record<key,{available,reason}>, sync } */
interface ShopDetailResponse {
  shop?: Record<string, unknown>;
  scopes?: string[];
  capabilities?: Record<string, { available: boolean; reason?: string }>;
  sync?: { lastSyncAt?: string | null; lastSyncStatus?: string | null; lastSyncError?: string | null };
}

function ShopRow({ shop }: { shop: Shop }): React.JSX.Element {
  const { orgId, refreshShops } = useOrg();
  const [expanded, setExpanded] = useState(false);
  const [detail, setDetail] = useState<ShopDetailResponse | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [disconnectOpen, setDisconnectOpen] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);
  const [rowError, setRowError] = useState<string | null>(null);

  const toggle = async () => {
    if (expanded) {
      setExpanded(false);
      return;
    }
    setExpanded(true);
    if (detail || detailLoading || !orgId) return;
    setDetailLoading(true);
    setDetailError(null);
    try {
      const d = await apiFetch<ShopDetailResponse>(
        `/api/orgs/${orgId}/shops/${shop.id}`
      );
      setDetail(d ?? null);
    } catch (e) {
      setDetailError(getErrorMessage(e));
    } finally {
      setDetailLoading(false);
    }
  };

  const disconnect = async () => {
    if (!orgId) return;
    setDisconnecting(true);
    setRowError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/shops/${shop.id}`, { method: "DELETE" });
      setDisconnectOpen(false);
      await refreshShops();
    } catch (e) {
      setRowError(getErrorMessage(e));
    } finally {
      setDisconnecting(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200">
      <div className="flex flex-wrap items-center gap-3 px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium text-slate-900">
            {shop.shopName ?? "Unnamed shop"}
          </p>
          <p className="text-sm text-slate-500">{shop.region ?? "Region unknown"}</p>
        </div>
        {modeBadge(shop)}
        {statusBadge(shop.status)}
        <Button variant="secondary" size="sm" onClick={toggle} ariaLabel={`Details for ${shop.shopName ?? "shop"}`}>
          {expanded ? "Hide details" : "Details"}
        </Button>
        <Can minRole="admin">
          <Button
            variant="danger"
            size="sm"
            onClick={() => setDisconnectOpen(true)}
            ariaLabel={`Disconnect ${shop.shopName ?? "shop"}`}
          >
            Disconnect
          </Button>
        </Can>
      </div>
      {rowError && (
        <div className="px-4 pb-3">
          <Alert tone="error" title="Couldn’t disconnect" onDismiss={() => setRowError(null)}>
            <p className="text-sm">{rowError}</p>
          </Alert>
        </div>
      )}
      {expanded && (
        <div className="space-y-3 border-t border-slate-100 px-4 py-3">
          {detailLoading && <SkeletonLines lines={3} />}
          {detailError && (
            <Alert tone="error" title="Couldn’t load shop details">
              <p className="text-sm">{detailError}</p>
            </Alert>
          )}
          {detail && (
            <>
              <div>
                <p className="mb-1.5 text-sm font-medium text-slate-700">Granted scopes</p>
                {Array.isArray(detail.scopes) && detail.scopes.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {detail.scopes.map((s) => (
                      <Badge key={s} tone="blue">
                        {s}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">No scopes granted</p>
                )}
              </div>
              {(() => {
                const unavailable = Object.entries(detail.capabilities ?? {})
                  .filter(([, info]) => info && info.available === false)
                  .map(([feature, info]) => ({
                    feature,
                    reason: info.reason ?? "Not available for the connected shop.",
                  }));
                return unavailable.length > 0 ? (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-slate-700">
                      Unavailable features
                    </p>
                    {unavailable.map((u) => (
                      <CapabilityNote key={u.feature} feature={u.feature} reason={u.reason} />
                    ))}
                  </div>
                ) : null;
              })()}
              <p className="text-xs text-slate-400">
                TikTok shop id:{" "}
                <span className="font-mono">{shop.tiktokShopId}</span>
              </p>
            </>
          )}
        </div>
      )}
      <ConfirmDialog
        open={disconnectOpen}
        title={`Disconnect ${shop.shopName ?? "this shop"}?`}
        body="Disconnecting removes stored credentials. Synced data stays in this workspace, but live data will stop updating until you reconnect."
        confirmLabel="Disconnect shop"
        cancelLabel="Cancel"
        danger
        loading={disconnecting}
        onConfirm={disconnect}
        onCancel={() => setDisconnectOpen(false)}
      />
    </div>
  );
}

function ShopsCard(): React.JSX.Element {
  const { orgId, orgSlug, shops, shopsLoading, refreshShops } = useOrg();
  const [connecting, setConnecting] = useState(false);
  const [connectNote, setConnectNote] = useState<string | null>(null);

  const connectShop = async () => {
    if (!orgId) return;
    setConnecting(true);
    setConnectNote(null);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/shops/connect`, {
        method: "POST",
      });
      const d = (data ?? {}) as Record<string, unknown>;
      // Demo mode: the API creates a demo shop immediately (201 { mode: "demo", shop }).
      if (d.mode === "demo") {
        await refreshShops();
        setConnectNote("Demo shop connected. All data shown for it is simulated.");
        return;
      }
      const url =
        typeof d.authorizationUrl === "string"
          ? d.authorizationUrl
          : typeof d.url === "string"
            ? d.url
            : null;
      if (url) {
        window.location.assign(url);
      } else {
        setConnectNote("Shop connection isn't configured — see Docs.");
      }
    } catch (e) {
      setConnectNote(getErrorMessage(e));
    } finally {
      setConnecting(false);
    }
  };

  return (
    <Card
      title="Connected shops"
      subtitle="TikTok Shops linked to this organization."
      actions={
        <Can minRole="admin">
          <Button variant="primary" size="sm" onClick={connectShop} loading={connecting}>
            Connect shop
          </Button>
        </Can>
      }
    >
      <div className="space-y-3">
        {connectNote && (
          <Alert
            tone="info"
            title="Connect a shop"
            onDismiss={() => setConnectNote(null)}
          >
            <p className="text-sm">
              {connectNote}{" "}
              <a href={`/${orgSlug}/docs#connecting`} className="font-medium text-indigo-600 hover:underline">
                See Docs
              </a>
            </p>
          </Alert>
        )}
        {shopsLoading && <SkeletonLines lines={3} />}
        {!shopsLoading && shops.length === 0 && (
          <p className="text-sm text-slate-500">
            No shops connected yet. Connect your TikTok Shop to start syncing data.
          </p>
        )}
        {shops.map((s) => (
          <ShopRow key={s.id} shop={s} />
        ))}
        {!shopsLoading && shops.length > 0 && (
          <Button variant="ghost" size="sm" onClick={() => refreshShops()}>
            <RefreshIcon className="h-4 w-4" /> Refresh shop list
          </Button>
        )}
      </div>
    </Card>
  );
}

/* ---------------- Sync ---------------- */

const SYNC_KINDS = [
  { kind: "product", label: "Products" },
  { kind: "campaign", label: "Campaigns" },
  { kind: "collab", label: "Creators" },
  { kind: "metrics", label: "Metrics" },
];

function SyncCard(): React.JSX.Element {
  const { orgId, shops } = useOrg();
  const [syncing, setSyncing] = useState<string | null>(null);
  const [note, setNote] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  const syncNow = async (shopId: string, kind: string) => {
    if (!orgId) return;
    setSyncing(`${shopId}:${kind}`);
    setNote(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/shops/${shopId}/sync`, {
        method: "POST",
        body: JSON.stringify({ kind }),
      });
      setNote({ tone: "success", text: "Sync started — results appear shortly." });
    } catch (e) {
      setNote({ tone: "error", text: getErrorMessage(e) });
    } finally {
      setSyncing(null);
    }
  };

  return (
    <Can minRole="campaign_manager" fallback={<PermissionDenied />}>
      <Card title="Sync" subtitle="Pull the latest data from TikTok for each shop.">
        <div className="space-y-4">
          {note && (
            <Alert tone={note.tone} title={note.tone === "success" ? "Sync" : "Sync failed"} onDismiss={() => setNote(null)}>
              <p className="text-sm">{note.text}</p>
            </Alert>
          )}
          {shops.length === 0 && (
            <p className="text-sm text-slate-500">No shops connected yet.</p>
          )}
          {shops.map((s) => (
            <div key={s.id} className="rounded-xl border border-slate-200 px-4 py-3">
              <div className="flex flex-wrap items-center gap-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-slate-900">
                    {s.shopName ?? "Unnamed shop"}
                  </p>
                  <p className="text-sm text-slate-500">
                    {s.lastSyncAt ? (
                      <>
                        Last sync {timeAgo(s.lastSyncAt)}
                        {s.lastSyncStatus && s.lastSyncStatus !== "success" && (
                          <> · <span className="font-medium text-amber-700">{s.lastSyncStatus}</span></>
                        )}
                        {s.lastSyncError && (
                          <span className="block text-xs text-red-600" title={s.lastSyncError}>
                            {truncate(s.lastSyncError, 120)}
                          </span>
                        )}
                      </>
                    ) : (
                      "Never synced"
                    )}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {SYNC_KINDS.map(({ kind, label }) => (
                    <Button
                      key={kind}
                      variant="secondary"
                      size="sm"
                      onClick={() => syncNow(s.id, kind)}
                      loading={syncing === `${s.id}:${kind}`}
                      disabled={syncing !== null}
                      ariaLabel={`Sync ${label} for ${s.shopName ?? "shop"}`}
                    >
                      Sync {label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </Can>
  );
}

/* ---------------- Notification preferences ---------------- */

const NOTIFICATION_TYPES: Array<{ type: string; label: string }> = [
  { type: "shop_auth_expired", label: "Shop authorization expired" },
  { type: "scope_missing", label: "Missing permissions (scopes)" },
  { type: "sync_completed", label: "Sync completed" },
  { type: "sync_failed", label: "Sync failed" },
  { type: "campaign_changed", label: "Campaign changed" },
  { type: "invite_status", label: "Invitation status updates" },
  { type: "campaign_ending", label: "Campaign ending soon" },
  { type: "export_ready", label: "Export ready" },
  { type: "team_invite_accepted", label: "Team invite accepted" },
  { type: "integration_attention", label: "Integration needs attention" },
];

function NotificationPrefsCard(): React.JSX.Element {
  const { orgId, orgSlug } = useOrg();
  const [prefs, setPrefs] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // The API saves one preference at a time: PUT { type, enabled }.
  const [savingType, setSavingType] = useState<string | null>(null);

  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    apiFetch<unknown>(`/api/orgs/${orgId}/notification-preferences`)
      .then((d) => {
        if (cancelled) return;
        const list = asArray<NotificationPref>(d);
        const map: Record<string, boolean> = {};
        for (const p of list) map[p.type] = p.enabled;
        const merged: Record<string, boolean> = {};
        for (const t of NOTIFICATION_TYPES) {
          merged[t.type] = map[t.type] ?? true;
        }
        setPrefs(merged);
        setLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setError(getErrorMessage(e));
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId]);

  const togglePref = async (type: string, enabled: boolean) => {
    if (!orgId) return;
    const previous = prefs[type] ?? true;
    setPrefs((p) => ({ ...p, [type]: enabled }));
    setSavingType(type);
    setError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/notification-preferences`, {
        method: "PUT",
        body: JSON.stringify({ type, enabled }),
      });
    } catch (e) {
      // Roll back on failure so the toggle reflects the saved state.
      setPrefs((p) => ({ ...p, [type]: previous }));
      setError(getErrorMessage(e));
    } finally {
      setSavingType(null);
    }
  };

  return (
    <Card
      title="Notification preferences"
      subtitle="Choose which events notify you."
      actions={
        <a
          href={`/${orgSlug}/notifications`}
          className="text-sm font-medium text-indigo-600 hover:underline"
        >
          View notifications
        </a>
      }
    >
      <div className="space-y-4">
        {error && (
          <Alert tone="error" title="Couldn’t load preferences" onDismiss={() => setError(null)}>
            <p className="text-sm">{error}</p>
          </Alert>
        )}
        {loading ? (
          <SkeletonLines lines={6} />
        ) : (
          <>
            <p className="text-sm text-slate-500">
              Changes save immediately.
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              {NOTIFICATION_TYPES.map((t) => (
                <label
                  key={t.type}
                  className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-slate-200 px-3 py-2.5 hover:bg-slate-50"
                >
                  <span className="text-sm text-slate-700">
                    {t.label}
                    {savingType === t.type && (
                      <span className="ml-2 text-xs text-slate-400">Saving…</span>
                    )}
                  </span>
                  <input
                    type="checkbox"
                    checked={prefs[t.type] ?? true}
                    onChange={(e) => togglePref(t.type, e.target.checked)}
                    disabled={savingType === t.type}
                    className="h-4 w-4 rounded border-slate-300 text-indigo-600"
                    aria-label={t.label}
                  />
                </label>
              ))}
            </div>
          </>
        )}
      </div>
    </Card>
  );
}

/* ---------------- Demo mode ---------------- */

function DemoCard(): React.JSX.Element {
  const { isDemo, orgSlug } = useOrg();
  return (
    <Card title="Demo mode" subtitle="How this workspace gets its data.">
      <div className="space-y-3">
        {isDemo ? (
          <Alert tone="warning" title="Demo mode is on">
            <p className="text-sm">
              Data is simulated. Connect a real shop to replace it.
            </p>
          </Alert>
        ) : (
          <Alert tone="info" title="Live mode">
            <p className="text-sm">
              This workspace is connected to a real TikTok Shop.
            </p>
          </Alert>
        )}
        <p className="text-sm text-slate-500">
          Demo data reset is documented in{" "}
          <a href={`/${orgSlug}/docs#demo-mode`} className="font-medium text-indigo-600 hover:underline">
            Help &amp; docs
          </a>
          .
        </p>
      </div>
    </Card>
  );
}

/* ---------------- Data & privacy ---------------- */

function DataPrivacyCard(): React.JSX.Element {
  const { orgSlug } = useOrg();
  return (
    <Card title="Data & privacy" subtitle="How your data is handled.">
      <div className="space-y-3 text-sm text-slate-600">
        <p>
          Exports you generate are yours to keep. If you need data deleted,
          contact support and we’ll take care of it.
        </p>
        <ul className="list-disc space-y-1 pl-5">
          <li>
            <a href={`/${orgSlug}/docs#privacy`} className="font-medium text-indigo-600 hover:underline">
              Privacy
            </a>
          </li>
          <li>
            <a href={`/${orgSlug}/docs#terms`} className="font-medium text-indigo-600 hover:underline">
              Terms
            </a>
          </li>
          <li>
            <a href={`/${orgSlug}/docs#support`} className="font-medium text-indigo-600 hover:underline">
              Support
            </a>
          </li>
        </ul>
      </div>
    </Card>
  );
}

/* ---------------- Audit log ---------------- */

function AuditLogCard(): React.JSX.Element {
  const { orgId } = useOrg();
  const [items, setItems] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    apiFetch<unknown>(`/api/orgs/${orgId}/audit-logs`)
      .then((d) => {
        if (cancelled) return;
        setItems(asArray<AuditLogItem>(d).slice(0, 50));
        setLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setError(getErrorMessage(e));
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId]);

  return (
    <Can minRole="admin" fallback={<PermissionDenied />}>
      <Card title="Audit log" subtitle="Recent actions in this organization (latest 50).">
        {loading ? (
          <SkeletonLines lines={6} />
        ) : error ? (
          <Alert tone="error" title="Couldn’t load the audit log">
            <p className="text-sm">{error}</p>
          </Alert>
        ) : items.length === 0 ? (
          <EmptyState
            icon={<GearIcon className="h-10 w-10" />}
            title="No audit events yet"
            body="Actions like sign-ins, team changes, and exports will appear here."
          />
        ) : (
          <Table
            ariaLabel="Audit log"
            rowKey={(a: AuditLogItem) => a.id}
            data={items}
            columns={[
              {
                key: "time",
                header: "Time",
                render: (a: AuditLogItem) => (
                  <span className="text-sm text-slate-600" title={formatDateTime(a.createdAt)}>
                    {timeAgo(a.createdAt)}
                  </span>
                ),
              },
              {
                key: "action",
                header: "Action",
                render: (a: AuditLogItem) => (
                  <span className="font-mono text-xs text-slate-800">{a.action}</span>
                ),
              },
              {
                key: "actor",
                header: "Actor",
                render: (a: AuditLogItem) => (
                  <span className="text-sm text-slate-700">
                    {a.actor?.name ?? a.actor?.email ?? "—"}
                  </span>
                ),
              },
              {
                key: "details",
                header: "Details",
                render: (a: AuditLogItem) => (
                  <span className="text-sm text-slate-500">{truncate(a.details, 80)}</span>
                ),
              },
            ]}
          />
        )}
      </Card>
    </Can>
  );
}

/* ---------------- Page ---------------- */

export default function SettingsPage(): React.JSX.Element {
  return (
    <div className={cx("space-y-6")}>
      <PageHeader title="Settings" subtitle="Workspace configuration." />
      <OrgProfileCard />
      <ShopsCard />
      <SyncCard />
      <NotificationPrefsCard />
      <DemoCard />
      <DataPrivacyCard />
      <AuditLogCard />
    </div>
  );
}
