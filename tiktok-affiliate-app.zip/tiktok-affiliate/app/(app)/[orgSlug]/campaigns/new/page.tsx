"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { useOrg } from "@/components/OrgContext";
import {
  apiFetch,
  getErrorMessage,
  getFieldErrors,
} from "@/lib/client";
import { cx, formatCurrency } from "@/lib/format";
import type { CapabilityInfo, Product } from "@/lib/types";
import { Button } from "@/components/Button";
import { PageHeader } from "@/components/PageHeader";
import { Can } from "@/components/RoleGate";
import { PermissionDenied } from "@/components/PermissionDenied";
import { Input } from "@/components/Input";
import { Select } from "@/components/Select";
import { Textarea } from "@/components/Textarea";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { Alert } from "@/components/Alert";
import { FieldError, FormErrors } from "@/components/FieldError";
import { CapabilityNote } from "@/components/CapabilityNote";
import { CheckIcon, SearchIcon, EmptyBoxIcon } from "@/components/icons";

const STEPS = ["Details", "Products", "Terms & dates", "Review"] as const;

const COMMISSION_TYPE_OPTIONS = [
  { value: "percent", label: "Percentage of sale" },
  { value: "flat", label: "Flat amount per order" },
];

const COLLABORATION_TYPE_OPTIONS = [
  { value: "open", label: "Open — any creator can request to join" },
  { value: "targeted", label: "Targeted — invite specific creators" },
];

/** Defensive extractor: API may return Paginated<Product> or a bare array. */
function extractProducts(data: unknown): Product[] {
  if (Array.isArray(data)) return data as Product[];
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.items)) return d.items as Product[];
  }
  return [];
}

/** Defensive extractor for a created campaign: data or { campaign }. */
function extractCampaignId(data: unknown): string | null {
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (typeof d.id === "string") return d.id;
    const nested = d.campaign as Record<string, unknown> | undefined;
    if (nested && typeof nested.id === "string") return nested.id;
  }
  return null;
}

/** "YYYY-MM-DDTHH:mm" (datetime-local) -> ISO string, or null. */
function toIsoOrNull(local: string): string | null {
  if (!local) return null;
  const d = new Date(local);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

function fieldMsg(
  fieldErrors: Record<string, string[]> | null,
  field: string
): string[] | undefined {
  const msgs = fieldErrors?.[field];
  return msgs && msgs.length > 0 ? msgs : undefined;
}

function NewCampaignWizard(): React.JSX.Element {
  const { orgId, orgSlug: ctxSlug, selectedShop } = useOrg();
  const params = useParams<{ orgSlug: string }>();
  const orgSlug = params.orgSlug ?? ctxSlug;
  const router = useRouter();
  const searchParams = useSearchParams();

  const preselectedIds = useMemo(() => {
    const raw = searchParams.get("products");
    if (!raw) return [];
    return raw
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  }, [searchParams]);

  const [step, setStep] = useState(0);

  // Step 1 — details
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  // Step 2 — products
  const [products, setProducts] = useState<Product[]>([]);
  const [productsLoading, setProductsLoading] = useState(false);
  const [productsError, setProductsError] = useState<string | null>(null);
  const [productsReloadKey, setProductsReloadKey] = useState(0);
  const [productSearch, setProductSearch] = useState("");
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(preselectedIds);

  // Step 3 — terms & dates
  const [commissionRate, setCommissionRate] = useState("");
  const [commissionType, setCommissionType] = useState("percent");
  const [startAt, setStartAt] = useState("");
  const [endAt, setEndAt] = useState("");
  const [collaborationType, setCollaborationType] = useState("targeted");
  const [sampleAvailable, setSampleAvailable] = useState(false);
  const [targetingNotes, setTargetingNotes] = useState("");

  // Capability gate for campaign creation.
  const [createCap, setCreateCap] = useState<CapabilityInfo | null>(null);

  // Submit state
  const [submitting, setSubmitting] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]> | null>(null);
  const [formErrors, setFormErrors] = useState<string[]>([]);
  const [clientError, setClientError] = useState<string | null>(null);

  // Fetch eligible products for the selected shop.
  useEffect(() => {
    if (!orgId || !selectedShop) return;
    let cancelled = false;
    setProductsLoading(true);
    setProductsError(null);
    apiFetch<unknown>(
      `/api/orgs/${orgId}/products?shopId=${encodeURIComponent(selectedShop.id)}&eligible=true&page=1&pageSize=100`
    )
      .then((data) => {
        if (cancelled) return;
        setProducts(extractProducts(data));
        setProductsLoading(false);
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setProductsError(getErrorMessage(e));
        setProductsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, selectedShop, productsReloadKey]);

  // Capability gate: fetch shop capabilities once per selected shop.
  // GET .../shops/[shopId]/capabilities → { capabilities: Record<key, {available, reason}>, mode, scopes }
  useEffect(() => {
    if (!orgId || !selectedShop) return;
    let cancelled = false;
    apiFetch<{ capabilities?: Record<string, CapabilityInfo> }>(
      `/api/orgs/${orgId}/shops/${selectedShop.id}/capabilities`
    )
      .then((data) => {
        if (cancelled) return;
        setCreateCap(data.capabilities?.["campaignCreate"] ?? null);
      })
      .catch(() => {
        // If the fetch fails, allow submit — the server enforces capabilities.
        if (!cancelled) setCreateCap(null);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, selectedShop]);

  const createUnavailable = createCap !== null && createCap.available === false;

  const toggleProduct = (id: string) => {
    setSelectedProductIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const filteredProducts = useMemo(() => {
    const q = productSearch.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) => (p.name ?? "").toLowerCase().includes(q));
  }, [products, productSearch]);

  const selectedProducts = useMemo(
    () => products.filter((p) => selectedProductIds.includes(p.id)),
    [products, selectedProductIds]
  );

  const validateStep = (s: number): string | null => {
    if (s === 0 && !name.trim()) return "Give your campaign a name to continue.";
    if (s === 1 && selectedProductIds.length === 0)
      return "Select at least one product for this campaign.";
    if (s === 2) {
      if (commissionRate !== "") {
        const n = Number(commissionRate);
        if (Number.isNaN(n) || n < 0 || n > 100)
          return "Commission rate must be a number between 0 and 100.";
      }
      if (startAt && endAt && new Date(startAt) >= new Date(endAt))
        return "The end date must be after the start date.";
    }
    return null;
  };

  const goNext = () => {
    const problem = validateStep(step);
    setClientError(problem);
    if (problem) return;
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const handleSubmit = async () => {
    setClientError(null);
    setFieldErrors(null);
    setFormErrors([]);
    for (let s = 0; s < 3; s++) {
      const problem = validateStep(s);
      if (problem) {
        setStep(s);
        setClientError(problem);
        return;
      }
    }
    if (!orgId || !selectedShop) {
      setClientError("No organization or shop is available. Please try again.");
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        name: name.trim(),
        description: description.trim() || null,
        productIds: selectedProductIds,
        commissionRate: commissionRate === "" ? null : Number(commissionRate),
        commissionType,
        startAt: toIsoOrNull(startAt),
        endAt: toIsoOrNull(endAt),
        collaborationType,
        sampleAvailable,
        targetingNotes: targetingNotes.trim() || null,
      };
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/campaigns`, {
        method: "POST",
        body: JSON.stringify(payload),
      });
      const newId = extractCampaignId(data);
      if (newId) {
        router.push(`/${orgSlug}/campaigns/${newId}`);
      } else {
        setFormErrors([
          "The campaign was created, but we couldn't determine its ID. Please check the campaigns list.",
        ]);
      }
    } catch (e: unknown) {
      const fe = getFieldErrors(e);
      if (fe) {
        setFieldErrors(fe);
      } else {
        setFormErrors([getErrorMessage(e)]);
      }
      // Inputs are preserved — nothing is cleared on failure.
    } finally {
      setSubmitting(false);
    }
  };

  const reviewRow = (label: string, value: React.ReactNode, editStep: number) => (
    <div className="flex items-start justify-between gap-4 border-b border-slate-100 py-3 last:border-0">
      <div>
        <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</dt>
        <dd className="mt-1 text-sm text-slate-900">{value}</dd>
      </div>
      <Button variant="ghost" size="sm" onClick={() => setStep(editStep)}>
        Edit
      </Button>
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="New campaign"
        subtitle="Create an affiliate campaign in four steps."
      />

      {createUnavailable && (
        <CapabilityNote
          feature="Campaign creation"
          reason={createCap?.reason}
        />
      )}

      {/* Step indicator */}
      <ol className="flex items-center gap-2" aria-label="Campaign creation steps">
        {STEPS.map((label, i) => {
          const done = i < step;
          const current = i === step;
          return (
            <li key={label} className="flex items-center gap-2" aria-current={current ? "step" : undefined}>
              <span
                className={cx(
                  "flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold",
                  done
                    ? "bg-emerald-600 text-white"
                    : current
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-200 text-slate-600"
                )}
                aria-hidden="true"
              >
                {done ? <CheckIcon className="h-4 w-4" /> : i + 1}
              </span>
              <span
                className={cx(
                  "text-sm",
                  current ? "font-semibold text-slate-900" : "text-slate-500"
                )}
              >
                {label}
              </span>
              {i < STEPS.length - 1 && (
                <span className="mx-2 h-px w-6 bg-slate-200" aria-hidden="true" />
              )}
            </li>
          );
        })}
      </ol>

      {clientError && (
        <Alert tone="error" title="Please fix the following" onDismiss={() => setClientError(null)}>
          {clientError}
        </Alert>
      )}
      {formErrors.length > 0 && (
        <Alert tone="error" title="Couldn't create campaign">
          <ul className="list-disc pl-5">
            {formErrors.map((m, i) => (
              <li key={i}>{m}</li>
            ))}
          </ul>
        </Alert>
      )}
      <FormErrors errors={fieldErrors} />

      {/* Step 1 — Details */}
      {step === 0 && (
        <Card title="Campaign details">
          <div className="space-y-4">
            <div>
              <Input
                label="Campaign name"
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Summer launch with fitness creators"
                required
              />
              {fieldMsg(fieldErrors, "name") && <FieldError error={fieldMsg(fieldErrors, "name")} />}
            </div>
            <div>
              <Textarea
                label="Description"
                name="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What is this campaign about? What should creators highlight?"
                rows={4}
              />
              {fieldMsg(fieldErrors, "description") && (
                <FieldError error={fieldMsg(fieldErrors, "description")} />
              )}
            </div>
          </div>
        </Card>
      )}

      {/* Step 2 — Products */}
      {step === 1 && (
        <Card
          title="Products"
          subtitle={
            selectedProductIds.length > 0
              ? `${selectedProductIds.length} product${selectedProductIds.length === 1 ? "" : "s"} selected`
              : "Select at least one product to promote."
          }
        >
          <div className="mb-4">
            <Input
              label="Filter products"
              name="productSearch"
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              placeholder="Search products…"
            />
          </div>
          {productsLoading ? (
            <SkeletonLines lines={5} />
          ) : productsError ? (
            <Alert tone="error" title="Couldn't load products">
              <div className="flex flex-col gap-2">
                <p>{productsError}</p>
                <div>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setProductsReloadKey((k) => k + 1)}
                  >
                    <SearchIcon className="h-4 w-4" aria-hidden="true" />
                    Retry
                  </Button>
                </div>
              </div>
            </Alert>
          ) : filteredProducts.length === 0 ? (
            <EmptyState
              icon={<EmptyBoxIcon className="h-10 w-10" aria-hidden="true" />}
              title="No eligible products"
              body="No affiliate-eligible products were found for the selected shop."
            />
          ) : (
            <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
              {filteredProducts.map((p) => {
                const checked = selectedProductIds.includes(p.id);
                return (
                  <li key={p.id}>
                    <label
                      className={cx(
                        "flex cursor-pointer items-center gap-3 px-4 py-3",
                        checked && "bg-indigo-50/60"
                      )}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleProduct(p.id)}
                        className="h-4 w-4 rounded border-slate-300 text-indigo-600"
                        aria-label={`Select ${p.name}`}
                      />
                      {p.imageUrl ? (
                        <img
                          src={p.imageUrl}
                          alt=""
                          className="h-10 w-10 rounded-lg object-cover"
                        />
                      ) : (
                        <span
                          className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100 text-xs font-semibold text-slate-500"
                          aria-hidden="true"
                        >
                          {(p.name ?? "?").slice(0, 2).toUpperCase()}
                        </span>
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium text-slate-900">
                          {p.name}
                        </span>
                        <span className="block text-xs text-slate-500">
                          {formatCurrency(p.price, p.currency)}
                        </span>
                      </span>
                      {p.affiliateEligible ? (
                        <Badge tone="green">Eligible</Badge>
                      ) : (
                        <span title={p.ineligibilityReason ?? undefined}>
                          <Badge tone="red">Not eligible</Badge>
                        </span>
                      )}
                    </label>
                  </li>
                );
              })}
            </ul>
          )}
          {fieldMsg(fieldErrors, "productIds") && (
            <div className="mt-2">
              <FieldError error={fieldMsg(fieldErrors, "productIds")} />
            </div>
          )}
        </Card>
      )}

      {/* Step 3 — Terms & dates */}
      {step === 2 && (
        <Card title="Terms & dates">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Input
                label="Commission rate"
                name="commissionRate"
                type="number"
                value={commissionRate}
                onChange={(e) => setCommissionRate(e.target.value)}
                placeholder="e.g. 10"
                hint="%"
              />
              {fieldMsg(fieldErrors, "commissionRate") && (
                <FieldError error={fieldMsg(fieldErrors, "commissionRate")} />
              )}
            </div>
            <div>
              <Select
                label="Commission type"
                name="commissionType"
                value={commissionType}
                onChange={(e) => setCommissionType(e.target.value)}
                options={COMMISSION_TYPE_OPTIONS}
              />
              {fieldMsg(fieldErrors, "commissionType") && (
                <FieldError error={fieldMsg(fieldErrors, "commissionType")} />
              )}
            </div>
            <div>
              <Input
                label="Start date"
                name="startAt"
                type="datetime-local"
                value={startAt}
                onChange={(e) => setStartAt(e.target.value)}
              />
            </div>
            <div>
              <Input
                label="End date"
                name="endAt"
                type="datetime-local"
                value={endAt}
                onChange={(e) => setEndAt(e.target.value)}
              />
            </div>
            <div>
              <Select
                label="Collaboration type"
                name="collaborationType"
                value={collaborationType}
                onChange={(e) => setCollaborationType(e.target.value)}
                options={COLLABORATION_TYPE_OPTIONS}
              />
            </div>
            <div className="flex items-center gap-2 pt-6">
              <input
                id="sampleAvailable"
                type="checkbox"
                checked={sampleAvailable}
                onChange={(e) => setSampleAvailable(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-indigo-600"
              />
              <label htmlFor="sampleAvailable" className="text-sm text-slate-700">
                Free samples available for creators
              </label>
            </div>
            <div className="sm:col-span-2">
              <Textarea
                label="Targeting notes"
                name="targetingNotes"
                value={targetingNotes}
                onChange={(e) => setTargetingNotes(e.target.value)}
                placeholder="Ideal creator profile, content style, posting requirements…"
                rows={4}
              />
            </div>
          </div>
        </Card>
      )}

      {/* Step 4 — Review */}
      {step === 3 && (
        <Card title="Review your campaign">
          <dl>
            {reviewRow("Name", name.trim() || "—", 0)}
            {reviewRow("Description", description.trim() || "—", 0)}
            {reviewRow(
              "Products",
              selectedProducts.length > 0 ? (
                <ul className="list-disc pl-5">
                  {selectedProducts.map((p) => (
                    <li key={p.id}>{p.name}</li>
                  ))}
                </ul>
              ) : (
                `${selectedProductIds.length} selected (details unavailable)`
              ),
              1
            )}
            {reviewRow(
              "Commission",
              commissionRate === ""
                ? "—"
                : `${commissionRate}% (${commissionType === "flat" ? "flat amount" : "percentage"})`,
              2
            )}
            {reviewRow(
              "Dates",
              `${startAt ? new Date(startAt).toLocaleString() : "No start"} → ${endAt ? new Date(endAt).toLocaleString() : "No end"}`,
              2
            )}
            {reviewRow(
              "Collaboration type",
              collaborationType === "open" ? "Open" : "Targeted",
              2
            )}
            {reviewRow("Samples available", sampleAvailable ? "Yes" : "No", 2)}
            {reviewRow("Targeting notes", targetingNotes.trim() || "—", 2)}
          </dl>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="secondary"
          onClick={() => setStep((s) => Math.max(s - 1, 0))}
          disabled={step === 0 || submitting}
        >
          Back
        </Button>
        {step < STEPS.length - 1 ? (
          <Button onClick={goNext} disabled={submitting}>
            Next
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            loading={submitting}
            disabled={submitting || createUnavailable}
            title={createUnavailable ? (createCap?.reason ?? "Campaign creation is unavailable") : undefined}
          >
            Create campaign
          </Button>
        )}
      </div>
    </div>
  );
}

export default function NewCampaignPage(): React.JSX.Element {
  return (
    <Can minRole="campaign_manager" fallback={<PermissionDenied />}>
      <Suspense fallback={<SkeletonLines lines={6} />}>
        <NewCampaignWizard />
      </Suspense>
    </Can>
  );
}
