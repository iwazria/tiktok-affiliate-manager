"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { useOrg } from "@/components/OrgContext";
import {
  apiFetch,
  getErrorMessage,
  getFieldErrors,
} from "@/lib/client";
import { cx, formatCurrency, formatDateTime, timeAgo } from "@/lib/format";
import type {
  AuditLogItem,
  Campaign,
  Collaboration,
  Creator,
} from "@/lib/types";
import { Button } from "@/components/Button";
import { PageHeader } from "@/components/PageHeader";
import { Can } from "@/components/RoleGate";
import { Input } from "@/components/Input";
import { Select } from "@/components/Select";
import { Textarea } from "@/components/Textarea";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { Alert } from "@/components/Alert";
import { Modal } from "@/components/Modal";
import { FieldError } from "@/components/FieldError";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Table } from "@/components/Table";
import { CapabilityNote } from "@/components/CapabilityNote";
import { DataSourceLabel } from "@/components/DataSourceLabel";
import { EmptyBoxIcon, PlusIcon, UsersIcon } from "@/components/icons";

const STATUS_TONE: Record<string, "green" | "yellow" | "red" | "blue" | "gray" | "purple"> = {
  draft: "gray",
  scheduled: "blue",
  active: "green",
  paused: "yellow",
  ended: "gray",
  archived: "gray",
};

const COLLAB_STATUS_TONE: Record<string, "green" | "yellow" | "red" | "blue" | "gray" | "purple"> = {
  draft: "gray",
  sent: "blue",
  accepted: "green",
  declined: "red",
  expired: "yellow",
  completed: "green",
  cancelled: "gray",
};

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "products", label: "Products" },
  { key: "creators", label: "Creators" },
  { key: "activity", label: "Activity" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

interface LifecycleAction {
  key: "pause" | "resume" | "end" | "archive";
  label: string;
  feature: string;
  danger: boolean;
  confirmBody: string;
}

const LIFECYCLE_ACTIONS: LifecycleAction[] = [
  {
    key: "pause",
    label: "Pause",
    feature: "campaignPause",
    danger: false,
    confirmBody: "Pause this campaign? While paused, creators won't be able to promote it.",
  },
  {
    key: "resume",
    label: "Resume",
    feature: "campaignResume",
    danger: false,
    confirmBody: "Resume this campaign? Creators will be able to promote it again.",
  },
  {
    key: "end",
    label: "End",
    feature: "campaignEnd",
    danger: true,
    confirmBody:
      "End this campaign? This is externally visible: creators will no longer be able to promote your products through this campaign.",
  },
  {
    key: "archive",
    label: "Archive",
    feature: "campaignArchive",
    danger: true,
    confirmBody:
      "Archive this campaign? It will be removed from the active list. This is externally visible to creators.",
  },
];

function pretty(s: string | null | undefined): string {
  if (!s) return "—";
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Defensive extractor: API may return the campaign directly or wrapped. */
function extractCampaign(data: unknown): Campaign | null {
  if (!data || typeof data !== "object") return null;
  const d = data as Record<string, unknown>;
  if (typeof d.id === "string") return d as unknown as Campaign;
  if (d.campaign && typeof d.campaign === "object") return d.campaign as Campaign;
  return null;
}

function extractArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.items)) return d.items as T[];
  }
  return [];
}

function creatorLabel(c: Creator): string {
  return c.displayName || c.handle || "Unknown creator";
}

export default function CampaignDetailPage(): React.JSX.Element {
  const { orgId, selectedShop, isDemo } = useOrg();
  const { orgSlug, id } = useParams<{ orgSlug: string; id: string }>();
  const campaignId = id;

  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const [tab, setTab] = useState<TabKey>("overview");

  // Capabilities for lifecycle actions.
  const [features, setFeatures] = useState<Record<string, { available: boolean; reason?: string }> | null>(null);

  // Edit modal.
  const [editOpen, setEditOpen] = useState(false);
  const [editName, setEditName] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editSaving, setEditSaving] = useState(false);
  const [editFieldErrors, setEditFieldErrors] = useState<Record<string, string[]> | null>(null);

  // Lifecycle confirm dialog.
  const [confirmAction, setConfirmAction] = useState<LifecycleAction | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  // Creators tab.
  const [collaborations, setCollaborations] = useState<Collaboration[]>([]);
  const [collabsLoading, setCollabsLoading] = useState(false);
  const [collabsError, setCollabsError] = useState<string | null>(null);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [creators, setCreators] = useState<Creator[]>([]);
  const [creatorsLoading, setCreatorsLoading] = useState(false);
  const [inviteCreatorId, setInviteCreatorId] = useState("");
  const [inviteSaving, setInviteSaving] = useState(false);
  const [inviteError, setInviteError] = useState<string | null>(null);
  const [cancelCollab, setCancelCollab] = useState<Collaboration | null>(null);
  const [collabActionLoading, setCollabActionLoading] = useState<string | null>(null);

  // Activity tab.
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);
  const [logsError, setLogsError] = useState<string | null>(null);

  const loadCampaign = useCallback(async () => {
    if (!orgId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/campaigns/${campaignId}`);
      const c = extractCampaign(data);
      if (!c) throw new Error("Campaign not found.");
      setCampaign(c);
    } catch (e: unknown) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, [orgId, campaignId]);

  useEffect(() => {
    loadCampaign();
  }, [loadCampaign]);

  // Capabilities (per selected shop; failure is non-fatal).
  // GET .../shops/[shopId]/capabilities → { capabilities: Record<key, {available, reason}>, mode, scopes }
  useEffect(() => {
    if (!orgId || !selectedShop) return;
    let cancelled = false;
    apiFetch<{ capabilities?: Record<string, { available: boolean; reason?: string }> }>(
      `/api/orgs/${orgId}/shops/${selectedShop.id}/capabilities`
    )
      .then((data) => {
        if (!cancelled) setFeatures(data.capabilities ?? null);
      })
      .catch(() => {
        if (!cancelled) setFeatures(null);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, selectedShop]);

  const loadCollaborations = useCallback(async () => {
    if (!orgId) return;
    setCollabsLoading(true);
    setCollabsError(null);
    try {
      const data = await apiFetch<unknown>(
        `/api/orgs/${orgId}/campaigns/${campaignId}/collaborations`
      );
      setCollaborations(extractArray<Collaboration>(data));
    } catch (e: unknown) {
      setCollabsError(getErrorMessage(e));
    } finally {
      setCollabsLoading(false);
    }
  }, [orgId, campaignId]);

  useEffect(() => {
    if (tab === "creators") loadCollaborations();
  }, [tab, loadCollaborations]);

  const loadLogs = useCallback(async () => {
    if (!orgId) return;
    setLogsLoading(true);
    setLogsError(null);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/audit-logs`);
      const all = extractArray<AuditLogItem>(data);
      const filtered = all
        .filter(
          (l) =>
            l.entityId === campaignId ||
            (typeof l.action === "string" && l.action.includes(campaignId))
        )
        .slice(0, 20);
      setLogs(filtered);
    } catch (e: unknown) {
      setLogsError(getErrorMessage(e));
    } finally {
      setLogsLoading(false);
    }
  }, [orgId, campaignId]);

  useEffect(() => {
    if (tab === "activity") loadLogs();
  }, [tab, loadLogs]);

  const openEdit = () => {
    if (!campaign) return;
    setEditName(campaign.name ?? "");
    setEditDescription(campaign.description ?? "");
    setEditFieldErrors(null);
    setEditOpen(true);
  };

  const saveEdit = async () => {
    if (!orgId) return;
    setEditSaving(true);
    setEditFieldErrors(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/campaigns/${campaignId}`, {
        method: "PATCH",
        body: JSON.stringify({ name: editName.trim(), description: editDescription.trim() || null }),
      });
      setEditOpen(false);
      loadCampaign();
    } catch (e: unknown) {
      const fe = getFieldErrors(e);
      if (fe) setEditFieldErrors(fe);
      else setActionError(getErrorMessage(e));
      // Input is preserved on failure.
    } finally {
      setEditSaving(false);
    }
  };

  const runLifecycleAction = async () => {
    if (!orgId || !confirmAction) return;
    setActionLoading(true);
    setActionError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/campaigns/${campaignId}/${confirmAction.key}`, {
        method: "POST",
        body: JSON.stringify({ confirm: true }),
      });
      setConfirmAction(null);
      loadCampaign();
    } catch (e: unknown) {
      setActionError(getErrorMessage(e));
      setConfirmAction(null);
    } finally {
      setActionLoading(false);
    }
  };

  const openInvite = async () => {
    setInviteOpen(true);
    setInviteError(null);
    setInviteCreatorId("");
    if (!orgId) return;
    setCreatorsLoading(true);
    try {
      const data = await apiFetch<unknown>(`/api/orgs/${orgId}/creators?page=1&pageSize=100`);
      setCreators(extractArray<Creator>(data));
    } catch {
      setCreators([]);
    } finally {
      setCreatorsLoading(false);
    }
  };

  const submitInvite = async () => {
    if (!orgId || !inviteCreatorId) return;
    setInviteSaving(true);
    setInviteError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/campaigns/${campaignId}/collaborations`, {
        method: "POST",
        body: JSON.stringify({ creatorId: inviteCreatorId }),
      });
      setInviteOpen(false);
      loadCollaborations();
    } catch (e: unknown) {
      setInviteError(getErrorMessage(e));
    } finally {
      setInviteSaving(false);
    }
  };

  const resendInvite = async (collab: Collaboration) => {
    if (!orgId) return;
    setCollabActionLoading(collab.id);
    setActionError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/collaborations/${collab.id}/resend`, { method: "POST" });
      loadCollaborations();
    } catch (e: unknown) {
      setActionError(getErrorMessage(e));
    } finally {
      setCollabActionLoading(null);
    }
  };

  const cancelInvite = async () => {
    if (!orgId || !cancelCollab) return;
    setCollabActionLoading(cancelCollab.id);
    setActionError(null);
    try {
      await apiFetch(`/api/orgs/${orgId}/collaborations/${cancelCollab.id}/cancel`, {
        method: "POST",
        body: JSON.stringify({ confirm: true }),
      });
      setCancelCollab(null);
      loadCollaborations();
    } catch (e: unknown) {
      setActionError(getErrorMessage(e));
      setCancelCollab(null);
    } finally {
      setCollabActionLoading(null);
    }
  };

  const visibleActions = LIFECYCLE_ACTIONS.filter((a) => {
    const s = campaign?.status;
    if (a.key === "pause") return s === "active" || s === "scheduled";
    if (a.key === "resume") return s === "paused";
    if (a.key === "end") return ["active", "paused", "scheduled", "draft"].includes(s ?? "");
    if (a.key === "archive") return s === "ended" || s === "draft";
    return false;
  });

  const unavailableActions = visibleActions.filter((a) => {
    const f = features?.[a.feature];
    return f !== undefined && f !== null && f.available === false;
  });

  const collabColumns = [
    {
      key: "creator",
      header: "Creator",
      render: (c: Collaboration) => {
        const creator = c.creator;
        const label = creatorLabel(creator ?? ({} as Creator));
        return (
          <div className="flex items-center gap-3">
            {creator?.avatarUrl ? (
              <img
                src={creator.avatarUrl}
                alt=""
                className="h-9 w-9 rounded-full object-cover"
              />
            ) : (
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700"
                aria-hidden="true"
              >
                {label.slice(0, 2).toUpperCase()}
              </span>
            )}
            <div className="flex flex-col">
              <span className="font-medium text-slate-900">{label}</span>
              {creator?.handle && (
                <span className="text-xs text-slate-500">@{creator.handle}</span>
              )}
            </div>
          </div>
        );
      },
    },
    {
      key: "status",
      header: "Status",
      render: (c: Collaboration) => (
        <span title={c.lastError ?? undefined}>
          <Badge tone={COLLAB_STATUS_TONE[c.status] ?? "gray"}>{pretty(c.status)}</Badge>
        </span>
      ),
    },
    {
      key: "invited",
      header: "Invited",
      render: (c: Collaboration) => timeAgo(c.invitedAt),
    },
    {
      key: "actions",
      header: "",
      className: "text-right",
      render: (c: Collaboration) => (
        <Can minRole="campaign_manager">
          <div className="flex justify-end gap-2">
            <Button
              variant="ghost"
              size="sm"
              loading={collabActionLoading === c.id}
              disabled={collabActionLoading === c.id}
              onClick={() => resendInvite(c)}
            >
              Resend
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setCancelCollab(c)}>
              Cancel
            </Button>
          </div>
        </Can>
      ),
    },
  ];

  const memberCount = campaign?.products?.length ?? 0;

  return (
    <div className="space-y-6">
      <div>
        <Link
          href={`/${orgSlug}/campaigns`}
          className="text-sm text-indigo-600 hover:underline"
        >
          ← Back to campaigns
        </Link>
      </div>

      {loading ? (
        <SkeletonLines lines={8} />
      ) : error ? (
        <Alert tone="error" title="Couldn't load campaign" onDismiss={() => setError(null)}>
          <div className="flex flex-col gap-2">
            <p>{error}</p>
            <div>
              <Button variant="secondary" size="sm" onClick={loadCampaign}>
                Retry
              </Button>
            </div>
          </div>
        </Alert>
      ) : campaign ? (
        <>
          <PageHeader
            title={campaign.name}
            actions={
              <Can minRole="campaign_manager">
                <div className="flex flex-wrap gap-2">
                  <Button variant="secondary" size="sm" onClick={openEdit}>
                    Edit
                  </Button>
                  {visibleActions.map((a) => {
                    const f = features?.[a.feature];
                    const unavailable = f !== undefined && f !== null && f.available === false;
                    return (
                      <Button
                        key={a.key}
                        variant={a.danger ? "danger" : "secondary"}
                        size="sm"
                        disabled={unavailable}
                        title={unavailable ? (f?.reason ?? `${a.label} is unavailable`) : undefined}
                        onClick={() => setConfirmAction(a)}
                      >
                        {a.label}
                      </Button>
                    );
                  })}
                </div>
              </Can>
            }
          />

          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={STATUS_TONE[campaign.status] ?? "gray"}>{pretty(campaign.status)}</Badge>
            {campaign.tiktokCampaignId ? (
              <Badge tone="green">TikTok synced</Badge>
            ) : (
              <Badge tone="gray">Local draft</Badge>
            )}
            {(campaign.isDemo ?? isDemo) && <Badge tone="yellow">Demo</Badge>}
            <DataSourceLabel
              source={campaign.isDemo ?? isDemo ? "demo" : "live"}
              syncedAt={campaign.lastSyncedAt}
            />
          </div>

          {actionError && (
            <Alert tone="error" title="Action failed" onDismiss={() => setActionError(null)}>
              {actionError}
            </Alert>
          )}

          {unavailableActions.length > 0 && (
            <Alert tone="warning" title="Actions availability">
              <ul className="list-disc pl-5">
                {unavailableActions.map((a) => (
                  <li key={a.key}>
                    {a.label}: {features?.[a.feature]?.reason ?? "Not available for this shop."}
                  </li>
                ))}
              </ul>
              <div className="mt-2">
                {unavailableActions.map((a) => (
                  <div key={a.key}>
                    <CapabilityNote feature={`Campaign ${a.label.toLowerCase()}`} reason={features?.[a.feature]?.reason} />
                  </div>
                ))}
              </div>
            </Alert>
          )}

          <div role="tablist" aria-label="Campaign sections" className="flex gap-1 border-b border-slate-200">
            {TABS.map((t) => (
              <button
                key={t.key}
                role="tab"
                aria-selected={tab === t.key}
                onClick={() => setTab(t.key)}
                className={cx(
                  "px-4 py-2 text-sm font-medium",
                  tab === t.key
                    ? "border-b-2 border-indigo-600 text-indigo-700"
                    : "text-slate-500 hover:text-slate-800"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          {tab === "overview" && (
            <Card title="Overview">
              <dl className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Description</dt>
                  <dd className="mt-1 text-sm text-slate-900">{campaign.description || "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Commission</dt>
                  <dd className="mt-1 text-sm text-slate-900">
                    {campaign.commissionRate != null
                      ? `${campaign.commissionRate}${campaign.commissionType === "flat" ? " (flat)" : "%"}`
                      : "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Collaboration type</dt>
                  <dd className="mt-1 text-sm text-slate-900">{pretty(campaign.collaborationType)}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Start</dt>
                  <dd className="mt-1 text-sm text-slate-900">{formatDateTime(campaign.startAt)}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">End</dt>
                  <dd className="mt-1 text-sm text-slate-900">{formatDateTime(campaign.endAt)}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Samples available</dt>
                  <dd className="mt-1 text-sm text-slate-900">{campaign.sampleAvailable ? "Yes" : "No"}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">TikTok campaign</dt>
                  <dd className="mt-1 text-sm text-slate-900">
                    {campaign.tiktokCampaignId ?? "Local draft — not yet created on TikTok Shop"}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Created</dt>
                  <dd className="mt-1 text-sm text-slate-900">{formatDateTime(campaign.createdAt)}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Last updated</dt>
                  <dd className="mt-1 text-sm text-slate-900">{formatDateTime(campaign.updatedAt)}</dd>
                </div>
                <div>
                  <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Sync status</dt>
                  <dd className="mt-1 text-sm text-slate-900">
                    {campaign.lastSyncedAt ? `Synced ${timeAgo(campaign.lastSyncedAt)}` : "Never synced"}
                  </dd>
                </div>
                {campaign.targetingNotes && (
                  <div className="sm:col-span-2">
                    <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">Targeting notes</dt>
                    <dd className="mt-1 text-sm text-slate-900">{campaign.targetingNotes}</dd>
                  </div>
                )}
              </dl>
            </Card>
          )}

          {tab === "products" && (
            <Card title={`Products (${memberCount})`}>
              {!campaign.products || campaign.products.length === 0 ? (
                <EmptyState
                  icon={<EmptyBoxIcon className="h-10 w-10" aria-hidden="true" />}
                  title="No products in this campaign"
                  body="Products added to this campaign will appear here."
                />
              ) : (
                <Table
                  ariaLabel="Campaign products"
                  rowKey={(p) => p.id}
                  data={campaign.products}
                  columns={[
                    {
                      key: "name",
                      header: "Product",
                      render: (p) => (
                        <div className="flex items-center gap-3">
                          {p.imageUrl ? (
                            <img src={p.imageUrl} alt="" className="h-9 w-9 rounded-lg object-cover" />
                          ) : (
                            <span
                              className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-xs font-semibold text-slate-500"
                              aria-hidden="true"
                            >
                              {(p.name ?? "?").slice(0, 2).toUpperCase()}
                            </span>
                          )}
                          <span className="font-medium text-slate-900">{p.name}</span>
                        </div>
                      ),
                    },
                    {
                      key: "price",
                      header: "Price",
                      render: (p) => formatCurrency(p.price, p.currency),
                    },
                    {
                      key: "eligibility",
                      header: "Eligibility",
                      render: (p) =>
                        p.affiliateEligible ? (
                          <Badge tone="green">Eligible</Badge>
                        ) : (
                          <span title={p.ineligibilityReason ?? undefined}>
                            <Badge tone="red">Not eligible</Badge>
                          </span>
                        ),
                    },
                  ]}
                />
              )}
            </Card>
          )}

          {tab === "creators" && (
            <Card
              title="Creators"
              subtitle="Creators invited to collaborate on this campaign."
              actions={
                <Can minRole="campaign_manager">
                  <Button size="sm" onClick={openInvite}>
                    <PlusIcon className="h-4 w-4" aria-hidden="true" />
                    Invite creator
                  </Button>
                </Can>
              }
            >
              {collabsLoading ? (
                <SkeletonLines lines={4} />
              ) : collabsError ? (
                <Alert tone="error" title="Couldn't load collaborations">
                  <div className="flex flex-col gap-2">
                    <p>{collabsError}</p>
                    <div>
                      <Button variant="secondary" size="sm" onClick={loadCollaborations}>
                        Retry
                      </Button>
                    </div>
                  </div>
                </Alert>
              ) : collaborations.length === 0 ? (
                <EmptyState
                  icon={<UsersIcon className="h-10 w-10" aria-hidden="true" />}
                  title="No creators invited yet"
                  body="Invite creators to start collaborating on this campaign."
                  action={
                    <Can minRole="campaign_manager">
                      <Button size="sm" onClick={openInvite}>
                        <PlusIcon className="h-4 w-4" aria-hidden="true" />
                        Invite creator
                      </Button>
                    </Can>
                  }
                />
              ) : (
                <Table
                  ariaLabel="Campaign collaborations"
                  rowKey={(c) => c.id}
                  data={collaborations}
                  columns={collabColumns}
                />
              )}
            </Card>
          )}

          {tab === "activity" && (
            <Card title="Activity">
              {logsLoading ? (
                <SkeletonLines lines={5} />
              ) : logsError ? (
                <Alert tone="error" title="Couldn't load activity">
                  <div className="flex flex-col gap-2">
                    <p>{logsError}</p>
                    <div>
                      <Button variant="secondary" size="sm" onClick={loadLogs}>
                        Retry
                      </Button>
                    </div>
                  </div>
                </Alert>
              ) : logs.length === 0 ? (
                <EmptyState
                  icon={<EmptyBoxIcon className="h-10 w-10" aria-hidden="true" />}
                  title="No activity yet"
                  body="Changes to this campaign will appear here."
                />
              ) : (
                <ul className="divide-y divide-slate-100">
                  {logs.map((l) => (
                    <li key={l.id} className="flex items-start justify-between gap-4 py-3">
                      <div>
                        <p className="text-sm font-medium text-slate-900">{l.action}</p>
                        {l.details && <p className="text-xs text-slate-500">{l.details}</p>}
                        {l.actor && (
                          <p className="text-xs text-slate-500">
                            {l.actor.name || l.actor.email || "System"}
                          </p>
                        )}
                      </div>
                      <span className="shrink-0 text-xs text-slate-400">{timeAgo(l.createdAt)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          )}
        </>
      ) : null}

      {/* Edit modal */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit campaign"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditOpen(false)} disabled={editSaving}>
              Cancel
            </Button>
            <Button onClick={saveEdit} loading={editSaving} disabled={editSaving}>
              Save changes
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <Input
              label="Campaign name"
              name="editName"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              required
            />
            {editFieldErrors?.name && <FieldError error={editFieldErrors.name} />}
          </div>
          <div>
            <Textarea
              label="Description"
              name="editDescription"
              value={editDescription}
              onChange={(e) => setEditDescription(e.target.value)}
              rows={4}
            />
            {editFieldErrors?.description && <FieldError error={editFieldErrors.description} />}
          </div>
        </div>
      </Modal>

      {/* Lifecycle confirm dialog */}
      <ConfirmDialog
        open={confirmAction !== null}
        title={confirmAction ? `${confirmAction.label} campaign` : ""}
        body={confirmAction?.confirmBody ?? ""}
        confirmLabel={confirmAction?.label ?? "Confirm"}
        cancelLabel="Cancel"
        danger={confirmAction?.danger ?? false}
        loading={actionLoading}
        onConfirm={runLifecycleAction}
        onCancel={() => setConfirmAction(null)}
      />

      {/* Invite creator modal */}
      <Modal
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        title="Invite creator"
        footer={
          <>
            <Button variant="secondary" onClick={() => setInviteOpen(false)} disabled={inviteSaving}>
              Cancel
            </Button>
            <Button
              onClick={submitInvite}
              loading={inviteSaving}
              disabled={inviteSaving || !inviteCreatorId}
            >
              Send invitation
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {inviteError && (
            <Alert tone="error" title="Couldn't send invitation" onDismiss={() => setInviteError(null)}>
              {inviteError}
            </Alert>
          )}
          <Select
            label="Creator"
            name="inviteCreator"
            value={inviteCreatorId}
            onChange={(e) => setInviteCreatorId(e.target.value)}
            disabled={creatorsLoading}
            required
            options={[
              { value: "", label: creatorsLoading ? "Loading creators…" : "Select a creator" },
              ...creators.map((c) => ({
                value: c.id,
                label: `${creatorLabel(c)}${c.handle ? ` (@${c.handle})` : ""}`,
              })),
            ]}
          />
        </div>
      </Modal>

      {/* Cancel collaboration confirm dialog */}
      <ConfirmDialog
        open={cancelCollab !== null}
        title="Cancel invitation"
        body={
          cancelCollab
            ? `Cancel the invitation to ${creatorLabel(cancelCollab.creator ?? ({} as Creator))}? The creator will no longer see this invitation.`
            : ""
        }
        confirmLabel="Cancel invitation"
        cancelLabel="Keep"
        danger
        loading={collabActionLoading === cancelCollab?.id}
        onConfirm={cancelInvite}
        onCancel={() => setCancelCollab(null)}
      />
    </div>
  );
}
