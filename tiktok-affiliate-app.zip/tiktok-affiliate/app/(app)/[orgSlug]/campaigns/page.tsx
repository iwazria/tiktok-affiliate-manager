"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useOrg } from "@/components/OrgContext";
import { apiFetch, getErrorMessage } from "@/lib/client";
import { timeAgo } from "@/lib/format";
import type { Campaign } from "@/lib/types";
import { Button } from "@/components/Button";
import { PageHeader } from "@/components/PageHeader";
import { Can } from "@/components/RoleGate";
import { Input } from "@/components/Input";
import { Select } from "@/components/Select";
import { Table } from "@/components/Table";
import { Badge } from "@/components/Badge";
import { EmptyState } from "@/components/EmptyState";
import { SkeletonLines } from "@/components/Skeleton";
import { Alert } from "@/components/Alert";
import { Pagination } from "@/components/Pagination";
import { PlusIcon, EmptyBoxIcon } from "@/components/icons";

const PAGE_SIZE = 10;

const STATUS_TONE: Record<string, "green" | "yellow" | "red" | "blue" | "gray" | "purple"> = {
  draft: "gray",
  scheduled: "blue",
  active: "green",
  paused: "yellow",
  ended: "gray",
  archived: "gray",
};

const STATUS_OPTIONS = [
  { value: "all", label: "All statuses" },
  { value: "draft", label: "Draft" },
  { value: "scheduled", label: "Scheduled" },
  { value: "active", label: "Active" },
  { value: "paused", label: "Paused" },
  { value: "ended", label: "Ended" },
  { value: "archived", label: "Archived" },
];

const SORT_OPTIONS = [
  { value: "updated-desc", label: "Recently updated" },
  { value: "name", label: "Name" },
  { value: "start-desc", label: "Start date" },
];

interface CampaignListResult {
  items: Campaign[];
  page: number;
  totalPages: number;
  total: number;
}

/** Defensive extractor: API may return Paginated<Campaign> or a bare array. */
function extractResult(data: unknown): CampaignListResult {
  if (Array.isArray(data)) {
    return { items: data as Campaign[], page: 1, totalPages: 1, total: data.length };
  }
  if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    const items = Array.isArray(d.items) ? (d.items as Campaign[]) : [];
    return {
      items,
      page: typeof d.page === "number" ? d.page : 1,
      totalPages: typeof d.totalPages === "number" ? d.totalPages : 1,
      total: typeof d.total === "number" ? d.total : items.length,
    };
  }
  return { items: [], page: 1, totalPages: 1, total: 0 };
}

function prettyStatus(status: string | null | undefined): string {
  if (!status) return "—";
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export default function CampaignsPage(): React.JSX.Element {
  const { orgId, orgSlug: ctxSlug, isDemo } = useOrg();
  const params = useParams<{ orgSlug: string }>();
  const orgSlug = params.orgSlug ?? ctxSlug;

  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("updated-desc");
  const [page, setPage] = useState(1);

  const [result, setResult] = useState<CampaignListResult>({ items: [], page: 1, totalPages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  // Debounce search input (400ms).
  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(searchInput.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [searchInput]);

  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    const qs = new URLSearchParams({
      page: String(page),
      pageSize: String(PAGE_SIZE),
      sort,
    });
    if (search) qs.set("search", search);
    if (status !== "all") qs.set("status", status);
    apiFetch<unknown>(`/api/orgs/${orgId}/campaigns?${qs.toString()}`)
      .then((data) => {
        if (cancelled) return;
        setResult(extractResult(data));
        setLoading(false);
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(getErrorMessage(e));
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [orgId, search, status, sort, page, reloadKey]);

  const columns = [
    {
      key: "campaign",
      header: "Campaign",
      render: (c: Campaign) => (
        <div className="flex flex-col gap-1">
          <Link
            href={`/${orgSlug}/campaigns/${c.id}`}
            className="font-medium text-indigo-600 hover:underline"
          >
            {c.name}
          </Link>
          <div className="flex flex-wrap gap-1">
            {!c.tiktokCampaignId && <Badge tone="gray">Local draft</Badge>}
            {(c.isDemo ?? isDemo) && <Badge tone="yellow">Demo</Badge>}
          </div>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (c: Campaign) => (
        <Badge tone={STATUS_TONE[c.status] ?? "gray"}>{prettyStatus(c.status)}</Badge>
      ),
    },
    {
      key: "products",
      header: "Products",
      render: (c: Campaign) =>
        c.productCount ?? (c.products != null ? String(c.products.length) : "—"),
    },
    {
      key: "creators",
      header: "Creators",
      render: (c: Campaign) => {
        // API list shape: collaborationCounts: Record<status, count>
        if (c.collaborationCounts) {
          const entries = Object.entries(c.collaborationCounts);
          const invited = entries.reduce((n, [, v]) => n + (v ?? 0), 0);
          const accepted = c.collaborationCounts["accepted"] ?? 0;
          return `${accepted} / ${invited}`;
        }
        return c.counts != null
          ? `${c.counts.accepted ?? 0} / ${c.counts.invited ?? 0}`
          : "—";
      },
    },
    {
      key: "updated",
      header: "Updated",
      render: (c: Campaign) => timeAgo(c.updatedAt),
    },
    {
      key: "actions",
      header: "",
      className: "text-right",
      render: (c: Campaign) => (
        <Button variant="ghost" size="sm" href={`/${orgSlug}/campaigns/${c.id}`}>
          View
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Campaigns"
        subtitle="Plan, launch, and track affiliate campaigns for your shop."
        actions={
          <Can minRole="campaign_manager">
            <Button href={`/${orgSlug}/campaigns/new`}>
              <PlusIcon className="h-4 w-4" aria-hidden="true" />
              New campaign
            </Button>
          </Can>
        }
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <div className="flex-1">
          <Input
            label="Search campaigns"
            name="search"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search by name…"
          />
        </div>
        <div className="w-full sm:w-48">
          <Select
            label="Status"
            name="status"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
            options={STATUS_OPTIONS}
          />
        </div>
        <div className="w-full sm:w-48">
          <Select
            label="Sort by"
            name="sort"
            value={sort}
            onChange={(e) => {
              setSort(e.target.value);
              setPage(1);
            }}
            options={SORT_OPTIONS}
          />
        </div>
      </div>

      {error && (
        <Alert
          tone="error"
          title="Couldn't load campaigns"
          onDismiss={() => setError(null)}
        >
          <div className="flex flex-col gap-2">
            <p>{error}</p>
            <div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setReloadKey((k) => k + 1)}
              >
                Retry
              </Button>
            </div>
          </div>
        </Alert>
      )}

      {loading ? (
        <SkeletonLines lines={6} />
      ) : result.items.length === 0 ? (
        <EmptyState
          icon={<EmptyBoxIcon className="h-10 w-10" aria-hidden="true" />}
          title="No campaigns yet"
          body="Create your first affiliate campaign to start inviting creators to promote your products."
          action={
            <Can minRole="campaign_manager">
              <Button href={`/${orgSlug}/campaigns/new`}>
                <PlusIcon className="h-4 w-4" aria-hidden="true" />
                New campaign
              </Button>
            </Can>
          }
        />
      ) : (
        <>
          <Table
            columns={columns}
            data={result.items}
            rowKey={(c) => c.id}
            ariaLabel="Campaigns"
          />
          {result.totalPages > 1 && (
            <Pagination
              page={result.page}
              totalPages={result.totalPages}
              onChange={setPage}
            />
          )}
        </>
      )}
    </div>
  );
}
