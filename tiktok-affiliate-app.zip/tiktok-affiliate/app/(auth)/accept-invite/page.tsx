"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { apiFetch, getErrorMessage } from "@/lib/client";
import { Button } from "@/components/Button";
import { Alert } from "@/components/Alert";
import { SkeletonLines } from "@/components/Skeleton";

type Status = "loading" | "success" | "error" | "missing";

function AcceptInviteInner(): React.JSX.Element {
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const [status, setStatus] = useState<Status>("loading");
  const [message, setMessage] = useState<string | null>(null);
  const [workspaceHref, setWorkspaceHref] = useState<string>("/");

  useEffect(() => {
    if (!token) {
      setStatus("missing");
      return;
    }
    let cancelled = false;
    (async () => {
      setStatus("loading");
      try {
        const data = await apiFetch<unknown>("/api/invitations/accept", {
          method: "POST",
          body: JSON.stringify({ token }),
        });
        if (cancelled) return;
        const slug =
          (data as { organization?: { slug?: string } } | null)?.organization
            ?.slug ?? null;
        setWorkspaceHref(slug ? `/${slug}/overview` : "/");
        setStatus("success");
      } catch (err) {
        if (cancelled) return;
        setMessage(getErrorMessage(err));
        setStatus("error");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  if (status === "loading") {
    return (
      <div aria-label="Accepting invitation">
        <h1 className="text-xl font-bold text-slate-900">Accepting invitation…</h1>
        <div className="mt-6">
          <SkeletonLines lines={3} />
        </div>
      </div>
    );
  }

  if (status === "missing") {
    return (
      <div>
        <h1 className="text-xl font-bold text-slate-900">Invalid invitation</h1>
        <div className="mt-4">
          <Alert tone="error" title="Missing invitation token">
            This invitation link is missing its token. Ask the person who
            invited you to resend it.
          </Alert>
        </div>
        <div className="mt-6">
          <Link
            href="/signin"
            className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
          >
            Go to sign in
          </Link>
        </div>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div>
        <h1 className="text-xl font-bold text-slate-900">Invitation failed</h1>
        <div className="mt-4">
          <Alert tone="error" title="Could not accept the invitation">
            {message ?? "The invitation link is invalid or has expired."}
          </Alert>
        </div>
        <div className="mt-6">
          <Link
            href="/signin"
            className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
          >
            Go to sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-xl font-bold text-slate-900">You're in!</h1>
      <div className="mt-4">
        <Alert tone="success" title="Invitation accepted">
          Your invitation was accepted. You now have access to the workspace.
        </Alert>
      </div>
      <div className="mt-6">
        <Button variant="primary" href={workspaceHref}>
          Go to workspace
        </Button>
      </div>
    </div>
  );
}

export default function AcceptInvitePage(): React.JSX.Element {
  return (
    <Suspense
      fallback={
        <div aria-label="Accepting invitation">
          <h1 className="text-xl font-bold text-slate-900">Accepting invitation…</h1>
          <div className="mt-6">
            <SkeletonLines lines={3} />
          </div>
        </div>
      }
    >
      <AcceptInviteInner />
    </Suspense>
  );
}
