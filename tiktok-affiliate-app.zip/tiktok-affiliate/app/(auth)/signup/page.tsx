"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { apiFetch, getErrorMessage, getFieldErrors } from "@/lib/client";
import type { MeResponse } from "@/lib/types";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { Alert } from "@/components/Alert";
import { FormErrors } from "@/components/FieldError";

export default function SignUpPage(): React.JSX.Element {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]> | null>(
    null
  );
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFieldErrors(null);
    setGeneralError(null);
    if (password !== confirm) {
      setFieldErrors({ confirmPassword: ["Passwords do not match."] });
      return;
    }
    setLoading(true);
    try {
      await apiFetch("/api/auth/signup", {
        method: "POST",
        body: JSON.stringify({ name, email, password }),
      });
      const me = await apiFetch<MeResponse>("/api/auth/me");
      const slug = me.memberships?.[0]?.organization?.slug;
      router.replace(slug ? `/${slug}/overview` : "/");
    } catch (err) {
      const fields = getFieldErrors(err);
      if (fields) {
        setFieldErrors(fields);
      } else {
        setGeneralError(getErrorMessage(err));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1 className="text-xl font-bold text-slate-900">Create an account</h1>
      <p className="mt-1 text-sm text-slate-600">
        You'll create your organization after signing in.
      </p>

      {generalError && (
        <div className="mt-4">
          <Alert tone="error" title="Sign up failed" onDismiss={() => setGeneralError(null)}>
            {generalError}
          </Alert>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
        <Input
          label="Name"
          name="name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Your name"
          required
          disabled={loading}
          autoComplete="name"
          error={fieldErrors?.name?.[0] ?? undefined}
        />
        <Input
          label="Email"
          name="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          required
          disabled={loading}
          autoComplete="email"
          error={fieldErrors?.email?.[0] ?? undefined}
        />
        <Input
          label="Password"
          name="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Choose a password"
          required
          disabled={loading}
          autoComplete="new-password"
          error={fieldErrors?.password?.[0] ?? undefined}
        />
        <Input
          label="Confirm password"
          name="confirmPassword"
          type="password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          placeholder="Repeat your password"
          required
          disabled={loading}
          autoComplete="new-password"
          error={fieldErrors?.confirmPassword?.[0] ?? undefined}
        />
        <FormErrors errors={fieldErrors} />
        <Button variant="primary" loading={loading} disabled={loading}>
          {loading ? "Creating account…" : "Create account"}
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-600">
        Already have an account?{" "}
        <Link href="/signin" className="font-medium text-indigo-600 hover:text-indigo-700">
          Sign in
        </Link>
      </p>
    </div>
  );
}
