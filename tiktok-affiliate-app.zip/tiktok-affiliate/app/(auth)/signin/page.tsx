"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  apiFetch,
  getErrorMessage,
  getFieldErrors,
  isAuthError,
} from "@/lib/client";
import type { MeResponse } from "@/lib/types";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { Alert } from "@/components/Alert";
import { FormErrors } from "@/components/FieldError";

export default function SignInPage(): React.JSX.Element {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]> | null>(
    null
  );
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFieldErrors(null);
    setGeneralError(null);
    setLoading(true);
    try {
      await apiFetch("/api/auth/signin", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      // Signed in — find the first workspace and go to its overview.
      const me = await apiFetch<MeResponse>("/api/auth/me");
      const slug = me.memberships?.[0]?.organization?.slug;
      router.replace(slug ? `/${slug}/overview` : "/");
    } catch (err) {
      const fields = getFieldErrors(err);
      if (fields) {
        setFieldErrors(fields);
      } else {
        setGeneralError(
          isAuthError(err)
            ? "Email or password is incorrect. Please try again."
            : getErrorMessage(err)
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1 className="text-xl font-bold text-slate-900">Sign in</h1>
      <p className="mt-1 text-sm text-slate-600">
        Welcome back to your affiliate workspace.
      </p>

      {generalError && (
        <div className="mt-4">
          <Alert tone="error" title="Sign in failed" onDismiss={() => setGeneralError(null)}>
            {generalError}
          </Alert>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
        <Input
          label="Email"
          name="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          required
          disabled={loading}
          autoComplete="email"
          error={fieldErrors?.email?.[0] ?? undefined}
        />
        <Input
          label="Password"
          name="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          required
          disabled={loading}
          autoComplete="current-password"
          error={fieldErrors?.password?.[0] ?? undefined}
        />
        <FormErrors errors={fieldErrors} />
        <Button
          variant="primary"
          loading={loading}
          disabled={loading}
        >
          {loading ? "Signing in…" : "Sign in"}
        </Button>
      </form>

      <div className="mt-6 flex items-center justify-between text-sm">
        <Link href="/signup" className="font-medium text-indigo-600 hover:text-indigo-700">
          Create an account
        </Link>
        <Link href="/recover" className="font-medium text-indigo-600 hover:text-indigo-700">
          Forgot password?
        </Link>
      </div>
    </div>
  );
}
