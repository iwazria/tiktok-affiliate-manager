"use client";

import { useState } from "react";
import Link from "next/link";
import { apiFetch, getErrorMessage } from "@/lib/client";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { Alert } from "@/components/Alert";

export default function RecoverPage(): React.JSX.Element {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await apiFetch("/api/auth/recover", {
        method: "POST",
        body: JSON.stringify({ email }),
      });
    } catch (err) {
      // Never reveal whether the account exists; only surface transport errors.
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
      // Always show the generic success message, even on failure.
      setSent(true);
    }
  };

  return (
    <div>
      <h1 className="text-xl font-bold text-slate-900">Reset your password</h1>
      <p className="mt-1 text-sm text-slate-600">
        Enter your account email and we'll send you a reset link.
      </p>

      {sent ? (
        <div className="mt-6">
          <Alert tone="success" title="Check your email">
            If an account exists for that email, a reset link is on its way.
          </Alert>
          <div className="mt-6 text-center">
            <Link
              href="/signin"
              className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
            >
              Back to sign in
            </Link>
          </div>
        </div>
      ) : (
        <>
          {error && (
            <div className="mt-4">
              <Alert tone="warning" title="Request issue" onDismiss={() => setError(null)}>
                {error}
              </Alert>
            </div>
          )}
          <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
            <Input
              label="Email"
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
              disabled={loading}
              autoComplete="email"
            />
            <Button variant="primary" loading={loading} disabled={loading}>
              {loading ? "Sending…" : "Send reset link"}
            </Button>
          </form>
          <p className="mt-6 text-center text-sm text-slate-600">
            <Link href="/signin" className="font-medium text-indigo-600 hover:text-indigo-700">
              Back to sign in
            </Link>
          </p>
        </>
      )}
    </div>
  );
}
