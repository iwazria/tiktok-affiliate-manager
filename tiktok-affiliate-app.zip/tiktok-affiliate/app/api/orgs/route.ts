import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { authUser, uniqueOrgSlug } from "@/app/api/_lib/org";

export async function GET(req: NextRequest) {
  const { error, user } = await authUser(req);
  if (error) return error;

  const memberships = await prisma.organizationMember.findMany({
    where: { userId: user.id, status: "active" },
    include: { organization: { select: { id: true, name: true, slug: true } } },
    orderBy: { createdAt: "asc" },
  });

  return ok(
    memberships.map((m) => ({
      id: m.organization.id,
      name: m.organization.name,
      slug: m.organization.slug,
      role: m.role,
    }))
  );
}

const createOrgSchema = z.object({
  name: z.string().min(1, "Organization name is required").max(100),
});

export async function POST(req: NextRequest) {
  const { error: authError, user } = await authUser(req);
  if (authError) return authError;

  const { error, data } = await parseJson(req, createOrgSchema);
  if (error) return error;

  const name = data.name.trim();
  const slug = await uniqueOrgSlug(name);
  const org = await prisma.organization.create({
    data: {
      name,
      slug,
      members: { create: { userId: user.id, role: "owner", status: "active" } },
      onboarding: { create: {} },
    },
  });

  await audit({
    organizationId: org.id,
    actorId: user.id,
    action: "org.created",
    entityType: "Organization",
    entityId: org.id,
    details: { name },
  });

  return ok({ id: org.id, name: org.name, slug: org.slug, role: "owner" }, 201);
}
