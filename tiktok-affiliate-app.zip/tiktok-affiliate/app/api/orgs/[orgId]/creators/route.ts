import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, parseJson, zodFail } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, parsePagination, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

const listQuerySchema = z.object({
  search: z.string().max(200).optional(),
  tag: z.string().max(50).optional(),
  listId: z.string().optional(),
  page: z.string().optional(),
  pageSize: z.string().optional(),
});

function publicCreator(c: {
  id: string;
  handle: string | null;
  displayName: string | null;
  avatarUrl: string | null;
  followerCount: number | null;
  notes: string | null;
  tags: string | null;
  source: string;
  isDemo: boolean;
  createdAt: Date;
  lists?: { list: { id: string; name: string } }[];
}) {
  let tags: string[] = [];
  try {
    tags = c.tags ? (JSON.parse(c.tags) as string[]) : [];
  } catch {
    tags = [];
  }
  return {
    id: c.id,
    handle: c.handle,
    displayName: c.displayName,
    avatarUrl: c.avatarUrl,
    followerCount: c.followerCount,
    notes: c.notes,
    tags,
    source: c.source,
    isDemo: c.isDemo,
    createdAt: c.createdAt,
    lists: c.lists?.map((m) => m.list) ?? [],
  };
}

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const parsed = listQuerySchema.safeParse(
    Object.fromEntries(req.nextUrl.searchParams.entries())
  );
  if (!parsed.success) return zodFail(parsed.error);
  const q = parsed.data;
  const { page, pageSize, skip } = parsePagination(req.nextUrl.searchParams);

  // Tags are stored as a JSON array string; match the quoted tag token.
  const where = {
    organizationId: orgId,
    ...(q.listId ? { lists: { some: { listId: q.listId } } } : {}),
    ...(q.tag ? { tags: { contains: `"${q.tag}"` } } : {}),
    ...(q.search
      ? {
          OR: [
            { handle: { contains: q.search } },
            { displayName: { contains: q.search } },
          ],
        }
      : {}),
  };

  const [creators, total] = await Promise.all([
    prisma.creator.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take: pageSize,
      include: { lists: { include: { list: { select: { id: true, name: true } } } } },
    }),
    prisma.creator.count({ where }),
  ]);

  return ok({
    items: creators.map(publicCreator),
    page,
    pageSize,
    total,
    totalPages: Math.ceil(total / pageSize),
  });
}

const createCreatorSchema = z.object({
  handle: z.string().max(100).optional(),
  displayName: z.string().max(200).optional(),
  followerCount: z.number().int().min(0).nullable().optional(),
  notes: z.string().max(2000).nullable().optional(),
  tags: z.array(z.string().max(50)).max(20).optional(),
}).refine((v) => v.handle?.trim() || v.displayName?.trim(), {
  message: "Provide a handle or a display name.",
  path: ["handle"],
});

/** Create a manually-entered creator record (source: manual). */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, createCreatorSchema);
  if (bodyError) return bodyError;

  const creator = await prisma.creator.create({
    data: {
      organizationId: orgId,
      handle: data.handle?.trim() || null,
      displayName: data.displayName?.trim() || null,
      followerCount: data.followerCount ?? null,
      notes: data.notes?.trim() || null,
      tags: data.tags ? JSON.stringify(data.tags) : null,
      source: "manual",
    },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator.created",
    entityType: "Creator",
    entityId: creator.id,
    details: { handle: creator.handle, source: "manual" },
    ip: clientIp(req),
  });

  return ok(publicCreator(creator), 201);
}
