import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; creatorId: string }> };

function serializeTags(tags?: string[] | null) {
  return tags ? JSON.stringify(tags) : null;
}

const patchCreatorSchema = z.object({
  handle: z.string().max(100).nullable().optional(),
  displayName: z.string().max(200).nullable().optional(),
  followerCount: z.number().int().min(0).nullable().optional(),
  notes: z.string().max(2000).nullable().optional(),
  tags: z.array(z.string().max(50)).max(20).nullable().optional(),
});

export async function PATCH(req: NextRequest, { params }: Params) {
  const { orgId, creatorId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, patchCreatorSchema);
  if (bodyError) return bodyError;

  const creator = await prisma.creator.findFirst({
    where: { id: creatorId, organizationId: orgId },
  });
  if (!creator) return fail("not_found", "Creator not found.", 404);

  const updated = await prisma.creator.update({
    where: { id: creator.id },
    data: {
      ...(data.handle !== undefined ? { handle: data.handle?.trim() || null } : {}),
      ...(data.displayName !== undefined ? { displayName: data.displayName?.trim() || null } : {}),
      ...(data.followerCount !== undefined ? { followerCount: data.followerCount } : {}),
      ...(data.notes !== undefined ? { notes: data.notes?.trim() || null } : {}),
      ...(data.tags !== undefined ? { tags: serializeTags(data.tags) } : {}),
    },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator.updated",
    entityType: "Creator",
    entityId: creator.id,
    ip: clientIp(req),
  });

  return ok({ id: updated.id });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const { orgId, creatorId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const creator = await prisma.creator.findFirst({
    where: { id: creatorId, organizationId: orgId },
  });
  if (!creator) return fail("not_found", "Creator not found.", 404);

  // List memberships and collaborations cascade-delete via the schema relations.
  await prisma.creator.delete({ where: { id: creator.id } });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator.deleted",
    entityType: "Creator",
    entityId: creatorId,
    details: { handle: creator.handle },
    ip: clientIp(req),
  });

  return ok({ deleted: true });
}
