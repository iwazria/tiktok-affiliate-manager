import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok } from "@/lib/api";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const shops = await prisma.connectedShop.findMany({
    where: { organizationId: orgId },
    include: { scopes: { select: { scope: true } } },
    orderBy: { connectedAt: "desc" },
  });

  return ok(
    shops.map((s) => ({
      id: s.id,
      tiktokShopId: s.tiktokShopId,
      shopName: s.shopName,
      region: s.region,
      currency: s.currency,
      status: s.status,
      mode: s.mode,
      scopes: s.scopes.map((sc) => sc.scope),
      lastSyncAt: s.lastSyncAt,
      lastSyncStatus: s.lastSyncStatus,
      lastSyncError: s.lastSyncError,
      connectedAt: s.connectedAt,
    }))
  );
}
