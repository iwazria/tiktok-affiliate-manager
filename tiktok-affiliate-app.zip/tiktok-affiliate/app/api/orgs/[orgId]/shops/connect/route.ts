import { NextRequest } from "next/server";
import { randomBytes } from "crypto";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { isDemoMode } from "@/lib/config";
import { orgContext, clientIp } from "@/app/api/_lib/org";
import { createAuthorizationSession } from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string }> };

const DEMO_SCOPES = ["demo.product", "demo.affiliate"];

/**
 * Connect a TikTok Shop.
 * - Demo mode: creates a demo ConnectedShop immediately (labeled demo data).
 * - Live mode: starts the official seller authorization flow and returns the
 *   authorization URL. The callback route completes the connection.
 */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;

  if (isDemoMode()) {
    let shop = await prisma.connectedShop.findFirst({
      where: { organizationId: orgId, mode: "demo" },
    });
    if (shop) {
      if (shop.status === "disconnected") {
        shop = await prisma.connectedShop.update({
          where: { id: shop.id },
          data: { status: "connected", disconnectedAt: null, lastSyncError: null },
        });
      }
    } else {
      const tiktokShopId = `demo-shop-${randomBytes(4).toString("hex")}`;
      shop = await prisma.connectedShop.create({
        data: {
          organizationId: orgId,
          tiktokShopId,
          shopName: "Demo TikTok Shop",
          region: "US",
          currency: "USD",
          sellerType: "demo",
          status: "connected",
          mode: "demo",
          connectedById: user.id,
          scopes: { create: DEMO_SCOPES.map((scope) => ({ scope })) },
        },
        include: { scopes: true },
      });
    }

    await prisma.onboardingState.upsert({
      where: { organizationId: orgId },
      update: { shopConnected: true },
      create: { organizationId: orgId, shopConnected: true },
    });

    await audit({
      organizationId: orgId,
      actorId: user.id,
      action: "shop.connected",
      entityType: "ConnectedShop",
      entityId: shop.id,
      details: { mode: "demo", tiktokShopId: shop.tiktokShopId },
      ip: clientIp(req),
    });

    await notify(
      orgId,
      "integration_attention",
      "Demo shop connected",
      "A demo TikTok Shop was connected. All data shown for it is simulated."
    );

    return ok({ mode: "demo", shop: { id: shop.id, tiktokShopId: shop.tiktokShopId } }, 201);
  }

  // Live mode: begin the official seller authorization flow.
  try {
    const { authUrl } = await createAuthorizationSession(orgId, user.id, "seller");

    await audit({
      organizationId: orgId,
      actorId: user.id,
      action: "shop.auth_started",
      details: { mode: "live" },
      ip: clientIp(req),
    });

    return ok({ mode: "live", authUrl });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Could not start authorization.";
    return fail("auth_start_failed", message, 502);
  }
}
