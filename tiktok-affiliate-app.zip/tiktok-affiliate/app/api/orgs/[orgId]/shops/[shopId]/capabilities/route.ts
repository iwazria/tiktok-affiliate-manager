import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { orgContext, getOrgShop } from "@/app/api/_lib/org";
import { getShopCapabilities } from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; shopId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, shopId } = await params;
  const { error } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const shop = await getOrgShop(orgId, shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const capabilities = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );

  return ok({ capabilities, mode: shop.mode, scopes: scopes.map((s) => s.scope) });
}
