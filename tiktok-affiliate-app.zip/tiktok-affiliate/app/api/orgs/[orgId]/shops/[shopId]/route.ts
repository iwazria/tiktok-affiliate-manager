import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import { getShopCapabilities, disconnectShop as revokeShopAuth } from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; shopId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, shopId } = await params;
  const { error } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const shop = await getOrgShop(orgId, shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const scopeNames = scopes.map((s) => s.scope);
  const capabilities = await getShopCapabilities(shop, scopeNames);

  return ok({
    shop: {
      id: shop.id,
      tiktokShopId: shop.tiktokShopId,
      shopName: shop.shopName,
      region: shop.region,
      currency: shop.currency,
      sellerType: shop.sellerType,
      status: shop.status,
      mode: shop.mode,
      connectedAt: shop.connectedAt,
      disconnectedAt: shop.disconnectedAt,
    },
    scopes: scopeNames,
    capabilities,
    sync: {
      lastSyncAt: shop.lastSyncAt,
      lastSyncStatus: shop.lastSyncStatus,
      lastSyncError: shop.lastSyncError,
    },
  });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const { orgId, shopId } = await params;
  // "admin" minimum covers owners as well (owner outranks admin).
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;
  return disconnectShop(req, orgId, shopId, user.id);
}

async function disconnectShop(
  req: NextRequest,
  orgId: string,
  shopId: string,
  actorId: string
) {
  const shop = await getOrgShop(orgId, shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);
  if (shop.status === "disconnected") return ok({ disconnected: true });

  // Best-effort remote revoke via the integration layer (which always deletes
  // stored credentials locally); local cleanup below runs regardless.
  try {
    await revokeShopAuth(shop.id, actorId);
  } catch {
    // Continue: stored credentials are deleted below either way.
  }

  await prisma.encryptedCredential.deleteMany({ where: { shopId: shop.id } });
  await prisma.connectedShop.update({
    where: { id: shop.id },
    data: { status: "disconnected", disconnectedAt: new Date() },
  });

  await audit({
    organizationId: orgId,
    actorId,
    action: "shop.disconnected",
    entityType: "ConnectedShop",
    entityId: shop.id,
    details: { tiktokShopId: shop.tiktokShopId, mode: shop.mode },
    ip: clientIp(req),
  });

  await notify(
    orgId,
    "integration_attention",
    "Shop disconnected",
    `${shop.shopName ?? "The shop"} was disconnected and its stored credentials were deleted.`
  );

  return ok({ disconnected: true });
}
