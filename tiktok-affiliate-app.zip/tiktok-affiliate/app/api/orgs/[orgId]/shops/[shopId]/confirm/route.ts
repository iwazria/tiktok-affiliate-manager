import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; shopId: string }> };

/** Confirm the connected shop identity (onboarding step 3). */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, shopId } = await params;
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const shop = await getOrgShop(orgId, shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);
  if (shop.status === "disconnected") {
    return fail("invalid_state", "This shop is disconnected.", 400);
  }

  const row = await prisma.onboardingState.upsert({
    where: { organizationId: orgId },
    update: { shopConfirmed: true },
    create: { organizationId: orgId, shopConfirmed: true },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "shop.confirmed",
    entityType: "ConnectedShop",
    entityId: shop.id,
    details: { tiktokShopId: shop.tiktokShopId, shopName: shop.shopName },
    ip: clientIp(req),
  });

  return ok({ shopConfirmed: row.shopConfirmed });
}
