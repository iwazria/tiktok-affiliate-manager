import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { enqueueJob } from "@/lib/jobs";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import { getShopCapabilities, hasCapability, CAP } from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; shopId: string }> };

const syncSchema = z.object({
  kind: z.enum(["product", "campaign", "collab", "metrics"]),
});

const KIND_TO_CAPABILITY: Record<string, string> = {
  product: CAP.productSync,
  campaign: CAP.campaignSync,
  collab: CAP.collabSync,
  metrics: CAP.metricsSync,
};

/** Enqueue a sync job for the shop (processed by the job runner). */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, shopId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, syncSchema);
  if (bodyError) return bodyError;

  const shop = await getOrgShop(orgId, shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);
  if (shop.status === "disconnected") {
    return fail("invalid_state", "This shop is disconnected. Reconnect it before syncing.", 400);
  }

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const capabilities = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  const capKey = KIND_TO_CAPABILITY[data.kind];
  if (!hasCapability(capabilities, capKey)) {
    return fail(
      "capability_unavailable",
      `The ${data.kind} sync is not available for this shop with its current TikTok approval and scopes.`
    );
  }

  const jobId = await enqueueJob({
    organizationId: orgId,
    shopId: shop.id,
    kind: `${data.kind}_sync` as "product_sync" | "campaign_sync" | "collab_sync" | "metrics_sync",
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "shop.sync_requested",
    entityType: "ConnectedShop",
    entityId: shop.id,
    details: { kind: data.kind, jobId },
    ip: clientIp(req),
  });

  return ok({ jobId, kind: data.kind }, 202);
}
