import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, ctx } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const org = await prisma.organization.findUnique({ where: { id: orgId } });
  if (!org) return fail("not_found", "Organization not found.", 404);

  return ok({
    organization: { id: org.id, name: org.name, slug: org.slug },
    myRole: ctx.role,
  });
}

const patchOrgSchema = z.object({
  name: z.string().min(1, "Organization name is required").max(100),
});

export async function PATCH(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user, ctx } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, patchOrgSchema);
  if (bodyError) return bodyError;

  const org = await prisma.organization.update({
    where: { id: orgId },
    data: { name: data.name.trim() },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "org.updated",
    entityType: "Organization",
    entityId: orgId,
    details: { name: org.name },
    ip: clientIp(req),
  });

  return ok({ id: org.id, name: org.name, slug: org.slug, myRole: ctx.role });
}
