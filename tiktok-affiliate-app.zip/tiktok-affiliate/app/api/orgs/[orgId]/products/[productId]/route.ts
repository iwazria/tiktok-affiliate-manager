import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; productId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, productId } = await params;
  const { error } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const product = await prisma.product.findFirst({
    where: { id: productId, organizationId: orgId },
    include: { shop: { select: { id: true, shopName: true, mode: true, region: true } } },
  });
  if (!product) return fail("not_found", "Product not found.", 404);

  let rawFields: Record<string, unknown> | null = null;
  if (product.rawFields) {
    try {
      rawFields = JSON.parse(product.rawFields) as Record<string, unknown>;
    } catch {
      rawFields = null;
    }
  }

  return ok({
    id: product.id,
    tiktokProductId: product.tiktokProductId,
    name: product.name,
    imageUrl: product.imageUrl,
    price: product.price,
    currency: product.currency,
    status: product.status,
    stock: product.stock,
    affiliateEligible: product.affiliateEligible,
    ineligibilityReason: product.ineligibilityReason,
    isDemo: product.isDemo,
    lastSyncedAt: product.lastSyncedAt,
    createdAt: product.createdAt,
    updatedAt: product.updatedAt,
    shop: product.shop,
    rawFields,
  });
}
