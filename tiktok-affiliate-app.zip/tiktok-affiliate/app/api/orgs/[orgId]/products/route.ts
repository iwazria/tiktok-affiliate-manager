import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, zodFail } from "@/lib/api";
import { orgContext, parsePagination } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

const querySchema = z.object({
  shopId: z.string().optional(),
  search: z.string().max(200).optional(),
  status: z.string().max(50).optional(),
  eligible: z.enum(["true", "false"]).optional(),
  sort: z.enum(["name", "price", "stock"]).optional(),
  page: z.string().optional(),
  pageSize: z.string().optional(),
});

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const parsed = querySchema.safeParse(Object.fromEntries(req.nextUrl.searchParams.entries()));
  if (!parsed.success) return zodFail(parsed.error);
  const q = parsed.data;
  const { page, pageSize, skip } = parsePagination(req.nextUrl.searchParams);

  const where = {
    organizationId: orgId,
    ...(q.shopId ? { shopId: q.shopId } : {}),
    ...(q.status ? { status: q.status } : {}),
    ...(q.eligible ? { affiliateEligible: q.eligible === "true" } : {}),
    ...(q.search ? { name: { contains: q.search } } : {}),
  };

  const orderBy =
    q.sort === "name"
      ? { name: "asc" as const }
      : q.sort === "price"
        ? { price: "asc" as const }
        : q.sort === "stock"
          ? { stock: "desc" as const }
          : { updatedAt: "desc" as const };

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where,
      orderBy,
      skip,
      take: pageSize,
      include: { shop: { select: { id: true, shopName: true, mode: true } } },
    }),
    prisma.product.count({ where }),
  ]);

  return ok({
    items: items.map((p) => ({
      id: p.id,
      tiktokProductId: p.tiktokProductId,
      name: p.name,
      imageUrl: p.imageUrl,
      price: p.price,
      currency: p.currency,
      status: p.status,
      stock: p.stock,
      affiliateEligible: p.affiliateEligible,
      ineligibilityReason: p.ineligibilityReason,
      isDemo: p.isDemo,
      lastSyncedAt: p.lastSyncedAt,
      shop: p.shop,
    })),
    page,
    pageSize,
    total,
    totalPages: Math.ceil(total / pageSize),
  });
}
