import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, zodFail } from "@/lib/api";
import { isDemoMode } from "@/lib/config";
import { orgContext, getOrgShop } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string }> };

const querySchema = z.object({
  by: z.enum(["day", "campaign", "product", "creator"]),
  shopId: z.string().optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
});

interface BreakdownRow {
  id: string | null;
  label: string;
  clicks: number;
  orders: number;
  revenue: number;
  commission: number;
}

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const parsed = querySchema.safeParse(
    Object.fromEntries(req.nextUrl.searchParams.entries())
  );
  if (!parsed.success) return zodFail(parsed.error);
  const q = parsed.data;
  const to = q.to ?? new Date();
  const from = q.from ?? new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000);

  const meta = {
    timezone: "UTC",
    range: { from: from.toISOString(), to: to.toISOString() },
    source: "none" as "demo" | "tiktok_api" | "none",
    quality: null as string | null,
    syncedAt: null as string | null,
    available: false,
    note: "",
  };

  if (isDemoMode()) {
    const snaps = await prisma.performanceSnapshot.findMany({
      where: {
        organizationId: orgId,
        ...(q.shopId ? { shopId: q.shopId } : {}),
        date: { gte: from, lte: to },
      },
    });
    if (snaps.length === 0) {
      meta.note = "No synced metrics yet. Run a metrics sync to populate this report.";
      return ok({ rows: [], meta });
    }

    const campaigns = await prisma.campaign.findMany({
      where: { organizationId: orgId },
      select: { id: true, name: true },
    });
    const products = await prisma.product.findMany({
      where: { organizationId: orgId },
      select: { id: true, name: true },
    });
    const creators = await prisma.creator.findMany({
      where: { organizationId: orgId },
      select: { id: true, displayName: true, handle: true },
    });
    const campaignName = new Map(campaigns.map((c) => [c.id, c.name]));
    const productName = new Map(products.map((p) => [p.id, p.name]));
    const creatorName = new Map(
      creators.map((c) => [c.id, c.displayName ?? c.handle ?? "Creator"])
    );

    const groups = new Map<string, BreakdownRow & { _sort: string }>();
    for (const s of snaps) {
      let key: string;
      let label: string;
      if (q.by === "day") {
        key = s.date.toISOString().slice(0, 10);
        label = key;
      } else if (q.by === "campaign") {
        key = s.campaignId ?? "none";
        label = s.campaignId ? (campaignName.get(s.campaignId) ?? "Campaign") : "Unattributed";
      } else if (q.by === "product") {
        key = s.productId ?? "none";
        label = s.productId ? (productName.get(s.productId) ?? "Product") : "Unattributed";
      } else {
        key = s.creatorId ?? "none";
        label = s.creatorId ? (creatorName.get(s.creatorId) ?? "Creator") : "Unattributed";
      }
      const g = groups.get(key) ?? {
        id: key === "none" ? null : key,
        label,
        clicks: 0,
        orders: 0,
        revenue: 0,
        commission: 0,
        _sort: key,
      };
      g.clicks += s.clicks ?? 0;
      g.orders += s.orders ?? 0;
      g.revenue += s.revenue ?? 0;
      g.commission += s.commission ?? 0;
      groups.set(key, g);
    }
    const rows: BreakdownRow[] = [...groups.values()]
      .sort((a, b) => (a._sort < b._sort ? -1 : 1))
      .map(({ _sort, ...r }) => r);

    meta.source = "demo";
    meta.quality = snaps[0].quality;
    meta.syncedAt = snaps.reduce((a, b) => (a > b.syncedAt ? a : b.syncedAt), snaps[0].syncedAt).toISOString();
    meta.available = true;
    meta.note = "Simulated demo data. TikTok source data may be delayed or revised.";
    return ok({ rows, meta });
  }

  // Live mode
  const shop = q.shopId
    ? await getOrgShop(orgId, q.shopId)
    : await prisma.connectedShop.findFirst({
        where: { organizationId: orgId, mode: "live", status: "connected" },
        orderBy: { connectedAt: "asc" },
      });
  if (!shop) {
    meta.note = "No connected live shop.";
    return ok({ rows: [], meta });
  }
  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const caps = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  if (!hasCapability(caps, CAP.performanceMetrics)) {
    meta.note = "Not available from connected TikTok Shop data.";
    return ok({ rows: [], meta });
  }

  try {
    const provider = await getShopProvider(shop.id);
    const res = await provider.getPerformanceMetrics({
      dateFrom: from.toISOString().slice(0, 10),
      dateTo: to.toISOString().slice(0, 10),
    });
    const points = res.points;
    const groups = new Map<string, BreakdownRow>();
    for (const m of points) {
      const key =
        q.by === "day"
          ? (m.date ? new Date(m.date).toISOString().slice(0, 10) : "none")
          : q.by === "campaign"
            ? (m.campaignId ?? "none")
            : q.by === "product"
              ? (m.productId ?? "none")
              : (m.creatorId ?? "none");
      const g = groups.get(key) ?? {
        id: key === "none" ? null : key,
        label: key,
        clicks: 0,
        orders: 0,
        revenue: 0,
        commission: 0,
      };
      g.clicks += m.clicks ?? 0;
      g.orders += m.orders ?? 0;
      g.revenue += m.revenue ?? 0;
      g.commission += m.commission ?? 0;
      groups.set(key, g);
    }
    // Resolve friendly labels for campaigns/products/creators where possible.
    if (q.by === "campaign" || q.by === "product") {
      const campaigns = await prisma.campaign.findMany({
        where: { shopId: shop.id, tiktokCampaignId: { not: null } },
        select: { tiktokCampaignId: true, name: true },
      });
      const products = await prisma.product.findMany({
        where: { shopId: shop.id },
        select: { tiktokProductId: true, name: true },
      });
      const names = new Map<string, string>();
      for (const c of campaigns) if (c.tiktokCampaignId) names.set(c.tiktokCampaignId, c.name);
      for (const p of products) names.set(p.tiktokProductId, p.name);
      for (const g of groups.values()) {
        if (g.id && names.has(g.id)) g.label = names.get(g.id)!;
      }
    }
    meta.source = res.source === "demo" ? "demo" : "tiktok_api";
    meta.quality = res.quality;
    meta.syncedAt = res.syncedAt;
    meta.available = points.length > 0;
    meta.note = "TikTok source data may be delayed or revised.";
    return ok({ rows: [...groups.values()], meta });
  } catch (e) {
    const mapped = mapTikTokError(e);
    return fail(mapped.code, mapped.message, mapped.status);
  }
}
