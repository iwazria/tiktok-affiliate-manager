import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, zodFail } from "@/lib/api";
import { isDemoMode } from "@/lib/config";
import { orgContext, getOrgShop } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string }> };

const querySchema = z.object({
  shopId: z.string().optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
});

interface MetricValue {
  value: number | null;
  source: "demo" | "tiktok_api" | "none";
  quality: string | null;
  syncedAt: string | null;
  available: boolean;
  note?: string;
}

const UNAVAILABLE = (note: string): MetricValue => ({
  value: null,
  source: "none",
  quality: null,
  syncedAt: null,
  available: false,
  note,
});

function emptySummary(note: string) {
  return {
    clicks: UNAVAILABLE(note),
    orders: UNAVAILABLE(note),
    revenue: UNAVAILABLE(note),
    commission: UNAVAILABLE(note),
    timezone: "UTC",
    range: null,
  };
}

/**
 * Report summary totals. Every metric carries its source, quality and
 * freshness. Metrics the connected TikTok Shop does not provide are returned
 * as available:false — never fabricated.
 */
export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const parsed = querySchema.safeParse(
    Object.fromEntries(req.nextUrl.searchParams.entries())
  );
  if (!parsed.success) return zodFail(parsed.error);
  const q = parsed.data;
  const to = q.to ?? new Date();
  const from = q.from ?? new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000);

  if (isDemoMode()) {
    const snaps = await prisma.performanceSnapshot.findMany({
      where: {
        organizationId: orgId,
        ...(q.shopId ? { shopId: q.shopId } : {}),
        date: { gte: from, lte: to },
      },
      orderBy: { syncedAt: "desc" },
    });
    if (snaps.length === 0) {
      return ok(emptySummary("No synced metrics yet. Run a metrics sync to populate this report."));
    }
    const sum = (pick: (s: (typeof snaps)[number]) => number | null) =>
      snaps.reduce((acc, s) => acc + (pick(s) ?? 0), 0);
    const latestSync = snaps[0].syncedAt.toISOString();
    const quality = snaps[0].quality;
    const mk = (value: number): MetricValue => ({
      value,
      source: "demo",
      quality,
      syncedAt: latestSync,
      available: true,
      note: "Simulated demo data.",
    });
    return ok({
      clicks: mk(sum((s) => s.clicks)),
      orders: mk(sum((s) => s.orders)),
      revenue: mk(sum((s) => s.revenue)),
      commission: mk(sum((s) => s.commission)),
      timezone: "UTC",
      range: { from: from.toISOString(), to: to.toISOString() },
    });
  }

  // Live mode: use the provider, only when the capability is granted.
  let shop = q.shopId
    ? await getOrgShop(orgId, q.shopId)
    : await prisma.connectedShop.findFirst({
        where: { organizationId: orgId, mode: "live", status: "connected" },
        orderBy: { connectedAt: "asc" },
      });
  if (!shop) {
    return ok(emptySummary("No connected live shop. Connect a TikTok Shop to see metrics."));
  }
  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const caps = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  if (!hasCapability(caps, CAP.performanceMetrics)) {
    return ok(
      emptySummary("Not available from connected TikTok Shop data.")
    );
  }

  try {
    const provider = await getShopProvider(shop.id);
    const res = await provider.getPerformanceMetrics({
      dateFrom: from.toISOString().slice(0, 10),
      dateTo: to.toISOString().slice(0, 10),
    });
    const totals = res.totals;
    const source = res.source === "demo" ? "demo" : "tiktok_api";
    if (
      totals.clicks == null &&
      totals.orders == null &&
      totals.revenue == null &&
      totals.commission == null
    ) {
      return ok(emptySummary("TikTok Shop returned no metrics for this range."));
    }
    const mk = (value: number | null): MetricValue => ({
      value,
      source,
      quality: res.quality,
      syncedAt: res.syncedAt,
      available: value != null,
      note: "TikTok source data may be delayed or revised.",
    });
    return ok({
      clicks: mk(totals.clicks),
      orders: mk(totals.orders),
      revenue: mk(totals.revenue),
      commission: mk(totals.commission),
      timezone: res.timezone,
      range: { from: from.toISOString(), to: to.toISOString() },
      shop: { id: shop.id, shopName: shop.shopName },
    });
  } catch (e) {
    const mapped = mapTikTokError(e);
    return fail(mapped.code, mapped.message, mapped.status);
  }
}
