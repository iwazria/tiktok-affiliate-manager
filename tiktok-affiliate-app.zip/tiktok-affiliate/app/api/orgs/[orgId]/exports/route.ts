import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { enqueueJob } from "@/lib/jobs";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

const exportSchema = z.object({
  kind: z.enum(["creators", "products", "report"]),
  filters: z
    .object({
      shopId: z.string().optional(),
      from: z.string().optional(),
      to: z.string().optional(),
    })
    .optional(),
});

function publicExport(e: {
  id: string;
  kind: string;
  status: string;
  fileName: string | null;
  rowCount: number | null;
  error: string | null;
  createdAt: Date;
  finishedAt: Date | null;
}) {
  return {
    id: e.id,
    kind: e.kind,
    status: e.status,
    fileName: e.fileName,
    rowCount: e.rowCount,
    error: e.error,
    createdAt: e.createdAt,
    finishedAt: e.finishedAt,
  };
}

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const exports = await prisma.exportJob.findMany({
    where: { organizationId: orgId },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  return ok(exports.map(publicExport));
}

/** Queue a CSV export. The job runner builds the file and notifies when ready. */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, exportSchema);
  if (bodyError) return bodyError;

  const exportJob = await prisma.exportJob.create({
    data: {
      organizationId: orgId,
      userId: user.id,
      kind: data.kind,
      status: "queued",
    },
  });

  await enqueueJob({
    organizationId: orgId,
    shopId: data.filters?.shopId,
    kind: "report_export",
    payload: { exportJobId: exportJob.id, kind: data.kind, filters: data.filters ?? {} },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "export.requested",
    entityType: "ExportJob",
    entityId: exportJob.id,
    details: { kind: data.kind, filters: data.filters ?? {} },
    ip: clientIp(req),
  });

  return ok(publicExport(exportJob), 202);
}
