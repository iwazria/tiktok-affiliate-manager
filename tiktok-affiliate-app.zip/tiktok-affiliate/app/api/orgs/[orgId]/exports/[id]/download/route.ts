import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import { prisma } from "@/lib/db";
import { fail } from "@/lib/api";
import { roleAtLeast } from "@/lib/rbac";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; id: string }> };

const EXPORT_DIR = path.join(process.cwd(), "storage", "exports");

/** Download a finished CSV export. Ownership + role checked; path is server-generated. */
export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, id } = await params;
  const { error, user, ctx } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const exportJob = await prisma.exportJob.findFirst({
    where: { id, organizationId: orgId },
  });
  if (!exportJob) return fail("not_found", "Export not found.", 404);

  // The requesting user must own the export or be an admin+.
  if (exportJob.userId !== user.id && !roleAtLeast(ctx.role, "admin")) {
    return fail("forbidden", "You don't have permission to download this export.", 403);
  }

  if (exportJob.status !== "ready" || !exportJob.filePath || !exportJob.fileName) {
    return fail(
      "not_ready",
      exportJob.status === "failed"
        ? `Export failed: ${exportJob.error ?? "unknown error"}`
        : "Export is not ready yet.",
      409
    );
  }

  // Guard against path traversal: the file must live under the exports dir.
  const resolved = path.resolve(exportJob.filePath);
  if (!resolved.startsWith(EXPORT_DIR + path.sep)) {
    return fail("not_found", "Export file not found.", 404);
  }

  let content: Buffer;
  try {
    content = await fs.readFile(resolved);
  } catch {
    return fail("not_found", "Export file not found.", 404);
  }

  return new NextResponse(new Uint8Array(content), {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${exportJob.fileName}"`,
      "Content-Length": String(content.length),
    },
  });
}
