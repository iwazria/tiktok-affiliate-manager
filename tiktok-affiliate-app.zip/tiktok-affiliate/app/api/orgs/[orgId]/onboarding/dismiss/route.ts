import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const row = await prisma.onboardingState.upsert({
    where: { organizationId: orgId },
    update: { dismissed: true },
    create: { organizationId: orgId, dismissed: true },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "org.onboarding_dismissed",
    entityType: "Organization",
    entityId: orgId,
    ip: clientIp(req),
  });

  return ok({ dismissed: row.dismissed });
}
