import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok } from "@/lib/api";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

const DEFAULTS = {
  shopConnected: false,
  shopConfirmed: false,
  productsSynced: false,
  firstCampaign: false,
  teamInvited: false,
  dismissed: false,
};

/** First-run onboarding checklist. Steps:
 * 1. Create or join an organization (done when this row exists).
 * 2. Connect a TikTok Shop, or continue in demo mode (shopConnected).
 * 3. Confirm the connected shop identity (shopConfirmed).
 * 4. Sync products (productsSynced).
 * 5. Create the first campaign (firstCampaign).
 * 6. Invite team members if needed (teamInvited).
 * Demo users are never blocked from exploring.
 */
export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const row = await prisma.onboardingState.findUnique({
    where: { organizationId: orgId },
  });

  return ok({
    organizationJoined: true,
    shopConnected: row?.shopConnected ?? DEFAULTS.shopConnected,
    shopConfirmed: row?.shopConfirmed ?? DEFAULTS.shopConfirmed,
    productsSynced: row?.productsSynced ?? DEFAULTS.productsSynced,
    firstCampaign: row?.firstCampaign ?? DEFAULTS.firstCampaign,
    teamInvited: row?.teamInvited ?? DEFAULTS.teamInvited,
    dismissed: row?.dismissed ?? DEFAULTS.dismissed,
  });
}
