import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; collabId: string }> };

async function loadCollab(orgId: string, collabId: string) {
  return prisma.collaboration.findFirst({
    where: { id: collabId, organizationId: orgId },
    include: { campaign: { include: { shop: true } }, creator: true },
  });
}

async function capabilityFor(
  orgId: string,
  shopId: string,
  key: string
): Promise<boolean> {
  const shop = await getOrgShop(orgId, shopId);
  if (!shop) return false;
  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const caps = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  return hasCapability(caps, key);
}

/** Resend a collaboration invitation (capability-gated). */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, collabId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const collab = await loadCollab(orgId, collabId);
  if (!collab) return fail("not_found", "Collaboration not found.", 404);
  if (["accepted", "completed", "cancelled"].includes(collab.status)) {
    return fail("invalid_state", `Cannot resend an invitation with status "${collab.status}".`, 400);
  }

  const capOk = await capabilityFor(orgId, collab.campaign.shopId, CAP.creatorInviteResend);
  if (!capOk) {
    return fail(
      "capability_unavailable",
      "Resending invitations is not available for this shop with its current TikTok approval and scopes."
    );
  }

  const shop = collab.campaign.shop;
  const isDemo = shop.mode === "demo";
  if (!isDemo && collab.campaign.tiktokCampaignId && collab.tiktokInviteId) {
    try {
      const provider = await getShopProvider(shop.id);
      await provider.resendInvitation(collab.tiktokInviteId);
    } catch (e) {
      const mapped = mapTikTokError(e);
      return fail(mapped.code, mapped.message, mapped.status, mapped.fieldErrors);
    }
  }

  const updated = await prisma.collaboration.update({
    where: { id: collab.id },
    data: { status: "sent", invitedAt: new Date(), lastError: null },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "collab.resent",
    entityType: "Collaboration",
    entityId: collab.id,
    details: { demo: isDemo },
    ip: clientIp(req),
  });

  await notify(orgId, "invite_status", "Invitation resent", `The invitation to ${collab.creator.displayName ?? collab.creator.handle ?? "the creator"} was resent.`);

  return ok({ id: updated.id, status: updated.status });
}
