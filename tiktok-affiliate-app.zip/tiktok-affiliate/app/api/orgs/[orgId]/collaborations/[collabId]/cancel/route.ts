import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; collabId: string }> };

/** Cancel a collaboration invitation (capability-gated). */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, collabId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const collab = await prisma.collaboration.findFirst({
    where: { id: collabId, organizationId: orgId },
    include: { campaign: { include: { shop: true } }, creator: true },
  });
  if (!collab) return fail("not_found", "Collaboration not found.", 404);
  if (["completed", "cancelled"].includes(collab.status)) {
    return fail("invalid_state", `This invitation is already "${collab.status}".`, 400);
  }

  const shop = await getOrgShop(orgId, collab.campaign.shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);
  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const caps = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  if (!hasCapability(caps, CAP.creatorInviteCancel)) {
    return fail(
      "capability_unavailable",
      "Cancelling invitations is not available for this shop with its current TikTok approval and scopes."
    );
  }

  const isDemo = shop.mode === "demo";
  if (!isDemo && collab.tiktokInviteId) {
    try {
      const provider = await getShopProvider(shop.id);
      await provider.cancelInvitation(collab.tiktokInviteId);
    } catch (e) {
      const mapped = mapTikTokError(e);
      return fail(mapped.code, mapped.message, mapped.status, mapped.fieldErrors);
    }
  }

  const updated = await prisma.collaboration.update({
    where: { id: collab.id },
    data: { status: "cancelled", lastError: null },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "collab.cancelled",
    entityType: "Collaboration",
    entityId: collab.id,
    details: { demo: isDemo },
    ip: clientIp(req),
  });

  await notify(
    orgId,
    "invite_status",
    "Invitation cancelled",
    `The invitation to ${collab.creator.displayName ?? collab.creator.handle ?? "the creator"} for "${collab.campaign.name}" was cancelled.`
  );

  return ok({ id: updated.id, status: updated.status });
}
