import { NextRequest } from "next/server";
import { randomBytes } from "crypto";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit } from "@/lib/audit";
import { config } from "@/lib/config";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; invId: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, invId } = await params;
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const invitation = await prisma.invitation.findFirst({
    where: { id: invId, organizationId: orgId },
  });
  if (!invitation) return fail("not_found", "Invitation not found.", 404);
  if (invitation.status !== "pending") {
    return fail("invalid_state", "Only pending invitations can be resent.", 400);
  }

  const updated = await prisma.invitation.update({
    where: { id: invitation.id },
    data: {
      token: randomBytes(32).toString("hex"),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "team.invitation_resent",
    entityType: "Invitation",
    entityId: invitation.id,
    details: { email: invitation.email },
    ip: clientIp(req),
  });

  return ok({
    id: updated.id,
    email: updated.email,
    role: updated.role,
    status: updated.status,
    expiresAt: updated.expiresAt,
    token: updated.token,
    inviteUrl: `${config.appUrl}/invite?token=${updated.token}`,
  });
}
