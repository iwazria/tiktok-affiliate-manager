import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; invId: string }> };

export async function DELETE(req: NextRequest, { params }: Params) {
  const { orgId, invId } = await params;
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const invitation = await prisma.invitation.findFirst({
    where: { id: invId, organizationId: orgId },
  });
  if (!invitation) return fail("not_found", "Invitation not found.", 404);
  if (invitation.status !== "pending") {
    return fail("invalid_state", "Only pending invitations can be revoked.", 400);
  }

  await prisma.invitation.update({
    where: { id: invitation.id },
    data: { status: "revoked" },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "team.invitation_revoked",
    entityType: "Invitation",
    entityId: invitation.id,
    details: { email: invitation.email },
    ip: clientIp(req),
  });

  return ok({ revoked: true });
}
