import { NextRequest } from "next/server";
import { z } from "zod";
import { randomBytes } from "crypto";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { ROLES, rateLimit } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { config } from "@/lib/config";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

const inviteSchema = z.object({
  email: z.string().email("Enter a valid email").max(255),
  role: z.enum(ROLES as [string, ...string[]], {
    errorMap: () => ({ message: "Invalid role." }),
  }),
});

function publicInvite(inv: {
  id: string;
  email: string;
  role: string;
  status: string;
  expiresAt: Date;
  createdAt: Date;
}) {
  return {
    id: inv.id,
    email: inv.email,
    role: inv.role,
    status: inv.status,
    expiresAt: inv.expiresAt,
    createdAt: inv.createdAt,
  };
}

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const invitations = await prisma.invitation.findMany({
    where: { organizationId: orgId },
    orderBy: { createdAt: "desc" },
  });
  return ok(invitations.map(publicInvite));
}

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user, ctx } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const ip = clientIp(req) ?? "unknown";
  if (!rateLimit(`invite:${orgId}:${ip}`, 10, 60_000)) {
    return fail("rate_limited", "Too many invitations. Please try again in a minute.", 429);
  }

  const { error: bodyError, data } = await parseJson(req, inviteSchema);
  if (bodyError) return bodyError;

  // Only owners can invite new owners.
  if (data.role === "owner" && ctx.role !== "owner") {
    return fail("forbidden", "Only organization owners can invite another owner.", 403);
  }

  const email = data.email.toLowerCase().trim();

  // Prevent duplicate pending invites for the same email.
  const duplicate = await prisma.invitation.findFirst({
    where: { organizationId: orgId, email, status: "pending" },
  });
  if (duplicate) {
    return fail("duplicate_invite", "A pending invitation already exists for this email.", 409);
  }

  // Don't invite someone who is already a member.
  const existingMember = await prisma.organizationMember.findFirst({
    where: {
      organizationId: orgId,
      user: { email },
    },
  });
  if (existingMember) {
    return fail("already_member", "This person is already a member of the organization.", 409);
  }

  const invitation = await prisma.invitation.create({
    data: {
      organizationId: orgId,
      email,
      role: data.role,
      token: randomBytes(32).toString("hex"),
      invitedById: user.id,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "team.invited",
    entityType: "Invitation",
    entityId: invitation.id,
    details: { email, role: data.role },
    ip: clientIp(req),
  });

  // In demo mode there is no email provider; return the token so the UI can
  // show a copyable invite link. A real deployment sends this by email.
  return ok(
    {
      ...publicInvite(invitation),
      token: invitation.token,
      inviteUrl: `${config.appUrl}/invite?token=${invitation.token}`,
    },
    201
  );
}
