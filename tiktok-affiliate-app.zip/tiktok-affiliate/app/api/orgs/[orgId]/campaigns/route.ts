import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson, zodFail } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { orgContext, parsePagination, clientIp } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string }> };

const listQuerySchema = z.object({
  status: z.string().max(50).optional(),
  search: z.string().max(200).optional(),
  page: z.string().optional(),
  pageSize: z.string().optional(),
});

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const parsed = listQuerySchema.safeParse(
    Object.fromEntries(req.nextUrl.searchParams.entries())
  );
  if (!parsed.success) return zodFail(parsed.error);
  const q = parsed.data;
  const { page, pageSize, skip } = parsePagination(req.nextUrl.searchParams);

  const where = {
    organizationId: orgId,
    ...(q.status ? { status: q.status } : {}),
    ...(q.search ? { name: { contains: q.search } } : {}),
  };

  const [campaigns, total] = await Promise.all([
    prisma.campaign.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      skip,
      take: pageSize,
      include: {
        _count: { select: { products: true } },
        collabs: { select: { status: true } },
        shop: { select: { id: true, shopName: true, mode: true } },
      },
    }),
    prisma.campaign.count({ where }),
  ]);

  return ok({
    items: campaigns.map((c) => ({
      id: c.id,
      name: c.name,
      status: c.status,
      tiktokCampaignId: c.tiktokCampaignId,
      isLive: !!c.tiktokCampaignId,
      commissionRate: c.commissionRate,
      commissionType: c.commissionType,
      startAt: c.startAt,
      endAt: c.endAt,
      productCount: c._count.products,
      collaborationCounts: c.collabs.reduce<Record<string, number>>((acc, k) => {
        acc[k.status] = (acc[k.status] ?? 0) + 1;
        return acc;
      }, {}),
      isDemo: c.isDemo,
      lastError: c.lastError,
      updatedAt: c.updatedAt,
      shop: c.shop,
    })),
    page,
    pageSize,
    total,
    totalPages: Math.ceil(total / pageSize),
  });
}

const createCampaignSchema = z
  .object({
    name: z.string().min(1, "Campaign name is required").max(200),
    description: z.string().max(2000).optional(),
    productIds: z.array(z.string().min(1)).min(1, "Select at least one product").max(100),
    commissionRate: z.number().min(0).max(100).optional(),
    commissionType: z.string().max(50).optional(),
    startAt: z.coerce.date().optional(),
    endAt: z.coerce.date().optional(),
    collaborationType: z.enum(["open", "targeted"]).optional(),
    sampleAvailable: z.boolean().optional(),
    targetingNotes: z.string().max(2000).optional(),
  })
  .refine((v) => !v.startAt || !v.endAt || v.endAt > v.startAt, {
    message: "End date must be after start date.",
    path: ["endAt"],
  });

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, createCampaignSchema);
  if (bodyError) return bodyError;

  // Products must exist, belong to this org, be affiliate-eligible, and all
  // come from the same shop (a campaign is created per shop).
  const products = await prisma.product.findMany({
    where: { id: { in: data.productIds }, organizationId: orgId },
    include: { shop: true },
  });
  if (products.length !== data.productIds.length) {
    return fail("validation_error", "One or more selected products were not found.", 422, {
      productIds: ["One or more selected products were not found."],
    });
  }
  const ineligible = products.filter((p) => !p.affiliateEligible);
  if (ineligible.length > 0) {
    return fail(
      "validation_error",
      "Some selected products are not eligible for affiliate collaboration.",
      422,
      {
        productIds: ineligible.map(
          (p) => `${p.name}: ${p.ineligibilityReason ?? "not eligible"}`
        ),
      }
    );
  }
  const shopIds = new Set(products.map((p) => p.shopId));
  if (shopIds.size !== 1) {
    return fail("validation_error", "All products in a campaign must come from the same shop.", 422, {
      productIds: ["Select products from a single shop."],
    });
  }
  const shop = products[0].shop;

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const capabilities = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  if (!hasCapability(capabilities, CAP.campaignCreate)) {
    return fail(
      "capability_unavailable",
      "Creating campaigns is not available for this shop with its current TikTok approval and scopes."
    );
  }

  // Create on TikTok Shop first when live; keep a local draft otherwise.
  let tiktokCampaignId: string | null = null;
  const isLive = shop.mode === "live";
  if (isLive) {
    try {
      const provider = await getShopProvider(shop.id);
      const created = await provider.createCampaign({
        name: data.name,
        description: data.description,
        productIds: products.map((p) => p.tiktokProductId),
        commissionRate: data.commissionRate,
        commissionType:
          data.commissionType === "percentage" || data.commissionType === "fixed"
            ? data.commissionType
            : undefined,
        startAt: data.startAt?.toISOString(),
        endAt: data.endAt?.toISOString(),
        collaborationType: data.collaborationType,
        sampleAvailable: data.sampleAvailable,
        targetingNotes: data.targetingNotes,
      });
      tiktokCampaignId = created.tiktokCampaignId;
    } catch (e) {
      const mapped = mapTikTokError(e);
      return fail(mapped.code, mapped.message, mapped.status, mapped.fieldErrors);
    }
  }

  const campaign = await prisma.$transaction(async (tx) => {
    const c = await tx.campaign.create({
      data: {
        organizationId: orgId,
        shopId: shop.id,
        tiktokCampaignId,
        name: data.name.trim(),
        description: data.description?.trim() || null,
        status: "draft",
        commissionRate: data.commissionRate ?? null,
        commissionType: data.commissionType ?? null,
        startAt: data.startAt ?? null,
        endAt: data.endAt ?? null,
        collaborationType: data.collaborationType ?? null,
        sampleAvailable: data.sampleAvailable ?? false,
        targetingNotes: data.targetingNotes?.trim() || null,
        isDemo: shop.mode === "demo",
        createdById: user.id,
      },
    });
    await tx.campaignProduct.createMany({
      data: data.productIds.map((productId) => ({ campaignId: c.id, productId })),
    });
    return c;
  });

  await prisma.onboardingState.upsert({
    where: { organizationId: orgId },
    update: { firstCampaign: true },
    create: { organizationId: orgId, firstCampaign: true },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "campaign.created",
    entityType: "Campaign",
    entityId: campaign.id,
    details: {
      name: data.name,
      shopId: shop.id,
      tiktokCampaignId,
      productCount: data.productIds.length,
      live: isLive,
    },
    ip: clientIp(req),
  });

  await notify(
    orgId,
    "campaign_changed",
    "Campaign created",
    `"${data.name}" was created${isLive ? " on TikTok Shop" : " as a local draft"}.`
  );

  return ok(
    {
      id: campaign.id,
      tiktokCampaignId,
      isLive,
      status: campaign.status,
    },
    201
  );
}
