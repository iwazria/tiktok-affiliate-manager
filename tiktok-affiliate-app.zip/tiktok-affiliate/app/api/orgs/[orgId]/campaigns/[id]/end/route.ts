import { lifecycleHandler } from "../_lifecycle";

export const POST = lifecycleHandler("end");
