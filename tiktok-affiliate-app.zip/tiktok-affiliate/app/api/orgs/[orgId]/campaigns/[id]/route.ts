import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
  LIVE_EDITABLE_CAMPAIGN_FIELDS,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; id: string }> };

async function loadCampaign(orgId: string, id: string) {
  return prisma.campaign.findFirst({
    where: { id, organizationId: orgId },
    include: {
      products: { include: { product: true } },
      collabs: { include: { creator: true } },
      shop: true,
    },
  });
}

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, id } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const campaign = await loadCampaign(orgId, id);
  if (!campaign) return fail("not_found", "Campaign not found.", 404);

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: campaign.shopId } });
  const capabilities = await getShopCapabilities(
    campaign.shop,
    scopes.map((s) => s.scope)
  );

  return ok({
    campaign: {
      id: campaign.id,
      name: campaign.name,
      description: campaign.description,
      status: campaign.status,
      tiktokCampaignId: campaign.tiktokCampaignId,
      isLive: !!campaign.tiktokCampaignId,
      commissionRate: campaign.commissionRate,
      commissionType: campaign.commissionType,
      startAt: campaign.startAt,
      endAt: campaign.endAt,
      collaborationType: campaign.collaborationType,
      sampleAvailable: campaign.sampleAvailable,
      targetingNotes: campaign.targetingNotes,
      isDemo: campaign.isDemo,
      lastError: campaign.lastError,
      lastSyncedAt: campaign.lastSyncedAt,
      createdAt: campaign.createdAt,
      updatedAt: campaign.updatedAt,
      shop: {
        id: campaign.shop.id,
        shopName: campaign.shop.shopName,
        mode: campaign.shop.mode,
        status: campaign.shop.status,
      },
      products: campaign.products.map((cp) => ({
        id: cp.product.id,
        tiktokProductId: cp.product.tiktokProductId,
        name: cp.product.name,
        imageUrl: cp.product.imageUrl,
        price: cp.product.price,
        currency: cp.product.currency,
        affiliateEligible: cp.product.affiliateEligible,
      })),
      collaborations: campaign.collabs.map((c) => ({
        id: c.id,
        status: c.status,
        tiktokInviteId: c.tiktokInviteId,
        invitedAt: c.invitedAt,
        respondedAt: c.respondedAt,
        creator: {
          id: c.creator.id,
          handle: c.creator.handle,
          displayName: c.creator.displayName,
          avatarUrl: c.creator.avatarUrl,
          followerCount: c.creator.followerCount,
        },
      })),
    },
    capabilities,
  });
}

const patchCampaignSchema = z
  .object({
    name: z.string().min(1).max(200).optional(),
    description: z.string().max(2000).nullable().optional(),
    productIds: z.array(z.string().min(1)).min(1).max(100).optional(),
    commissionRate: z.number().min(0).max(100).nullable().optional(),
    commissionType: z.string().max(50).nullable().optional(),
    startAt: z.coerce.date().nullable().optional(),
    endAt: z.coerce.date().nullable().optional(),
    collaborationType: z.enum(["open", "targeted"]).nullable().optional(),
    sampleAvailable: z.boolean().optional(),
    targetingNotes: z.string().max(2000).nullable().optional(),
  })
  .refine((v) => !v.startAt || !v.endAt || v.endAt > v.startAt, {
    message: "End date must be after start date.",
    path: ["endAt"],
  });

export async function PATCH(req: NextRequest, { params }: Params) {
  const { orgId, id } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, patchCampaignSchema);
  if (bodyError) return bodyError;

  const campaign = await loadCampaign(orgId, id);
  if (!campaign) return fail("not_found", "Campaign not found.", 404);
  if (["ended", "archived"].includes(campaign.status)) {
    return fail("invalid_state", `Ended or archived campaigns cannot be edited.`, 400);
  }

  const shop = await getOrgShop(orgId, campaign.shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const capabilities = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );

  const isLiveCampaign = !!campaign.tiktokCampaignId && shop.mode === "live";
  const changedFields = Object.keys(data);

  if (isLiveCampaign) {
    if (!hasCapability(capabilities, CAP.campaignEdit)) {
      return fail(
        "capability_unavailable",
        "Editing live campaigns is not available for this shop with its current TikTok approval and scopes."
      );
    }
    const disallowed = changedFields.filter(
      (f) => !(LIVE_EDITABLE_CAMPAIGN_FIELDS as readonly string[]).includes(f)
    );
    if (disallowed.length > 0) {
      const fieldErrors: Record<string, string[]> = {};
      for (const f of disallowed) {
        fieldErrors[f] = ["This field cannot be edited on a campaign that exists on TikTok Shop."];
      }
      return fail(
        "validation_error",
        "Some fields cannot be edited on a live TikTok Shop campaign.",
        422,
        fieldErrors
      );
    }
  }

  // Validate replacement product list (drafts only; live campaigns keep products).
  if (data.productIds) {
    if (isLiveCampaign) {
      return fail("validation_error", "Products cannot be changed on a live campaign.", 422, {
        productIds: ["Products cannot be changed on a live TikTok Shop campaign."],
      });
    }
    const products = await prisma.product.findMany({
      where: { id: { in: data.productIds }, organizationId: orgId, shopId: shop.id },
    });
    if (products.length !== data.productIds.length) {
      return fail("validation_error", "One or more selected products were not found.", 422, {
        productIds: ["One or more selected products were not found."],
      });
    }
    const ineligible = products.filter((p) => !p.affiliateEligible);
    if (ineligible.length > 0) {
      return fail("validation_error", "Some selected products are not affiliate-eligible.", 422, {
        productIds: ineligible.map((p) => `${p.name}: not eligible`),
      });
    }
  }

  // Push editable fields to TikTok Shop when live.
  if (isLiveCampaign && campaign.tiktokCampaignId) {
    const liveUpdate: Record<string, unknown> = {};
    if (data.name !== undefined) liveUpdate.name = data.name.trim();
    if (data.description !== undefined) liveUpdate.description = data.description;
    if (data.endAt !== undefined) liveUpdate.endAt = data.endAt?.toISOString() ?? null;
    if (data.commissionRate !== undefined) liveUpdate.commissionRate = data.commissionRate;
    if (Object.keys(liveUpdate).length > 0) {
      try {
        const provider = await getShopProvider(shop.id);
        await provider.updateCampaign(campaign.tiktokCampaignId, {
          ...(liveUpdate.name !== undefined ? { name: liveUpdate.name as string } : {}),
          ...(liveUpdate.description !== undefined
            ? { description: liveUpdate.description as string | null }
            : {}),
          ...(liveUpdate.endAt !== undefined ? { endAt: liveUpdate.endAt as string | null } : {}),
          ...(liveUpdate.commissionRate !== undefined
            ? { commissionRate: liveUpdate.commissionRate as number | null }
            : {}),
        });
      } catch (e) {
        const mapped = mapTikTokError(e);
        await prisma.campaign.update({
          where: { id: campaign.id },
          data: { lastError: mapped.message.slice(0, 500) },
        });
        return fail(mapped.code, mapped.message, mapped.status, mapped.fieldErrors);
      }
    }
  }

  const updated = await prisma.$transaction(async (tx) => {
    const c = await tx.campaign.update({
      where: { id: campaign.id },
      data: {
        ...(data.name !== undefined ? { name: data.name.trim() } : {}),
        ...(data.description !== undefined ? { description: data.description?.trim() || null } : {}),
        ...(data.commissionRate !== undefined ? { commissionRate: data.commissionRate } : {}),
        ...(data.commissionType !== undefined ? { commissionType: data.commissionType } : {}),
        ...(data.startAt !== undefined ? { startAt: data.startAt } : {}),
        ...(data.endAt !== undefined ? { endAt: data.endAt } : {}),
        ...(data.collaborationType !== undefined ? { collaborationType: data.collaborationType } : {}),
        ...(data.sampleAvailable !== undefined ? { sampleAvailable: data.sampleAvailable } : {}),
        ...(data.targetingNotes !== undefined
          ? { targetingNotes: data.targetingNotes?.trim() || null }
          : {}),
        lastError: null,
      },
    });
    if (data.productIds) {
      await tx.campaignProduct.deleteMany({ where: { campaignId: campaign.id } });
      await tx.campaignProduct.createMany({
        data: data.productIds.map((productId) => ({ campaignId: campaign.id, productId })),
      });
    }
    return c;
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "campaign.updated",
    entityType: "Campaign",
    entityId: campaign.id,
    details: { changedFields, live: isLiveCampaign },
    ip: clientIp(req),
  });

  return ok({ id: updated.id, status: updated.status, updatedAt: updated.updatedAt });
}
