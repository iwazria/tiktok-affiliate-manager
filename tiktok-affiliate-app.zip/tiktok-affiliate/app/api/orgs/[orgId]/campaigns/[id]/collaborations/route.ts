import { NextRequest } from "next/server";
import { z } from "zod";
import { randomBytes } from "crypto";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

type Params = { params: Promise<{ orgId: string; id: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, id: campaignId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const campaign = await prisma.campaign.findFirst({
    where: { id: campaignId, organizationId: orgId },
  });
  if (!campaign) return fail("not_found", "Campaign not found.", 404);

  const collabs = await prisma.collaboration.findMany({
    where: { campaignId: campaign.id, organizationId: orgId },
    include: {
      creator: {
        select: {
          id: true,
          handle: true,
          displayName: true,
          avatarUrl: true,
          followerCount: true,
          source: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return ok(
    collabs.map((c) => ({
      id: c.id,
      status: c.status,
      tiktokInviteId: c.tiktokInviteId,
      invitedAt: c.invitedAt,
      respondedAt: c.respondedAt,
      lastError: c.lastError,
      isDemo: c.isDemo,
      creator: c.creator,
    }))
  );
}

const inviteSchema = z.object({
  creatorId: z.string().min(1, "creatorId is required"),
});

/**
 * Invite a creator to a targeted collaboration on a campaign.
 * Requires the creator_invite capability; duplicate (campaign, creator)
 * invitations are rejected with 409.
 */
export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, id: campaignId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, inviteSchema);
  if (bodyError) return bodyError;

  const campaign = await prisma.campaign.findFirst({
    where: { id: campaignId, organizationId: orgId },
    include: { shop: true },
  });
  if (!campaign) return fail("not_found", "Campaign not found.", 404);
  if (["ended", "archived"].includes(campaign.status)) {
    return fail("invalid_state", "Cannot invite creators to an ended or archived campaign.", 400);
  }

  const creator = await prisma.creator.findFirst({
    where: { id: data.creatorId, organizationId: orgId },
  });
  if (!creator) return fail("not_found", "Creator not found.", 404);

  const duplicate = await prisma.collaboration.findUnique({
    where: { campaignId_creatorId: { campaignId: campaign.id, creatorId: creator.id } },
  });
  if (duplicate) {
    return fail(
      "duplicate_invitation",
      "This creator has already been invited to this campaign.",
      409
    );
  }

  const shop = await getOrgShop(orgId, campaign.shopId);
  if (!shop) return fail("not_found", "Shop not found.", 404);

  const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
  const capabilities = await getShopCapabilities(
    shop,
    scopes.map((s) => s.scope)
  );
  if (!hasCapability(capabilities, CAP.creatorInvite)) {
    return fail(
      "capability_unavailable",
      "Inviting creators is not available for this shop with its current TikTok approval and scopes. You can still track this creator manually."
    );
  }

  const isDemo = shop.mode === "demo";
  let tiktokInviteId: string | null = null;
  let status = "sent";

  if (!isDemo && campaign.tiktokCampaignId) {
    if (!creator.tiktokCreatorId) {
      return fail(
        "missing_creator_id",
        "This creator has no TikTok creator ID. Creator discovery requires additional TikTok approval.",
        422,
        { creatorId: ["No TikTok creator ID on this creator record."] }
      );
    }
    try {
      const provider = await getShopProvider(shop.id);
      const campaignProducts = await prisma.campaignProduct.findMany({
        where: { campaignId: campaign.id },
        include: { product: { select: { tiktokProductId: true } } },
      });
      const invited = await provider.inviteCreator(campaign.tiktokCampaignId, {
        creatorRef: { tiktokCreatorId: creator.tiktokCreatorId ?? undefined },
        productIds: campaignProducts.map((cp) => cp.product.tiktokProductId),
      });
      tiktokInviteId = invited.tiktokInviteId ?? invited.id;
    } catch (e) {
      const mapped = mapTikTokError(e);
      return fail(mapped.code, mapped.message, mapped.status, mapped.fieldErrors);
    }
  } else {
    // Demo mode (or local draft campaign): simulate the invitation, labeled demo.
    tiktokInviteId = `demo-inv-${randomBytes(6).toString("hex")}`;
    status = "sent";
  }

  const collab = await prisma.collaboration.create({
    data: {
      organizationId: orgId,
      campaignId: campaign.id,
      creatorId: creator.id,
      tiktokInviteId,
      status,
      invitedAt: new Date(),
      isDemo,
      createdById: user.id,
    },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "collab.invited",
    entityType: "Collaboration",
    entityId: collab.id,
    details: {
      campaignId: campaign.id,
      creatorId: creator.id,
      tiktokInviteId,
      demo: isDemo,
    },
    ip: clientIp(req),
  });

  await notify(
    orgId,
    "invite_status",
    "Creator invitation sent",
    `${creator.displayName ?? creator.handle ?? "A creator"} was invited to "${campaign.name}"${
      isDemo ? " (simulated in demo mode)" : ""
    }.`
  );

  return ok({ id: collab.id, status: collab.status, isDemo }, 201);
}
