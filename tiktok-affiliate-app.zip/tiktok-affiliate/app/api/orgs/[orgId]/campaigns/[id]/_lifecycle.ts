import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { orgContext, getOrgShop, clientIp } from "@/app/api/_lib/org";
import {
  getShopCapabilities,
  getShopProvider,
  hasCapability,
  mapTikTokError,
  CAP,
} from "@/app/api/_lib/tiktok";

/**
 * Shared lifecycle-action factory for pause | resume | end | archive.
 * end/archive are destructive → require { confirm: true } in the body.
 */
const LIFECYCLE = {
  pause: { to: "paused", cap: CAP.campaignPause, label: "paused", destructive: false },
  resume: { to: "active", cap: CAP.campaignResume, label: "resumed", destructive: false },
  end: { to: "ended", cap: CAP.campaignEnd, label: "ended", destructive: true },
  archive: { to: "archived", cap: CAP.campaignArchive, label: "archived", destructive: true },
} as const;

type Action = keyof typeof LIFECYCLE;

const confirmSchema = z.object({
  confirm: z.literal(true, {
    errorMap: () => ({ message: "Confirmation is required for this action." }),
  }),
});

/** Build the POST handler for a lifecycle action. */
export function lifecycleHandler(action: Action) {
  const def = LIFECYCLE[action];
  return async function (
    req: NextRequest,
    { params }: { params: Promise<{ orgId: string; id: string }> }
  ) {
    const { orgId, id } = await params;
    const { error, user } = await orgContext(req, orgId, "campaign_manager");
    if (error) return error;

    if (def.destructive) {
      const { error: bodyError } = await parseJson(req, confirmSchema);
      if (bodyError) return bodyError;
    }

    const campaign = await prisma.campaign.findFirst({
      where: { id, organizationId: orgId },
      include: { shop: true },
    });
    if (!campaign) return fail("not_found", "Campaign not found.", 404);
    if (campaign.status === def.to) {
      return ok({ id: campaign.id, status: campaign.status, unchanged: true });
    }

    const shop = await getOrgShop(orgId, campaign.shopId);
    if (!shop) return fail("not_found", "Shop not found.", 404);

    const scopes = await prisma.grantedScope.findMany({ where: { shopId: shop.id } });
    const capabilities = await getShopCapabilities(
      shop,
      scopes.map((s) => s.scope)
    );
    if (!hasCapability(capabilities, def.cap)) {
      return fail(
        "capability_unavailable",
        `The "${action}" action is not available for this shop with its current TikTok approval and scopes.`
      );
    }

    // Mirror the state change on TikTok Shop when the campaign lives there.
    const isLiveCampaign = !!campaign.tiktokCampaignId && shop.mode === "live";
    if (isLiveCampaign && campaign.tiktokCampaignId) {
      try {
        const provider = await getShopProvider(shop.id);
        await provider.setCampaignStatus(campaign.tiktokCampaignId, def.to);
      } catch (e) {
        const mapped = mapTikTokError(e);
        await prisma.campaign.update({
          where: { id: campaign.id },
          data: { lastError: mapped.message.slice(0, 500) },
        });
        return fail(mapped.code, mapped.message, mapped.status, mapped.fieldErrors);
      }
    }

    const updated = await prisma.campaign.update({
      where: { id: campaign.id },
      data: { status: def.to, lastError: null },
    });

    await audit({
      organizationId: orgId,
      actorId: user.id,
      action: "campaign.status_changed",
      entityType: "Campaign",
      entityId: campaign.id,
      details: { action, from: campaign.status, to: def.to, live: isLiveCampaign },
      ip: clientIp(req),
    });

    await notify(
      orgId,
      "campaign_changed",
      `Campaign ${def.label}`,
      `"${campaign.name}" was ${def.label}.`
    );

    return ok({ id: updated.id, status: updated.status });
  };
}
