import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { ROLES } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; memberId: string }> };

const roleSchema = z.object({
  role: z.enum(ROLES as [string, ...string[]], {
    errorMap: () => ({ message: "Invalid role." }),
  }),
});

async function loadMember(orgId: string, memberId: string) {
  return prisma.organizationMember.findFirst({
    where: { id: memberId, organizationId: orgId },
    include: { user: { select: { id: true, name: true, email: true } } },
  });
}

async function ownerCount(orgId: string) {
  return prisma.organizationMember.count({
    where: { organizationId: orgId, role: "owner", status: "active" },
  });
}

export async function PATCH(req: NextRequest, { params }: Params) {
  const { orgId, memberId } = await params;
  const { error, user, ctx } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, roleSchema);
  if (bodyError) return bodyError;

  const member = await loadMember(orgId, memberId);
  if (!member) return fail("not_found", "Member not found.", 404);

  // Admins cannot touch owners in either direction.
  if (ctx.role === "admin" && (member.role === "owner" || data.role === "owner")) {
    return fail("forbidden", "Only organization owners can manage owner roles.", 403);
  }
  // Never demote the last owner.
  if (member.role === "owner" && data.role !== "owner" && (await ownerCount(orgId)) <= 1) {
    return fail("last_owner", "You cannot demote the last organization owner.", 400);
  }
  if (member.role === data.role) {
    return ok({ id: member.id, role: member.role });
  }

  const updated = await prisma.organizationMember.update({
    where: { id: member.id },
    data: { role: data.role },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "team.role_changed",
    entityType: "OrganizationMember",
    entityId: member.id,
    details: { email: member.user.email, from: member.role, to: data.role },
    ip: clientIp(req),
  });

  return ok({ id: updated.id, role: updated.role });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const { orgId, memberId } = await params;
  const { error, user, ctx } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const member = await loadMember(orgId, memberId);
  if (!member) return fail("not_found", "Member not found.", 404);

  if (ctx.role === "admin" && member.role === "owner") {
    return fail("forbidden", "Only organization owners can remove an owner.", 403);
  }
  // Never remove the last owner (covers "cannot remove self if last owner").
  if (member.role === "owner" && (await ownerCount(orgId)) <= 1) {
    return fail("last_owner", "You cannot remove the last organization owner.", 400);
  }

  await prisma.organizationMember.delete({ where: { id: member.id } });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "team.member_removed",
    entityType: "OrganizationMember",
    entityId: member.id,
    details: { email: member.user.email, role: member.role },
    ip: clientIp(req),
  });

  return ok({ removed: true });
}
