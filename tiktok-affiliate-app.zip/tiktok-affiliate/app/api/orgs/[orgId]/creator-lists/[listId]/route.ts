import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; listId: string }> };

async function loadList(orgId: string, listId: string) {
  return prisma.creatorList.findFirst({
    where: { id: listId, organizationId: orgId },
    include: {
      members: {
        include: {
          creator: {
            select: { id: true, handle: true, displayName: true, followerCount: true },
          },
        },
      },
    },
  });
}

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId, listId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const list = await loadList(orgId, listId);
  if (!list) return fail("not_found", "Creator list not found.", 404);

  return ok({
    id: list.id,
    name: list.name,
    members: list.members.map((m) => m.creator),
  });
}

const renameSchema = z.object({
  name: z.string().min(1, "List name is required").max(100),
});

export async function PATCH(req: NextRequest, { params }: Params) {
  const { orgId, listId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, renameSchema);
  if (bodyError) return bodyError;

  const list = await prisma.creatorList.findFirst({
    where: { id: listId, organizationId: orgId },
  });
  if (!list) return fail("not_found", "Creator list not found.", 404);

  const name = data.name.trim();
  const duplicate = await prisma.creatorList.findUnique({
    where: { organizationId_name: { organizationId: orgId, name } },
  });
  if (duplicate && duplicate.id !== list.id) {
    return fail("duplicate_list", "A list with this name already exists.", 409);
  }

  const updated = await prisma.creatorList.update({
    where: { id: list.id },
    data: { name },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator_list.renamed",
    entityType: "CreatorList",
    entityId: list.id,
    details: { from: list.name, to: name },
    ip: clientIp(req),
  });

  return ok({ id: updated.id, name: updated.name });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const { orgId, listId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const list = await prisma.creatorList.findFirst({
    where: { id: listId, organizationId: orgId },
  });
  if (!list) return fail("not_found", "Creator list not found.", 404);

  await prisma.creatorList.delete({ where: { id: list.id } });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator_list.deleted",
    entityType: "CreatorList",
    entityId: listId,
    details: { name: list.name },
    ip: clientIp(req),
  });

  return ok({ deleted: true });
}
