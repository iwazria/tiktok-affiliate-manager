import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; listId: string }> };

const memberSchema = z.object({
  creatorId: z.string().min(1, "creatorId is required"),
});

async function loadList(orgId: string, listId: string) {
  return prisma.creatorList.findFirst({ where: { id: listId, organizationId: orgId } });
}

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, listId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, memberSchema);
  if (bodyError) return bodyError;

  const list = await loadList(orgId, listId);
  if (!list) return fail("not_found", "Creator list not found.", 404);

  const creator = await prisma.creator.findFirst({
    where: { id: data.creatorId, organizationId: orgId },
  });
  if (!creator) return fail("not_found", "Creator not found.", 404);

  const existing = await prisma.creatorListMembership.findUnique({
    where: { listId_creatorId: { listId: list.id, creatorId: creator.id } },
  });
  if (existing) {
    return fail("duplicate_membership", "Creator is already in this list.", 409);
  }

  await prisma.creatorListMembership.create({
    data: { listId: list.id, creatorId: creator.id },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator_list.member_added",
    entityType: "CreatorList",
    entityId: list.id,
    details: { creatorId: creator.id },
    ip: clientIp(req),
  });

  return ok({ added: true }, 201);
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const { orgId, listId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, memberSchema);
  if (bodyError) return bodyError;

  const list = await loadList(orgId, listId);
  if (!list) return fail("not_found", "Creator list not found.", 404);

  const deleted = await prisma.creatorListMembership.deleteMany({
    where: { listId: list.id, creatorId: data.creatorId },
  });
  if (deleted.count === 0) {
    return fail("not_found", "Creator is not in this list.", 404);
  }

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator_list.member_removed",
    entityType: "CreatorList",
    entityId: list.id,
    details: { creatorId: data.creatorId },
    ip: clientIp(req),
  });

  return ok({ removed: true });
}
