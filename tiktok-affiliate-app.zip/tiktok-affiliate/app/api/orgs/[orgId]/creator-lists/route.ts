import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error } = await orgContext(req, orgId, "analyst");
  if (error) return error;

  const lists = await prisma.creatorList.findMany({
    where: { organizationId: orgId },
    orderBy: { createdAt: "asc" },
    include: { _count: { select: { members: true } } },
  });

  return ok(
    lists.map((l) => ({
      id: l.id,
      name: l.name,
      memberCount: l._count.members,
      createdAt: l.createdAt,
    }))
  );
}

const listSchema = z.object({
  name: z.string().min(1, "List name is required").max(100),
});

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "campaign_manager");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, listSchema);
  if (bodyError) return bodyError;

  const name = data.name.trim();
  const duplicate = await prisma.creatorList.findUnique({
    where: { organizationId_name: { organizationId: orgId, name } },
  });
  if (duplicate) {
    return fail("duplicate_list", "A list with this name already exists.", 409);
  }

  const list = await prisma.creatorList.create({
    data: { organizationId: orgId, name, createdById: user.id },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "creator_list.created",
    entityType: "CreatorList",
    entityId: list.id,
    details: { name },
    ip: clientIp(req),
  });

  return ok({ id: list.id, name: list.name }, 201);
}
