import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";
import { isDemoMode } from "@/lib/config";
import { orgContext, clientIp } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, ctx } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const org = await prisma.organization.findUnique({ where: { id: orgId } });
  if (!org) return ok(null);

  const [shopCount, memberCount, onboarding] = await Promise.all([
    prisma.connectedShop.count({ where: { organizationId: orgId } }),
    prisma.organizationMember.count({ where: { organizationId: orgId } }),
    prisma.onboardingState.findUnique({ where: { organizationId: orgId } }),
  ]);

  return ok({
    organization: { id: org.id, name: org.name, slug: org.slug },
    myRole: ctx.role,
    shopCount,
    memberCount,
    demoMode: isDemoMode(),
    onboarding,
    privacy: {
      termsUrl: "/terms",
      privacyUrl: "/privacy",
      supportUrl: "/support",
    },
  });
}

const settingsSchema = z.object({
  name: z.string().min(1, "Organization name is required").max(100),
});

export async function PATCH(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  // owner/admin: "admin" minimum covers owners as well.
  const { error, user } = await orgContext(req, orgId, "admin");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, settingsSchema);
  if (bodyError) return bodyError;

  const org = await prisma.organization.update({
    where: { id: orgId },
    data: { name: data.name.trim() },
  });

  await audit({
    organizationId: orgId,
    actorId: user.id,
    action: "org.settings_updated",
    entityType: "Organization",
    entityId: orgId,
    details: { name: org.name },
    ip: clientIp(req),
  });

  return ok({ id: org.id, name: org.name, slug: org.slug });
}
