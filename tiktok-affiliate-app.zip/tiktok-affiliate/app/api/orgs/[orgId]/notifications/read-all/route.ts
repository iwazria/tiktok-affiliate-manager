import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok } from "@/lib/api";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const updated = await prisma.notification.updateMany({
    where: {
      organizationId: orgId,
      OR: [{ userId: null }, { userId: user.id }],
      readAt: null,
    },
    data: { readAt: new Date() },
  });

  return ok({ markedRead: updated.count });
}
