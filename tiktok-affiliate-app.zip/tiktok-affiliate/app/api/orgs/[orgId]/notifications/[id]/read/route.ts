import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, fail } from "@/lib/api";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string; id: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { orgId, id } = await params;
  const { error, user } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const notification = await prisma.notification.findFirst({
    where: {
      id,
      organizationId: orgId,
      OR: [{ userId: null }, { userId: user.id }],
    },
  });
  if (!notification) return fail("not_found", "Notification not found.", 404);

  await prisma.notification.update({
    where: { id: notification.id },
    data: { readAt: new Date() },
  });

  return ok({ read: true });
}
