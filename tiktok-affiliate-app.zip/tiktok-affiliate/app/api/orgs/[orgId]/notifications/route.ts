import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok } from "@/lib/api";
import { orgContext } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const unreadOnly = req.nextUrl.searchParams.get("unreadOnly") === "true";

  const notifications = await prisma.notification.findMany({
    where: {
      organizationId: orgId,
      OR: [{ userId: null }, { userId: user.id }],
      ...(unreadOnly ? { readAt: null } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const unreadCount = await prisma.notification.count({
    where: {
      organizationId: orgId,
      OR: [{ userId: null }, { userId: user.id }],
      readAt: null,
    },
  });

  return ok({
    items: notifications.map((n) => ({
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body,
      readAt: n.readAt,
      createdAt: n.createdAt,
    })),
    unreadCount,
  });
}
