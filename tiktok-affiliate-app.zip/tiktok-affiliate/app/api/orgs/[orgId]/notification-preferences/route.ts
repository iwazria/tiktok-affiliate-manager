import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { orgContext, NOTIFICATION_TYPES } from "@/app/api/_lib/org";

type Params = { params: Promise<{ orgId: string }> };

/** The signed-in user's own notification preferences. */
export async function GET(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const prefs = await prisma.notificationPreference.findMany({
    where: { organizationId: orgId, userId: user.id },
  });
  const byType = new Map(prefs.map((p) => [p.type, p.enabled]));

  return ok(
    NOTIFICATION_TYPES.map((type) => ({
      type,
      enabled: byType.get(type) ?? true,
    }))
  );
}

const prefSchema = z.object({
  type: z.enum(NOTIFICATION_TYPES as unknown as [string, ...string[]], {
    errorMap: () => ({ message: "Invalid notification type." }),
  }),
  enabled: z.boolean(),
});

export async function PUT(req: NextRequest, { params }: Params) {
  const { orgId } = await params;
  const { error, user } = await orgContext(req, orgId, "read_only");
  if (error) return error;

  const { error: bodyError, data } = await parseJson(req, prefSchema);
  if (bodyError) return bodyError;

  const pref = await prisma.notificationPreference.upsert({
    where: {
      organizationId_userId_type: {
        organizationId: orgId,
        userId: user.id,
        type: data.type,
      },
    },
    update: { enabled: data.enabled },
    create: {
      organizationId: orgId,
      userId: user.id,
      type: data.type,
      enabled: data.enabled,
    },
  });

  return ok({ type: pref.type, enabled: pref.enabled });
}
