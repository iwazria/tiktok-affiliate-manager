import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok } from "@/lib/api";
import { authUser } from "@/app/api/_lib/org";

export async function GET(req: NextRequest) {
  const { error, user } = await authUser(req);
  if (error) return error;

  const memberships = await prisma.organizationMember.findMany({
    where: { userId: user.id, status: "active" },
    include: { organization: { select: { id: true, name: true, slug: true } } },
    orderBy: { createdAt: "asc" },
  });

  return ok({
    user: { id: user.id, email: user.email, name: user.name },
    memberships: memberships.map((m) => ({
      organization: m.organization,
      role: m.role,
    })),
  });
}
