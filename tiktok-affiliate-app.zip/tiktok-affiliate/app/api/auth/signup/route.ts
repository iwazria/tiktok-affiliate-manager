import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { hashPassword, createSession } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { uniqueOrgSlug, clientIp } from "@/app/api/_lib/org";

const signupSchema = z.object({
  name: z.string().min(1, "Name is required").max(100),
  email: z.string().email("Enter a valid email").max(255),
  password: z.string().min(8, "Password must be at least 8 characters").max(128),
});

export async function POST(req: NextRequest) {
  const { error, data } = await parseJson(req, signupSchema);
  if (error) return error;

  const email = data.email.toLowerCase().trim();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return fail("email_exists", "An account with this email already exists.", 409);
  }

  const passwordHash = await hashPassword(data.password);
  const name = data.name.trim();
  const slug = await uniqueOrgSlug(name);
  const orgName = `${name}'s Organization`;

  const user = await prisma.user.create({
    data: {
      email,
      name,
      passwordHash,
      memberships: {
        create: {
          role: "owner",
          status: "active",
          organization: {
            create: {
              name: orgName,
              slug,
              onboarding: { create: {} },
            },
          },
        },
      },
    },
    include: { memberships: { include: { organization: true } } },
  });

  const membership = user.memberships[0];
  await createSession(user.id, {
    ip: clientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  await audit({
    organizationId: membership.organizationId,
    actorId: user.id,
    action: "auth.signup",
    entityType: "User",
    entityId: user.id,
    ip: clientIp(req),
  });

  return ok(
    {
      user: { id: user.id, email: user.email, name: user.name },
      organization: {
        id: membership.organization.id,
        name: membership.organization.name,
        slug: membership.organization.slug,
      },
    },
    201
  );
}
