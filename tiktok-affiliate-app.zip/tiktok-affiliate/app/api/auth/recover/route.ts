import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, parseJson } from "@/lib/api";
import { audit } from "@/lib/audit";

const recoverSchema = z.object({
  email: z.string().email("Enter a valid email").max(255),
});

export async function POST(req: NextRequest) {
  const { error, data } = await parseJson(req, recoverSchema);
  if (error) return error;

  // Always 200 — never reveal whether the email is registered.
  const user = await prisma.user.findUnique({
    where: { email: data.email.toLowerCase().trim() },
    include: {
      memberships: { where: { status: "active" }, select: { organizationId: true } },
    },
  });
  if (user) {
    // Demo mode: no email is actually sent. A real deployment needs an
    // opt-in email provider before recovery emails can go out.
    for (const m of user.memberships) {
      await audit({
        organizationId: m.organizationId,
        actorId: user.id,
        action: "auth.recovery_requested",
        entityType: "User",
        entityId: user.id,
        details: {
          note: "Password recovery requested. Demo mode: no email sent; a configured email provider is required.",
        },
      });
    }
  }

  return ok({
    message: "If an account exists for that email, recovery instructions will be sent.",
  });
}
