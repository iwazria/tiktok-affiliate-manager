import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { verifyPassword, createSession } from "@/lib/auth";
import { rateLimit } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { clientIp } from "@/app/api/_lib/org";

const signinSchema = z.object({
  email: z.string().email("Enter a valid email").max(255),
  password: z.string().min(1, "Password is required").max(128),
});

export async function POST(req: NextRequest) {
  const ip = clientIp(req) ?? "unknown";
  // 5 attempts per minute per IP.
  if (!rateLimit(`login:${ip}`, 5, 60_000)) {
    return fail("rate_limited", "Too many sign-in attempts. Please try again in a minute.", 429);
  }

  const { error, data } = await parseJson(req, signinSchema);
  if (error) return error;

  const email = data.email.toLowerCase().trim();
  const user = await prisma.user.findUnique({ where: { email } });
  const valid = user ? await verifyPassword(data.password, user.passwordHash) : false;
  if (!user || !valid) {
    return fail("invalid_credentials", "Email or password is incorrect.", 401);
  }

  await createSession(user.id, {
    ip: clientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const memberships = await prisma.organizationMember.findMany({
    where: { userId: user.id, status: "active" },
    select: { organizationId: true },
  });
  for (const m of memberships) {
    await audit({
      organizationId: m.organizationId,
      actorId: user.id,
      action: "auth.signin",
      entityType: "User",
      entityId: user.id,
      ip: clientIp(req),
    });
  }

  return ok({ user: { id: user.id, email: user.email, name: user.name } });
}
