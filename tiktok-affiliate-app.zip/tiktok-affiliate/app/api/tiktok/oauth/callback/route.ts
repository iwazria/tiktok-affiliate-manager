import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { audit, notify } from "@/lib/audit";
import { config } from "@/lib/config";
import {
  validateCallback,
  exchangeCodeForTokens,
  storeTokens,
} from "@/app/api/_lib/tiktok";
import { TikTokCapabilityError } from "@/lib/tiktok/errors";

const CALLBACK_ERROR_CODES = new Set([
  "denied",
  "invalid_state",
  "expired_state",
  "exchange_failed",
  "callback_failed",
]);

/**
 * TikTok Shop seller authorization callback.
 *
 * 1. Validates the single-use state (rejects missing/invalid/expired/reused)
 *    and handles user denial.
 * 2. Exchanges the short-lived authorization code server-side.
 * 3. Creates/updates the ConnectedShop, stores tokens encrypted at rest via
 *    storeTokens (which also replaces granted scopes), marks onboarding.
 * 4. Redirects to the shops page with ?connected=1 or ?error=<code>.
 *
 * Shop identity note: the shop-info endpoint is pending TikTok approval, so
 * shop identity is derived from the token response (open_id / seller_name).
 * This is documented in docs/ASSUMPTIONS.md and revisited once approved.
 */
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const redirectBase = `${config.appUrl}/app/shops`;
  const redirectError = (code: string) =>
    NextResponse.redirect(
      `${redirectBase}?error=${encodeURIComponent(
        CALLBACK_ERROR_CODES.has(code) ? code : "callback_failed"
      )}`
    );

  let validated: { organizationId: string; userId: string; code: string };
  try {
    validated = await validateCallback({
      code: sp.get("code"),
      state: sp.get("state"),
      error: sp.get("error"),
      errorDescription: sp.get("error_description"),
    });
  } catch (e) {
    const rawCode =
      e instanceof TikTokCapabilityError
        ? "callback_failed"
        : ((e as { code?: string })?.code ?? "callback_failed");
    // Map integration error codes to our redirect codes.
    const mapped =
      rawCode === "INVALID_STATE"
        ? "invalid_state"
        : rawCode === "denied"
          ? "denied"
          : "callback_failed";
    return redirectError(mapped);
  }

  let tokens;
  try {
    tokens = await exchangeCodeForTokens(validated.code);
  } catch {
    return redirectError("exchange_failed");
  }

  try {
    // Shop identity from the token response (shop-info endpoint pending approval).
    const tiktokShopId = tokens.openId ?? `live-${validated.organizationId.slice(0, 8)}`;
    const shopName = tokens.sellerName ?? null;

    let shop = await prisma.connectedShop.findFirst({
      where: {
        organizationId: validated.organizationId,
        tiktokShopId,
      },
    });
    if (shop) {
      shop = await prisma.connectedShop.update({
        where: { id: shop.id },
        data: {
          shopName: shopName ?? shop.shopName,
          status: "connected",
          mode: "live",
          connectedById: validated.userId,
          disconnectedAt: null,
          lastSyncError: null,
        },
      });
    } else {
      shop = await prisma.connectedShop.create({
        data: {
          organizationId: validated.organizationId,
          tiktokShopId,
          shopName,
          status: "connected",
          mode: "live",
          connectedById: validated.userId,
        },
      });
    }

    // Tokens encrypted at rest inside storeTokens (never plaintext); it also
    // replaces the granted scopes from the token response.
    await storeTokens(shop.id, tokens);

    await prisma.onboardingState.upsert({
      where: { organizationId: validated.organizationId },
      update: { shopConnected: true },
      create: { organizationId: validated.organizationId, shopConnected: true },
    });

    await audit({
      organizationId: validated.organizationId,
      actorId: validated.userId,
      action: "shop.connected",
      entityType: "ConnectedShop",
      entityId: shop.id,
      details: { mode: "live", scopes: tokens.grantedScopes ?? [] },
    });

    await notify(
      validated.organizationId,
      "integration_attention",
      "TikTok Shop connected",
      `${shopName ?? "The shop"} was authorized successfully.`
    );

    return NextResponse.redirect(`${redirectBase}?connected=1`);
  } catch {
    return redirectError("callback_failed");
  }
}
