import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ok, fail, parseJson } from "@/lib/api";
import { audit, notify } from "@/lib/audit";
import { authUser, clientIp } from "@/app/api/_lib/org";

const acceptSchema = z.object({
  token: z.string().min(1, "Invitation token is required"),
});

export async function POST(req: NextRequest) {
  const { error: authError, user } = await authUser(req);
  if (authError) return authError;

  const { error, data } = await parseJson(req, acceptSchema);
  if (error) return error;

  const invitation = await prisma.invitation.findUnique({
    where: { token: data.token },
    include: { organization: { select: { id: true, name: true, slug: true } } },
  });
  if (!invitation) return fail("not_found", "Invitation not found.", 404);
  if (invitation.status !== "pending") {
    return fail("invalid_state", "This invitation is no longer pending.", 410);
  }
  if (invitation.expiresAt < new Date()) {
    await prisma.invitation.update({
      where: { id: invitation.id },
      data: { status: "expired" },
    });
    return fail("expired", "This invitation has expired.", 410);
  }
  // The signed-in user's email must match the invited email.
  if (user.email.toLowerCase() !== invitation.email.toLowerCase()) {
    return fail(
      "email_mismatch",
      "This invitation was sent to a different email address. Sign in with the invited email to accept it.",
      403
    );
  }

  const membership = await prisma.organizationMember.upsert({
    where: {
      organizationId_userId: { organizationId: invitation.organizationId, userId: user.id },
    },
    update: { role: invitation.role, status: "active" },
    create: {
      organizationId: invitation.organizationId,
      userId: user.id,
      role: invitation.role,
      status: "active",
    },
  });

  await prisma.invitation.update({
    where: { id: invitation.id },
    data: { status: "accepted", acceptedAt: new Date() },
  });

  await prisma.onboardingState.upsert({
    where: { organizationId: invitation.organizationId },
    update: { teamInvited: true },
    create: { organizationId: invitation.organizationId, teamInvited: true },
  });

  await audit({
    organizationId: invitation.organizationId,
    actorId: user.id,
    action: "team.invite_accepted",
    entityType: "Invitation",
    entityId: invitation.id,
    details: { email: invitation.email, role: invitation.role },
    ip: clientIp(req),
  });

  await notify(
    invitation.organizationId,
    "team_invite_accepted",
    "Team invitation accepted",
    `${user.name} (${user.email}) joined ${invitation.organization.name}.`
  );

  return ok({
    membership: { id: membership.id, role: membership.role },
    organization: invitation.organization,
  });
}
