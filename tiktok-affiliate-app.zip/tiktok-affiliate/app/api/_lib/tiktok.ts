/**
 * app/api/_lib/tiktok.ts — typed facade over the TikTok integration layer.
 *
 * The API layer never calls TikTok directly; it goes through:
 * - lib/tiktok/provider (provider selection, server-only)
 * - lib/tiktok/oauth (authorization flow, token storage)
 * - lib/capabilities (CAP.* keys, hasCapability, error mapping)
 *
 * Canonical DTOs live in lib/tiktok/types.ts.
 */
import { getProviderForShopId } from "@/lib/tiktok/provider";
import {
  createAuthorizationSession,
  validateCallback,
  exchangeCodeForTokens,
  storeTokens,
  refreshAccessToken,
  disconnectShop,
} from "@/lib/tiktok/oauth";
import {
  CAP,
  getShopCapabilities,
  hasCapability,
  capabilityReason,
  mapTikTokError,
} from "@/lib/capabilities";
import type { CapKey, CapabilityInfo, MappedTikTokError } from "@/lib/capabilities";
import type {
  TikTokProvider,
  ProductDto,
  CampaignDto,
  CollaborationDto,
  PerformanceMetrics,
  PerformancePoint,
  TikTokTokenSet,
  CampaignInput,
  CampaignPatch,
  InviteCreatorInput,
  CampaignStatusAction,
} from "@/lib/tiktok/types";

export {
  getProviderForShopId,
  createAuthorizationSession,
  validateCallback,
  exchangeCodeForTokens,
  storeTokens,
  refreshAccessToken,
  disconnectShop,
  CAP,
  getShopCapabilities,
  hasCapability,
  capabilityReason,
  mapTikTokError,
};
export type {
  CapKey,
  CapabilityInfo,
  MappedTikTokError,
  TikTokProvider,
  ProductDto,
  CampaignDto,
  CollaborationDto,
  PerformanceMetrics,
  PerformancePoint,
  TikTokTokenSet,
  CampaignInput,
  CampaignPatch,
  InviteCreatorInput,
  CampaignStatusAction,
};

/** Backwards-compatible alias: resolve the provider for a shop id. */
export async function getShopProvider(shopId: string): Promise<TikTokProvider> {
  return getProviderForShopId(shopId);
}

/** Fields editable on a campaign that already exists on TikTok Shop. */
export const LIVE_EDITABLE_CAMPAIGN_FIELDS = [
  "name",
  "description",
  "endAt",
  "commissionRate",
] as const;
