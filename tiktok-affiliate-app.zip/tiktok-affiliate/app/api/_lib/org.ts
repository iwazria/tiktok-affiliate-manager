import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { fail } from "@/lib/api";
import { requireUser, requireOrgRole, OrgContext } from "@/lib/rbac";
import { SessionUser } from "@/lib/auth";

type AuthOk = { error: null; user: SessionUser };
type AuthFail = { error: NextResponse; user: null };

/** Require a signed-in user. Returns a discriminated union — check `error` first. */
export async function authUser(req: NextRequest): Promise<AuthOk | AuthFail> {
  const r = await requireUser(req);
  if (r.error || !r.user) {
    return {
      error: (r.error ?? fail("unauthorized", "Sign in required.", 401)) as NextResponse,
      user: null,
    };
  }
  return { error: null, user: r.user };
}

type OrgOk = { error: null; user: SessionUser; ctx: OrgContext };
type OrgFail = { error: NextResponse; user: null; ctx: null };

/**
 * Require a signed-in user who is a member of `orgId` with at least `minRole`.
 * Returns a discriminated union — check `error` first.
 */
export async function orgContext(
  req: NextRequest,
  orgId: string,
  minRole: string
): Promise<OrgOk | OrgFail> {
  const a = await authUser(req);
  if (a.error) return { error: a.error, user: null, ctx: null };
  const r = await requireOrgRole(a.user.id, orgId, minRole);
  if (r.error || !r.ctx) {
    return {
      error: (r.error ?? fail("forbidden", "You don't have permission for this action.", 403)) as NextResponse,
      user: null,
      ctx: null,
    };
  }
  return { error: null, user: a.user, ctx: r.ctx };
}

/** Best-effort client IP for rate limiting / audit. */
export function clientIp(req: NextRequest): string | undefined {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]?.trim() || undefined;
  return req.headers.get("x-real-ip") ?? undefined;
}

/** Fetch a shop scoped to the organization; returns null when not found (→ 404). */
export async function getOrgShop(organizationId: string, shopId: string) {
  return prisma.connectedShop.findFirst({
    where: { id: shopId, organizationId },
  });
}

function slugify(name: string): string {
  const base =
    name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40) || "org";
  return `${base}-${Math.random().toString(36).slice(2, 8)}`;
}

/** Generate a unique organization slug. */
export async function uniqueOrgSlug(name: string): Promise<string> {
  for (let i = 0; i < 5; i++) {
    const slug = slugify(name);
    const exists = await prisma.organization.findUnique({ where: { slug } });
    if (!exists) return slug;
  }
  return `org-${Date.now().toString(36)}`;
}

/** Parse ?page=&pageSize= with sane bounds. */
export function parsePagination(searchParams: URLSearchParams) {
  const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10) || 1);
  const pageSize = Math.min(
    100,
    Math.max(1, parseInt(searchParams.get("pageSize") ?? "20", 10) || 20)
  );
  return { page, pageSize, skip: (page - 1) * pageSize };
}

/** Notification types users can toggle in preferences. */
export const NOTIFICATION_TYPES = [
  "shop_auth_expired",
  "scope_missing",
  "sync_completed",
  "sync_failed",
  "campaign_changed",
  "invite_status",
  "campaign_ending",
  "export_ready",
  "team_invite_accepted",
  "integration_attention",
] as const;
