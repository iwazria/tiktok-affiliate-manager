import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef6ff",
          100: "#d9eaff",
          500: "#0f7ae5",
          600: "#0b63bd",
          700: "#0a529c",
        },
      },
    },
  },
  plugins: [],
};

export default config;
