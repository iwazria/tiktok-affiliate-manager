import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Keep the app container-friendly and dependency-light.
  poweredByHeader: false,
};

export default nextConfig;
