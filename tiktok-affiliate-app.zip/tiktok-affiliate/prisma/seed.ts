/**
 * Demo seed. Every row created here is clearly labeled demo data
 * (isDemo flags, mode "demo") and is safe to reset: `npm run db:seed`
 * wipes demo rows first. Never run against production.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding demo data…");

  // Reset demo data (idempotent re-seed)
  const demoOrg = await prisma.organization.findUnique({ where: { slug: "demo-commerce-co" } });
  if (demoOrg) {
    await prisma.organization.delete({ where: { id: demoOrg.id } });
  }
  await prisma.user.deleteMany({ where: { email: "demo@example.com" } });

  const passwordHash = await bcrypt.hash("demo1234", 12);
  const user = await prisma.user.create({
    data: { email: "demo@example.com", name: "Demo Seller", passwordHash, emailVerified: true },
  });

  const org = await prisma.organization.create({
    data: {
      name: "Demo Commerce Co",
      slug: "demo-commerce-co",
      members: { create: { userId: user.id, role: "owner", status: "active" } },
      onboarding: {
        create: { shopConnected: true, shopConfirmed: true, productsSynced: true, firstCampaign: true },
      },
    },
  });

  const shop = await prisma.connectedShop.create({
    data: {
      organizationId: org.id,
      tiktokShopId: "demo-shop-001",
      shopName: "Demo TikTok Shop",
      region: "US",
      currency: "USD",
      sellerType: "demo",
      status: "connected",
      mode: "demo",
      connectedById: user.id,
      lastSyncAt: new Date(),
      lastSyncStatus: "succeeded",
      scopes: {
        create: [
          { scope: "product.info" },
          { scope: "affiliate.campaign" },
          { scope: "affiliate.creator" },
        ].map((s) => ({ scope: s.scope })),
      },
    },
  });

  const productsData = [
    { tiktokProductId: "p-1001", name: "Aurora LED Desk Lamp", price: 34.99, status: "ACTIVE", stock: 420, affiliateEligible: true },
    { tiktokProductId: "p-1002", name: "Terra Ceramic Pour-Over Set", price: 49.5, status: "ACTIVE", stock: 180, affiliateEligible: true },
    { tiktokProductId: "p-1003", name: "Nimbus Ultralight Backpack", price: 79.0, status: "ACTIVE", stock: 0, affiliateEligible: false, ineligibilityReason: "Out of stock" },
    { tiktokProductId: "p-1004", name: "Solstice Vitamin C Serum", price: 24.99, status: "ACTIVE", stock: 950, affiliateEligible: true },
    { tiktokProductId: "p-1005", name: "Echo Bamboo Toothbrush (4-pack)", price: 12.99, status: "INACTIVE", stock: 300, affiliateEligible: false, ineligibilityReason: "Product not active" },
    { tiktokProductId: "p-1006", name: "Vertex Mechanical Keyboard", price: 129.0, status: "ACTIVE", stock: 75, affiliateEligible: true },
    { tiktokProductId: "p-1007", name: "Lumen Reusable Water Bottle", price: 19.99, status: "ACTIVE", stock: 1200, affiliateEligible: true },
    { tiktokProductId: "p-1008", name: "Drift Linen Throw Blanket", price: 59.0, status: "ACTIVE", stock: 210, affiliateEligible: true },
  ];

  const products = [];
  for (const p of productsData) {
    products.push(
      await prisma.product.create({
        data: {
          organizationId: org.id,
          shopId: shop.id,
          currency: "USD",
          isDemo: true,
          lastSyncedAt: new Date(),
          imageUrl: `https://picsum.photos/seed/${p.tiktokProductId}/400/400`,
          ...p,
        },
      })
    );
  }

  const eligible = products.filter((p) => p.affiliateEligible);
  const campaign = await prisma.campaign.create({
    data: {
      organizationId: org.id,
      shopId: shop.id,
      name: "Spring Creator Push",
      description: "Demo campaign promoting bestsellers with mid-tier creators.",
      status: "active",
      commissionRate: 12,
      commissionType: "percentage",
      collaborationType: "targeted",
      startAt: new Date(Date.now() - 20 * 86400000),
      endAt: new Date(Date.now() + 10 * 86400000),
      isDemo: true,
      createdById: user.id,
      products: { create: eligible.slice(0, 4).map((p) => ({ productId: p.id })) },
    },
  });

  await prisma.campaign.create({
    data: {
      organizationId: org.id,
      shopId: shop.id,
      name: "Summer Launch (draft)",
      description: "Local draft — not yet created on TikTok Shop.",
      status: "draft",
      commissionRate: 15,
      commissionType: "percentage",
      isDemo: true,
      createdById: user.id,
      products: { create: [{ productId: eligible[4].id }] },
    },
  });

  const creatorsData = [
    { handle: "@glowwithmia", displayName: "Mia Chen", followerCount: 84200, tags: ["beauty", "skincare"] },
    { handle: "@desksetupdan", displayName: "Dan Park", followerCount: 156000, tags: ["tech", "desk-setup"] },
    { handle: "@trailheadtess", displayName: "Tess Alvarez", followerCount: 48300, tags: ["outdoors", "travel"] },
    { handle: "@kitchenwithkojo", displayName: "Kojo Mensah", followerCount: 210500, tags: ["kitchen", "lifestyle"] },
    { handle: "@fitbypriya", displayName: "Priya Nair", followerCount: 92700, tags: ["fitness", "wellness"] },
    { handle: "@makerlou", displayName: "Lou Fontaine", followerCount: 31800, tags: ["diy", "home"] },
  ];

  const creators = [];
  for (const c of creatorsData) {
    creators.push(
      await prisma.creator.create({
        data: {
          organizationId: org.id,
          handle: c.handle,
          displayName: c.displayName,
          followerCount: c.followerCount,
          tags: JSON.stringify(c.tags),
          notes: "Demo creator — manually entered sample record.",
          source: "manual",
          isDemo: true,
          avatarUrl: `https://picsum.photos/seed/${encodeURIComponent(c.handle)}/200/200`,
        },
      })
    );
  }

  const list = await prisma.creatorList.create({
    data: {
      organizationId: org.id,
      name: "Q2 Prospects",
      createdById: user.id,
      members: { create: creators.slice(0, 3).map((c) => ({ creatorId: c.id })) },
    },
  });

  const collabStatuses: Array<{ creator: number; status: string; invitedDaysAgo: number }> = [
    { creator: 0, status: "accepted", invitedDaysAgo: 18 },
    { creator: 1, status: "sent", invitedDaysAgo: 6 },
    { creator: 2, status: "declined", invitedDaysAgo: 12 },
    { creator: 3, status: "completed", invitedDaysAgo: 25 },
  ];
  for (const c of collabStatuses) {
    await prisma.collaboration.create({
      data: {
        organizationId: org.id,
        campaignId: campaign.id,
        creatorId: creators[c.creator].id,
        tiktokInviteId: `demo-invite-${c.creator}`,
        status: c.status,
        invitedAt: new Date(Date.now() - c.invitedDaysAgo * 86400000),
        respondedAt: c.status === "sent" ? null : new Date(Date.now() - (c.invitedDaysAgo - 2) * 86400000),
        isDemo: true,
        createdById: user.id,
      },
    });
  }

  // 30 days of demo performance snapshots (labeled estimated)
  const snaps = [];
  for (let d = 30; d >= 1; d--) {
    const date = new Date();
    date.setUTCHours(0, 0, 0, 0);
    date.setUTCDate(date.getUTCDate() - d);
    const wave = Math.sin(d / 4) * 0.3 + 1;
    const clicks = Math.round(180 * wave + ((d * 37) % 60));
    const orders = Math.round(clicks * 0.06);
    const revenue = +(orders * 42.5).toFixed(2);
    snaps.push({
      organizationId: org.id,
      shopId: shop.id,
      campaignId: campaign.id,
      date,
      clicks,
      orders,
      revenue,
      commission: +(revenue * 0.12).toFixed(2),
      currency: "USD",
      quality: d <= 2 ? "pending" : "final",
      source: "demo",
    });
  }
  await prisma.performanceSnapshot.createMany({ data: snaps });

  await prisma.notification.createMany({
    data: [
      { organizationId: org.id, type: "sync_completed", title: "Product sync completed", body: "8 demo products synced just now." },
      { organizationId: org.id, type: "invite_status", title: "Creator accepted your invitation", body: "@glowwithmia accepted the Spring Creator Push collaboration." },
      { organizationId: org.id, type: "campaign_ending", title: "Campaign ending soon", body: "Spring Creator Push ends in 10 days." },
    ],
  });

  await prisma.auditLog.create({
    data: {
      organizationId: org.id,
      actorId: user.id,
      action: "seed.demo_data_loaded",
      entityType: "organization",
      entityId: org.id,
      details: JSON.stringify({ note: "Demo seed loaded" }),
    },
  });

  console.log("Done. Demo login: demo@example.com / demo1234");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
